const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
const path = require("path");


module.exports = {
    output: {
      uniqueName: "portalWebApp",
      publicPath: "auto",
    },
    optimization: {
      runtimeChunk: false
    },  
    resolve: {
      alias: {
        
      }
    },
    module: {
      rules: [
        {
          test: /\.html$/,
          use: ['html-loader']
        }
      ]
    },
    experiments: {
      outputModule: true
    },
    plugins: [
      new ModuleFederationPlugin({
   
          // For remotes (please Add this 5 Line)
          name: "portalWebApp",
          filename: "remoteEntry.js",
          remotes: {
            'astrPortFolioMasterWebApp' : "astrPortFolioMasterWebApp@http://localhost:3002/remoteEntry.js"
          },       
         
          shared: {
            "@angular/core": { singleton: true, strictVersion: true, eager: true },
            "@angular/common/": { singleton: true, strictVersion: true, eager: true },
            "@angular/router": { singleton: true, strictVersion: true, eager: true },
            }
      }),
    ],
    // devServer: {
    //   port: 1112,
    //   open: true,
    //   hot: false,
    //   liveReload: false,
    //   historyApiFallback: true,
    //   static: {
    //     directory: path.join(__dirname, 'dist')
    //   }
    // }
   };