export const LayoutConfig = {
    grid: {
        cssClass: 'grid-layout',
        description: 'Display Widgets in a grid layout',

    },
    'single-column': {
        cssClass: 'grid-layout',
        description: 'Display Widgets in a grid layout',

    },
}

export interface Layout {
    cssClass: string;
    description: string;
}