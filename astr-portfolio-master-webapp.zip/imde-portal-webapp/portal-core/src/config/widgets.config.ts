export interface WidgetItem {
    type?: string;
    remoteModule?:string;
    componentName?: string;
    moduleName?:string;
    id: string;
    key: any;
    inputs?: { [key:string]: any}
}

export const WidgetsConfig : WidgetItem[] = [
    {
        id: 'MainLayoutWidget',
        type: 'angular',
        remoteModule: 'astrPortFolioMasterWebApp',
        componentName: 'MainLayoutModule', //Refernce to mfe Module exposed,
        moduleName: 'astrPortFolioMasterWebAppModule',
        inputs: {
            title: ""
        },
        key: 1
    }
    
]

