export interface MenuItem {
    label: string;
    path: string;
    layout: string;
    widgets: string [];
}

export const MenuConfig = [
    {
        label: 'Security App',
        path: 'security',
        layout: 'grid',
        widgets:['angularWidget']
    },
    {
        label: 'Portfolio App',
        path: '',
        layout: 'single-column',
        widgets:['reactWidget']
    },
]