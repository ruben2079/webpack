// import { Injectable } from "@angular/core";
// import { WidgetsConfig } from "../config/widgets.config";

// @Injectable({
//     providedIn: 'root',
// })
// type WidgetKey = 'angularWidget' 
// export class MFELoaderService {
//     constructor() {}

//     async loadMfe(widgetName: string): Promise<any> {
//         const mfeConfig = WidgetsConfig[widgetName];
//         if(!mfeConfig) {
//             throw new Error(`No such MFE: ${widgetName}`)
//         }

//         //If the MFE is ANgular?React and exposed via Module Federation
//         if(mfeConfig === 'mfe') {
//             await __webpack_init_sharing__('default');
//             const container = (window as any)[widgetName];
//             await container.init(--webpack_share_scopes__.default);
//             const factory = await container.get(mfeConfig.component);
//             return factory();
//         }
//     }
// }