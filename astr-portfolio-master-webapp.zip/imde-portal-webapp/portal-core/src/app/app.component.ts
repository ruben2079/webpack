import { CommonModule } from '@angular/common';
import { Component, OnInit, Inject } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';

import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { IconsModule } from "@progress/kendo-angular-icons";
import { LabelModule } from "@progress/kendo-angular-label";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { DOCUMENT } from '@angular/common';
import { LocalStorageService } from './service/local-storage.service';

@Component({
  standalone: true,
  selector: 'app-root',
  imports: [CommonModule, RouterOutlet, RouterLink, ButtonsModule,ButtonsModule,
    IconsModule,
    LayoutModule,
    DropDownsModule,InputsModule,
    LabelModule],
  providers: [ LocalStorageService ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit {
  
  public currentTheme: string = 'light-theme';
  public checked: boolean = false;
  constructor(@Inject(DOCUMENT) private document: Document, private localStorageService: LocalStorageService){
   
  }
  ngOnInit(): void { 
    
    if(this.localStorageService.getItem('web-portal-theme')){
      this.currentTheme = this.localStorageService.getItem('web-portal-theme');
    }

    if(this.currentTheme === 'light-theme'){
      this.changeTheme(false);
    }
    if(this.currentTheme === 'dark-theme') {
      this.changeTheme(true);
    }
  }

  changeTheme(isDarkTheme: boolean): void {
    
    if (isDarkTheme) {
      this.currentTheme = 'dark-theme';
      this.document.getElementById('global-theme')?.setAttribute('href','/assets/css/voya-im-ds/vimds-kendo-dark-theme-v0.2.0.css');
      this.localStorageService.setItem("web-portal-theme", this.currentTheme);
      this.checked = true;
    }
    if(!isDarkTheme) {
      this.currentTheme = 'light-theme';
      this.document.getElementById('global-theme')?.setAttribute('href','/assets/css/voya-im-ds/vimds-kendo-light-theme-v0.2.0.css');
      this.localStorageService.setItem("web-portal-theme", this.currentTheme);
      this.checked = false;
    }
  }
}
