// import { Injectable } from "@angular/core";
// import { WidgetItem, WidgetsConfig } from "../config/widgets.config";

// type WidgetKey = keyof typeof WidgetsConfig;

// @Injectable({
//     providedIn: 'root',
// })
// export class WidgetLoaderService {
//     widgets: { [key: string]: WidgetItem};
//     constructor() {
//         //Assign WidgetCOnfig to the widgets property
//         this.widgets = WidgetsConfig;
//     }

//     async loadWidget(WidgetKey: WidgetKey) {
//         const selectedWidget = this.widgets[WidgetKey];
//         if(!selectedWidget) {
//             throw new Error(`No such widget: ${WidgetKey}`)
//         }

//         switch (selectedWidget.type) {
//             case 'mfe':
//                 return this.loadMFEModule(selectedWidget);
//             case 'ifram':
//                 return this.loadIframe(selectedWidget.url);
//             case '.net':
//                 return this.loadDotNetApp(selectedWidget);
//             case 'powerbi':
//                 return this.loadPowerBI(selectedWidget);
            
//             default:
//                 throw new Error(`unknown widget type: ${WidgetKey}`)
//         }
//     }

//     private async loadMFEModule(widget :WidgetItem) {
//         const container = await import(/* webpackIgnore: true */ widget.url);
//         const factory = await container.get(widget.component!); //MFE must have a component
//         return factory
//     }

//     private async loadIframe(url :string) {
//         const iframe = document.createElement('iframe');
//         iframe.src = url;
//         iframe.width = '100%';
//         iframe.height = '60px'; //adjust as needed
//        document.body.appendChild(iframe)
//     }
//     private async loadDotNetApp(widget :WidgetItem) {
//         const container = await import(/* webpackIgnore: true */ widget.url);
//         const factory = await container.get(widget.component!); //MFE must have a component
//         return factory
//     }
//     private async loadPowerBI(widget :WidgetItem) {
//         //adjust as needed
//         const iframe = document.createElement('iframe');
//         iframe.src = `${widget.url}?reportId=${widget.component}&access_token=${widget.additionalConfig?.accessToken}`;
//         iframe.width = '100%';
//         iframe.height = '60px'; //adjust as needed
//        document.body.appendChild(iframe)
//     }
//     getWidgets() {
//         return this.widgets;
//     }
// }