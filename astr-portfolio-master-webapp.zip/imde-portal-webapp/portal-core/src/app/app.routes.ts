import { Routes } from '@angular/router';
// import { MsalGuard } from '@azure/msal-angular';
// import { UserNotAllowedComponent } from './layout/user-not-allowed/user-not-allowed.component';
// import { ServerErrorComponent } from './layout/server-error/server-error.component';

export const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: ''
  },
  {
    path: '',
    loadChildren: () =>
      import('./content-providers/content-provider.module').then((m) => m.ContentProviderModule),
      canActivate: [],
  },

//   {
//     path: 'usernotallowed',
//     component: UserNotAllowedComponent,
//   },

//   {
//     path: '**',
//     component: ServerErrorComponent,
//   },
];
