import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContentProviderPageComponent } from './content-provider-page.component';
import { KtdGridModule } from '@katoid/angular-grid-layout';

const routes: Routes = [
  {
    path: '',
    component: ContentProviderPageComponent,
  }, 
  //  {
  //   path: 'astrPortFolioMasterWebApp/astrPortFolioMasterWebAppModule',
  //   component: ContentProviderPageComponent,
  // },
  // {
  //   path: 'details',
  //   component: MainLayoutModule,
  // },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule, KtdGridModule],
})
export class ContentProviderRotuingModule {}
