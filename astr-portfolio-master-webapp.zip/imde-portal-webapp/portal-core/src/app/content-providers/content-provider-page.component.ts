import { Component, OnInit } from "@angular/core";
import { MenuConfig } from "../../config/menu.config";
import { LayoutConfig } from "../../config/layout.config";
import { WidgetItem, WidgetsConfig } from "../../config/widgets.config";


@Component( {
    selector: 'content-provider-page',
    templateUrl: './content-provider-page.component.html',
    styleUrls: ['./content-provider-page.component.scss']
})
export class ContentProviderPageComponent implements OnInit {
    menuItems = MenuConfig;
    layoutType: string = 'grid';

    ngOnInit(): void {
        //load menu items and layout from config
        // this.menuItems = MenuConfig;
        this.layoutType = LayoutConfig['grid'].cssClass  || 'default-layout' //Default grid layout
    }
}