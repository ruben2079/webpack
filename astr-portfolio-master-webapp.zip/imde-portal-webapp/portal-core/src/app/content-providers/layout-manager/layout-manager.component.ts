import { Component, Input, OnInit } from "@angular/core";
import { LayoutConfig } from "../../../config/layout.config";
import { WidgetItem, WidgetsConfig } from "../../../config/widgets.config";
import { KtdGridLayout, ktdTrackById } from "@katoid/angular-grid-layout";


@Component({
    selector: 'layout-manager',
    templateUrl: './layout-manager.component.html',
    styleUrls: ['./layout-manager.component.scss']
})

export class LayoutManagerComponent implements OnInit {
    widgets: WidgetItem[] = WidgetsConfig;
    layout: KtdGridLayout = []; //Define layout for ktd-grid
    trackById = ktdTrackById;
    cols: number = 6;
    rowHeight: number = 100;
    ngOnInit(): void {
        this.layout = this.widgets.map((widget, index) => ({
            id: widget.key,
            x: index % this.cols,
            y: Math.floor(index / this.cols),
            w: 2,
            h: 2
        }))
        console.log('widgets', this.widgets)
    }

    onLayoutUpdated(layout: KtdGridLayout) {
        console.log('on layout updated', layout);
      }
}