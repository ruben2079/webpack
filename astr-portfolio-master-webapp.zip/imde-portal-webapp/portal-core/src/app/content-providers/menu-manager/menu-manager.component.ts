import { Component, Input, OnInit } from "@angular/core";
import { MenuConfig, MenuItem } from "../../../config/menu.config";

@Component({
    selector: 'menu-manager',
    templateUrl: './menu-manager.component.html',
    styleUrls: ['./menu-manager.component.scss']
})
export class MenuManagerComponent implements OnInit {
    @Input() menuItems : MenuItem [] = [];
    ngOnInit(): void {
        
    }
}