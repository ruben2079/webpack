import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from "@angular/core";
import { ContentProviderPageComponent } from "./content-provider-page.component";
import { LayoutManagerComponent } from "./layout-manager/layout-manager.component";
import { CommonModule } from "@angular/common";
import { MenuManagerComponent } from "./menu-manager/menu-manager.component";
import { RouterLink } from "@angular/router";
import { WidgetComponent } from "./widget/widget.component";
import { ContentProviderRotuingModule } from "./content-provider-routing.module";
import { KtdGridModule } from '@katoid/angular-grid-layout';

@NgModule({
    declarations: [
        ContentProviderPageComponent,
        MenuManagerComponent,
        LayoutManagerComponent,
        WidgetComponent
    ],
    imports: [
        CommonModule,
        RouterLink,
        ContentProviderRotuingModule,
        KtdGridModule
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class ContentProviderModule {}