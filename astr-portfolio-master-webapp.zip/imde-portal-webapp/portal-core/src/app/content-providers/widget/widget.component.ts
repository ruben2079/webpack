import { Component, Input, OnInit, ViewContainerRef, ViewChild, input, ComponentRef } from "@angular/core";
import { WidgetItem, WidgetsConfig } from "../../../config/widgets.config";

interface WidgetComponentInstance {
    [key: string]: any;
}

@Component({
    selector: 'widget-app',
    templateUrl: './widget.component.html',
    styleUrls: ['./widget.component.scss'],
    template: '<ng-container #mfeContainer></ng-container>'
})
export class WidgetComponent implements OnInit {
    @Input() widget!: WidgetItem;
    @ViewChild('mfeContainer', {read: ViewContainerRef, static: true})
    mfeContainer!: ViewContainerRef
    async ngOnInit(): Promise<void> {
        // const config = WidgetsConfig.find((w)=> w.id === this.widget.id)
            try {
                if(this.widget.remoteModule && this.widget.componentName) {
                    const mfeModule = await import(`${this.widget.remoteModule}/${this.widget.moduleName}`);
                    const moduleClass = mfeModule[this.widget.componentName]
                    const componentRef = this.mfeContainer.createComponent<WidgetComponentInstance>(moduleClass as any) as ComponentRef<WidgetComponentInstance>;
                    if(this.widget.inputs) {
                        Object.keys(this.widget.inputs).forEach((input) => {
                            (componentRef.instance as WidgetComponentInstance)[input] = this.widget.inputs?.[input]
                        })
                    }
                }
            } catch (error) {
                console.error("error loading widget:", error)
            }
        }

    openUrl(url: string) {
        if(url) {
            window.open(url, '_blank')
        }
    }
    
}