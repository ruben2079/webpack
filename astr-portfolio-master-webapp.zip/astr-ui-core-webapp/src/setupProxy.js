const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function (app) {
  app.use(
    '/v1',
    createProxyMiddleware({
      target: 'https://vim-zue2-dev-astr-mstr-001.vimasezue2intdev002.appserviceenvironment.net',
      changeOrigin: true,
    })
  );
};
