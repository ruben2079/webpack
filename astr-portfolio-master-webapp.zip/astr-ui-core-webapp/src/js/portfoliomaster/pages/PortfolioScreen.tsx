import React, { FC, useEffect, useState } from "react";
import classNames from "classnames";
import { Menu, MenuItem } from "@progress/kendo-react-layout";
import { Button } from "@progress/kendo-react-buttons";
import { pencilIcon } from "@progress/kendo-svg-icons";

import {
  checkFieldsMaxLength,
  checkRequiredFields,
  getAllGridFields,
  getDuplicates,
  getRequiredFieldsBasedonStatus,
} from "../utils/utils";
import PortfolioInfoPanel from "../components/PortfolioInfoPanel";
import * as constants from "../utils/constants";
import PortfolioSnapShot from "../components/PortfolioSnapShot";
import PortfolioTagGrid from "../components/PortfolioTagGrid";
import FormGenerationGrid from "../components/FormGenerationGrid";

import styles from "./PortfolioScreen.module.scss";

const {
  container,
  content,
  back_link,
  action_btn,
  portfolio_menu,
  menu_link,
  selected,
  warnning_info,
  error_field,
} = styles;

interface IPSProps {
  className?: string;
  gridMeta?: any[];
  allDataFields?: string[];
  isEditMode?: boolean;
  isReadOnly?: boolean;
  feedFormName?: string;
  portfolioCode?: string;
  portfolioData?: any;
  referenceData?: any;
  referenceList?: any;
  referenceObjects?: any;
  entitlement?: any;
  switchScreen?: (screen: string, options?: any) => void;
  openNewPortfolio?: (
    isOpen: boolean,
    portfolioCode?: string,
    isClone?: boolean
  ) => void;
  updatePortfolio?: (dataItem: any) => void;
  filterPortfolio?: (filters: FilterItem[]) => void;
  updateReference?: (
    referenceId: string,
    dataItem: string,
    isUpdatePortfolio: boolean,
    isUpdatePortfolioOnly: boolean
  ) => void;
  fetchDownStream?: (formType: string) => void;
  fetchAllPorfolio?: (isCoreDataOnly: boolean) => void;
}

type PSProps = IPSProps;

const PortfolioScreen: FC<PSProps> = (props: PSProps) => {
  const {
    className,
    gridMeta = [],
    isEditMode = false,
    isReadOnly = false,
    feedFormName = null,
    portfolioCode,
    portfolioData,
    entitlement,
    referenceData,
    referenceList,
    referenceObjects,
    switchScreen,
    openNewPortfolio,
    updatePortfolio,
    filterPortfolio,
    updateReference,
    fetchDownStream,
    fetchAllPorfolio,
  } = props;
  const [contentView, setContentView] = useState(
    constants.default_portfolio_content_view
  );
  const [portfolioState, setPortfolioState] = useState(null);
  const [disableSave, setDisableSave] = useState(true);
  const [requiredFields, setRequiredFields] = useState(null);

  useEffect(() => setPortfolioState(portfolioData || {}), [portfolioData]);

  useEffect(() => {
    let requiredFields = null;
    if (!!portfolioState && !!portfolioData) {
      requiredFields = checkRequiredFields(
        portfolioState,
        getRequiredFieldsBasedonStatus(
          portfolioState,
          !!feedFormName,
          referenceObjects,
          portfolioState.Status === portfolioData.Status,
          !!feedFormName ? constants[`${feedFormName}_form_dq_fields`] : null
        )
      );
      setDisableSave(
        requiredFields.isFailed || checkFieldsMaxLength(portfolioState)
      );
      setRequiredFields(requiredFields);
    }
  }, [portfolioState, feedFormName]);

  const portfolioScreen_cn = classNames(container, className);
  useEffect(() => {
    !!isEditMode &&
      !viewItem.isEditable &&
      setContentView(constants.portfolio_menuitems[0].key);
  }, [isEditMode]);

  const handleSelect = (e) => {
    const contentView = constants.portfolio_menuitems[e.itemId].key;
    setContentView(contentView);
    contentView === "form" && fetchAllPorfolio(true);
  };

  const viewItem = constants.portfolio_menuitems.find(
    (menu) => menu.key === contentView
  );

  return (
    <div className={portfolioScreen_cn}>
      <div
        className={back_link}
        onClick={() => switchScreen("home")}
      >{`< Back to portfolios list`}</div>
      {!!portfolioData && (
        <>
          <PortfolioSnapShot
            gridMeta={gridMeta}
            isReadOnly={isReadOnly}
            isEditMode={isEditMode}
            portfolioData={portfolioData}
            switchScreen={switchScreen}
            feedFormName={feedFormName}
          >
            <div className={warnning_info}>* Required field</div>
            {!isReadOnly ? (
              isEditMode ? (
                <>
                  <Button
                    className={classNames(
                      action_btn,
                      "k-button-flat k-button-flat-base"
                    )}
                    onClick={() => {
                      setPortfolioState({ ...portfolioData });
                      switchScreen("portfolio", {
                        portfolioCode,
                        feedFormName: null,
                      });
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    disabled={disableSave}
                    className={action_btn}
                    themeColor="primary"
                    onClick={() => updatePortfolio(portfolioState)}
                  >
                    Save
                  </Button>
                </>
              ) : (
                <>
                  {!isReadOnly && (
                    <Button
                      themeColor="primary"
                      svgIcon={pencilIcon}
                      className={action_btn}
                      onClick={() =>
                        switchScreen("portfolio", {
                          portfolioCode,
                          isEditMode: true,
                        })
                      }
                    >
                      Edit
                    </Button>
                  )}
                  {!!entitlement?.CanSetup && (
                    <Button
                      themeColor="base"
                      className={action_btn}
                      onClick={() =>
                        openNewPortfolio(true, portfolioCode, true)
                      }
                    >
                      Clone
                    </Button>
                  )}
                </>
              )
            ) : null}
          </PortfolioSnapShot>
          <div className={content}>
            <Menu
              vertical={true}
              className={portfolio_menu}
              onSelect={handleSelect}
            >
              {constants.portfolio_menuitems.map((item) => {
                const { key, text, isEditable } = item;
                const sectionItem = constants.portfolio_content_datafields[key];
                const duplicates = getDuplicates([
                  ...(!!sectionItem
                    ? getAllGridFields(
                        referenceList,
                        referenceObjects,
                        sectionItem
                      )
                    : []),
                  ...(!!requiredFields ? requiredFields.errorFields : []),
                ]);
                return key !== "form" || !isReadOnly ? (
                  <MenuItem
                    key={key}
                    text={text}
                    disabled={!isEditable && isEditMode}
                    cssClass={classNames(menu_link, {
                      [selected]: contentView === key,
                      [error_field]:
                        !!requiredFields &&
                        requiredFields.isFailed &&
                        !!duplicates.length,
                    })}
                  />
                ) : null;
              })}
            </Menu>
            <div>
              {viewItem.isEditable ? (
                <>
                  <PortfolioInfoPanel
                    datafields={
                      constants.portfolio_content_datafields[contentView]
                    }
                    contentView={contentView}
                    isReadOnly={isReadOnly}
                    isEditMode={isEditMode}
                    feedFormName={feedFormName}
                    portfolioData={portfolioData}
                    referenceList={referenceList}
                    referenceObjects={referenceObjects}
                    entitlement={entitlement}
                    onPortfolioClick={(portfolioCode) =>
                      switchScreen("portfolio", {
                        portfolioCode,
                      })
                    }
                    onStateChange={(state) => {
                      setPortfolioState({ ...portfolioState, ...state });
                    }}
                  />
                </>
              ) : contentView === "tags" ? (
                <PortfolioTagGrid
                  viewItem={viewItem}
                  isReadOnly={isReadOnly}
                  entitlement={entitlement}
                  referenceList={referenceList}
                  referenceData={referenceData}
                  portfolioData={portfolioData}
                  filterPortfolio={filterPortfolio}
                  updateReference={updateReference}
                />
              ) : (
                !isReadOnly && (
                  <FormGenerationGrid
                    viewItem={viewItem}
                    referenceList={referenceList}
                    referenceObjects={referenceObjects}
                    portfolioData={portfolioData}
                    switchScreen={switchScreen}
                    isReadOnly={isReadOnly}
                    downStreamTigger={fetchDownStream}
                  />
                )
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default PortfolioScreen;
