import React, { FC, useEffect, useMemo, useState } from "react";
import classNames from "classnames";
import { Button, ButtonGroup } from "@progress/kendo-react-buttons";
import { Checkbox, Input } from "@progress/kendo-react-inputs";
import { DropDownList } from "@progress/kendo-react-dropdowns";
import { filterBy } from "@progress/kendo-data-query";
import _ from "lodash";

import DataGrid from "../../common/components/DataGrid";
import {
  DEFAULT_PM_GRID_DEF,
  DEFAULT_VIEW_MODE,
  Default_Filters,
  Filter_Suffix,
  home_screen_filterCheckbox,
  max_pageSize,
  portfolio_date_datafields,
  reference_data_fields_pair,
  status_options,
} from "../utils/constants";
import PortfolioActionMenu from "../components/PortfolioActionMenu";
import {
  getDataFieldTitle,
  getGridFilterRender,
  getSubOptions,
  getPortfolioManagerTeamOptions,
  getReferenceOptions,
  getStatusClass,
  getStatusOptions,
} from "../utils/utils";
import StatusDialog from "../components/StatusDialog";
import StyledMultiSelectedList from "../../common/components/StyledMultiSelectedList";
import StyledRangeDatePicker from "../../common/components/StyledRangeDatePicker";

import styles from "./HomeScreen.module.scss";

const {
  container,
  new_button,
  tool_bar,
  filter_content,
  filter_item,
  link,
  upper_case,
  main_grid,
  grid_action,
  filter_btn,
} = styles;

interface IHSProps {
  className?: string;
  allData?: any;
  allDataFields?: string[];
  filters?: FilterItem[];
  isReadOnly?: boolean;
  referenceList?: any;
  referenceObjects?: any;
  entitlement?: any;
  userSettings?: any;
  switchScreen?: (screen: string, options?: any) => void;
  openNewPortfolio?: (
    isOpen: boolean,
    portfolioCode?: string,
    isClone?: boolean
  ) => void;
  updatePortfolio?: (dataItem: any) => void;
  filterPortfolio?: (filters: FilterItem[]) => void;
  updateUserSettings?: (Settings: any) => void;
}

type HSProps = IHSProps;

const HomeScreen: FC<HSProps> = (props: HSProps) => {
  const {
    className,
    entitlement = {},
    userSettings = {},
    allData,
    allDataFields,
    filters = [],
    isReadOnly = false,
    referenceList,
    referenceObjects,
    switchScreen,
    openNewPortfolio,
    updatePortfolio,
    filterPortfolio,
    updateUserSettings,
  } = props;
  const [viewMode, setViewMode] = useState(Object.keys(DEFAULT_VIEW_MODE)[1]);
  const [visibleStatusDialog, setVisibleStatusDialog] = useState(false);
  const [selectedPortfolio, setSelectedPortfolio] = useState(null);
  const [selectedFilterId, setSelectedFilterId] = useState(null);
  const [selectedFilterValue, setSelectedFilterValue] = useState(null);
  const [filterFields, setFilterFields] = useState([]);
  const [isResetFilter, setResetFilter] = useState(false);

  const allFilterFields = useMemo(() => {
    let existed_fields = [];
    const filter_dataFields = _.chain(allDataFields)
      .sortBy()
      .xor(existed_fields)
      .map((field) => ({
        id: field,
        text: getDataFieldTitle(field),
      }))
      .value();
    setFilterFields(filter_dataFields);
    return filter_dataFields;
  }, [allDataFields]);

  useEffect(() => {
    if (!!filters && !!filters.length) {
      const filterItem = filters.filter(
        (item) => !item.key.includes(Filter_Suffix)
      );
      if (!!filterItem.length) {
        const filter = filterItem[0];
        setSelectedFilterId(filter.key);
        setSelectedFilterValue(filter.value);
      }
    }
    setResetFilter(false);
  }, [filters]);

  const homeScreen_cn = classNames(container, className);

  const onFilterClicked = (
    e,
    filterId?,
    filterValue?,
    isClear = false,
    isReset = false
  ) => {
    let newFilters = filters.filter((f) => f.key.includes(Filter_Suffix));
    let needFilter = true;
    if (!isClear && !isReset) {
      newFilters.push({
        key: filterId || selectedFilterId,
        value: filterValue || selectedFilterValue,
        isExclude: false,
      });
    } else {
      setSelectedFilterId(null);
      setSelectedFilterValue(null);
      if (isReset) {
        needFilter = !_.isEqual(filters, Default_Filters);
        newFilters = Default_Filters;
        setResetFilter(isReset);
      }
    }
    needFilter && filterPortfolio(newFilters);
  };

  const { referenceItem, codeReferenceItem, filterOptions } = useMemo(() => {
    const references = getReferenceOptions(
      selectedFilterId,
      referenceList,
      referenceObjects
    );
    const filterOptions =
      !!selectedFilterId && !!references.referenceItem
        ? selectedFilterId === "Status"
          ? getStatusOptions()
          : Object.values(
              Object.keys(reference_data_fields_pair).includes(selectedFilterId)
                ? getSubOptions("all", references.referenceItem)
                : references.referenceItem
            ).sort()
        : [];
    return { ...references, filterOptions };
  }, [selectedFilterId]);

  const createGridToolbar = () => (
    <>
      {entitlement?.CanSetup && (
        <Button
          themeColor="primary"
          className={new_button}
          onClick={() => openNewPortfolio(true)}
        >
          Create New Portfolio
        </Button>
      )}
      <div className={tool_bar}>
        {/* <div>
          <span>View Mode</span>
          <ButtonGroup>
            {Object.keys(DEFAULT_VIEW_MODE).map((view) => (
              <Button
                key={`${view}_btn`}
                togglable={true}
                selected={viewMode === view}
                onClick={() => setViewMode(view)}
              >
                {view}
              </Button>
            ))}
          </ButtonGroup>
        </div> */}
        <div>
          <DropDownList
            data={filterFields}
            textField="text"
            filterable={true}
            defaultItem={{
              id: null,
              text: "Select data field",
            }}
            value={
              selectedFilterId
                ? allFilterFields.find((item) => item.id === selectedFilterId)
                : null
            }
            onFilterChange={(event) => {
              setFilterFields(filterBy(allFilterFields, event.filter));
            }}
            style={{
              width: "300px",
            }}
            onChange={(event) => {
              setSelectedFilterId(event.target.value.id);
              setSelectedFilterValue(null);
            }}
          />
          {!!selectedFilterId &&
          (!!referenceItem ||
            portfolio_date_datafields.includes(selectedFilterId) ||
            selectedFilterId.includes("On")) ? (
            !!referenceItem ? (
              <StyledMultiSelectedList
                className={filter_item}
                value={selectedFilterValue || []}
                options={filterOptions || []}
                {...(codeReferenceItem
                  ? { itemRender: getGridFilterRender(codeReferenceItem) }
                  : {})}
                onSave={(e, value) =>
                  setSelectedFilterValue(
                    !!value && !!value.length ? value : null
                  )
                }
              />
            ) : (
              <StyledRangeDatePicker
                className={filter_item}
                value={selectedFilterValue || null}
                onSave={(event, dates) =>
                  setSelectedFilterValue(
                    !!dates.min || !!dates.max ? dates : null
                  )
                }
              />
            )
          ) : (
            <Input
              placeholder="Enter keyword"
              className={filter_item}
              value={selectedFilterValue || ""}
              onChange={(e) => setSelectedFilterValue(e.target.value)}
            ></Input>
          )}
          <Button
            className={filter_btn}
            disabled={!selectedFilterId || !selectedFilterValue}
            themeColor="primary"
            onClick={onFilterClicked}
          >
            Filter
          </Button>
          <Button
            className={classNames(
              filter_btn,
              "k-button-flat k-button-flat-base"
            )}
            onClick={(e) => {
              onFilterClicked(e, null, null, true);
            }}
          >
            Clear
          </Button>
        </div>
        <div className={filter_content}>
          {home_screen_filterCheckbox.map((filter) => {
            const old_filter = filters.findIndex(
              (f) =>
                f.key === filter.key ||
                (filter.isReverse &&
                  f.key === filter.key.replace(Filter_Suffix, ""))
            );
            const isCheck = old_filter > -1;
            return (
              <div key={filter.key}>
                <Checkbox
                  checked={!filter.isReverse ? isCheck : !isCheck}
                  value={filter.value}
                  label={filter.text}
                  onChange={(e) => {
                    const newFilters = [...(filters || [])];
                    const normalCase = !filter.isReverse && e.value;
                    const reverselCase = filter.isReverse && !e.value;
                    (normalCase || reverselCase) &&
                      newFilters.push({
                        key: filter.key,
                        value: filter.value,
                        isExclude: filter?.isExclude,
                      });
                    !(normalCase || reverselCase) &&
                      newFilters.splice(old_filter, 1);
                    filterPortfolio(newFilters);
                  }}
                />
              </div>
            );
          })}
          <Button
            className={"k-button-flat k-button-flat-base"}
            onClick={(e) => {
              onFilterClicked(e, null, null, false, true);
            }}
          >
            Reset Filters
          </Button>
        </div>
      </div>
    </>
  );

  const handleActionMenuSelect = (menuText, dataItem) => {
    if (Object.values(status_options).includes(menuText)) {
      setSelectedPortfolio(dataItem);
      toggleStatusDialog();
    } else {
      switch (menuText) {
        case "Edit":
          switchScreen("portfolio", {
            portfolioCode: dataItem.PortfolioCode,
            isEditMode: true,
          });
          break;
        case "Clone":
          openNewPortfolio(true, dataItem.PortfolioCode, true);
          break;
        default:
          break;
      }
    }
  };

  const colDefs = useMemo(() => {
    const allDataCols = (allDataFields || []).map((field) => ({
      field,
      width: "150px",
      hide: true,
    }));
    const allCols = _.unionBy(
      userSettings.colDefs || DEFAULT_VIEW_MODE[viewMode].columnDefs,
      allDataCols,
      "field"
    );
    const cols = allCols.map(
      (col) => {
        let referenceId = col.field;
        let newCol = {
          ...col,
          title: getDataFieldTitle(referenceId),
        };

        let { referenceItem, codeReferenceItem } = getReferenceOptions(
          referenceId,
          referenceList,
          referenceObjects
        );

        if (
          !!referenceItem &&
          Object.keys(reference_data_fields_pair).includes(referenceId)
        ) {
          referenceItem = getSubOptions("all", referenceItem);
        }
        if (referenceId === "PortfolioManagerTeamName") {
          referenceItem = getPortfolioManagerTeamOptions(referenceItem);
        }
        !!referenceItem &&
          referenceId !== "Status" &&
          (newCol = {
            ...newCol,
            filter: "text",
            filter_type: "list",
            filter_options: Object.values(referenceItem),
            ...(codeReferenceItem
              ? { filter_item_render: getGridFilterRender(codeReferenceItem) }
              : {}),
          });

        portfolio_date_datafields.includes(referenceId) &&
          (newCol = {
            ...newCol,
            filter: "date",
          });

        switch (referenceId) {
          case "Status":
            newCol = {
              ...newCol,
              filter: "text",
              filter_type: "list",
              filter_options: getStatusOptions(),
              cell: (props, tdProps) =>
                !props.dataItem.aggregates && (
                  <td {...tdProps}>
                    <div
                      className={classNames(
                        "status",
                        getStatusClass(props.dataItem.Status)
                      )}
                    >
                      {props.dataItem.Status}
                    </div>
                  </td>
                ),
            };
            break;
          case "PortfolioCode":
          case "ParentPortfolioCode":
          case "PortfolioName":
            newCol = {
              ...newCol,
              cell: (props, tdProps) => {
                const dispalyValue = props.dataItem[newCol.field];
                const PortfolioCode =
                  newCol.field !== "ParentPortfolioCode"
                    ? props.dataItem.PortfolioCode
                    : props.dataItem[newCol.field];
                return (
                  !props.dataItem.aggregates && (
                    <td {...tdProps}>
                      <div
                        className={classNames(link, {
                          [upper_case]: referenceId !== "PortfolioName",
                        })}
                        onClick={() =>
                          switchScreen("portfolio", {
                            portfolioCode: PortfolioCode,
                          })
                        }
                      >
                        {dispalyValue}
                      </div>
                    </td>
                  )
                );
              },
            };
            break;
          case "BaseCurrencyName":
          case "ReportingCurrencyName":
            newCol = {
              ...newCol,
              cell: (props) => {
                return (
                  <td>
                    {(props.dataItem[newCol.field] || "").split("-")[0].trim()}
                  </td>
                );
              },
            };
            break;
        }
        return newCol;
      },
      [userSettings.colDefs]
    );

    !isReadOnly &&
      cols.push({
        field: "Action",
        title: " ",
        filterable: false,
        sortable: false,
        width: "40px",
        locked: true,
        cell: (props, tdProps) =>
          !props.dataItem.aggregates && (
            <td {...tdProps}>
              <PortfolioActionMenu
                className={grid_action}
                entitlement={entitlement}
                hasEdit={!isReadOnly}
                portfolioData={props.dataItem}
                referenceObjects={referenceObjects}
                onSelect={(action: string): void =>
                  handleActionMenuSelect(action, props.dataItem)
                }
              />
            </td>
          ),
      });

    return cols;
  }, [viewMode, entitlement, isReadOnly, referenceList]);

  const toggleStatusDialog = () => {
    setVisibleStatusDialog(!visibleStatusDialog);
    if (!!visibleStatusDialog) {
      setSelectedPortfolio(null);
    }
  };
  return (
    <div className={homeScreen_cn}>
      <DataGrid
        className={main_grid}
        gridData={allData}
        gridDef={{
          ...DEFAULT_PM_GRID_DEF,
          pageable: {
            ...DEFAULT_PM_GRID_DEF.pageable,
            pageSizes: [
              50,
              100,
              500,
              (allData || []).length <= max_pageSize ? "All" : max_pageSize,
            ],
          },
          toolbarRender: createGridToolbar,
        }}
        columnDefs={colDefs}
        isResetFilter={isResetFilter}
        resetCallback={() => {
          setResetFilter(false);
        }}
        onSaveUserSettings={(colDefs) => {
          updateUserSettings({ ...userSettings, colDefs });
        }}
      />
      <StatusDialog
        isVisible={visibleStatusDialog}
        portfolioData={selectedPortfolio}
        onClose={toggleStatusDialog}
        onSave={(dataItem: any) => {
          updatePortfolio({ Id: selectedPortfolio.Id, ...dataItem });
          toggleStatusDialog();
        }}
      />
    </div>
  );
};

export default HomeScreen;
