import React, { ReactElement, cloneElement } from "react";
import classNames from "classnames";
import _ from "lodash";
import {
  portfolio_inputs_key_max_length_mapping,
  excluded_filter_fields,
  portfolio_content_datafields,
  portfolio_required_datafields,
  status_options,
  portfolio_active_required_datafields,
  ESG_DQ_keys,
  single_reference_ids,
  portfolio_toggle_datafields,
  ABOR_DQ_key,
  xreference_DQ_key,
  DEFAULT_VIEW_MODE,
  portfolio_key_name_mapping,
  Benchmark_Suffix,
  defautlErrorMessage,
  XReference_Split,
  Benchmark_DQ_Values,
  portfolio_date_datafields,
  data_value_split,
  currency_data_value_split,
  portfolio_inputs_key_fixed_length_mapping,
} from "./constants";
import { ListItemProps } from "@progress/kendo-react-dropdowns";
import { getDateStringforSaving } from "../../common/utils/utils";

export const getNextStatus = (status: string) => {
  const nextStatusIndex = Object.values(status_options).indexOf(status) + 1;
  return [
    Object.values(status_options)[
      nextStatusIndex < Object.values(status_options).length
        ? nextStatusIndex
        : 0
    ],
  ];
};

export const getStatusClass = (status: string) => {
  if (!status) {
    return "";
  }
  const statusArray = status.toLowerCase().split(" ");
  return classNames(
    "portfolio_status",
    `${statusArray[statusArray.length - 1]}`
  );
};

export const checkParentPortfolio = (typeValue) => {
  return !!typeValue && typeValue === "Sleeve";
};

export const getRequiredFieldsBasedonStatus = (
  dataState,
  isSaveForm,
  referenceObjects,
  isInit = false,
  dataFields = portfolio_required_datafields
) => {
  let requiredFields = [...(dataFields || portfolio_required_datafields)];
  if (isSaveForm) {
    return requiredFields;
  }
  if (!!dataState && !!dataState.Status) {
    const status = dataState.Status;
    if (!isInit) {
      switch (status) {
        case status_options.OperationallyReady:
        case status_options.Active:
          requiredFields = requiredFields.concat(
            portfolio_active_required_datafields
          );

          !!dataState.PerformanceBookOfRecordName &&
            dataState.PerformanceBookOfRecordName !== "Not Applicable" &&
            requiredFields.push("PerformanceInceptionDate");

          !!dataState.CustodianBankName &&
            dataState.CustodianBankName !== "No Custodian Access" &&
            requiredFields.push("CustodianAccountNumber");

          ABOR_DQ_key.includes(dataState.VehicleName) &&
            (requiredFields = _.without(requiredFields, "ABORSystemName"));

          !!dataState.ESGFlag &&
            dataState.ESGFlag === "Yes" &&
            (requiredFields = requiredFields.concat(ESG_DQ_keys));

          !!dataState.ESGSustainability &&
            dataState.ESGSustainability === "Yes" &&
            requiredFields.push("ESGSustainabilityObjectiveName");

          if (!!referenceObjects) {
            const { options, keyField } =
              referenceObjects.PortfolioXReferenceCategoryName;
            Object.values(options[keyField]).forEach((referenceId: any) => {
              if (!referenceId.includes("Shareholder")) {
                const checking = checkXreference(dataState);
                const checkingKey = referenceId
                  .split(XReference_Split)[0]
                  .toLowerCase();
                checking.toLowerCase().includes(checkingKey.toLowerCase()) &&
                  requiredFields.push(referenceId);
              } else {
                !!dataState.TransferAgentSystemName &&
                  dataState.TransferAgentSystemName !== "Not Applicable" &&
                  requiredFields.push(referenceId);
              }
            });
          }
          break;
        case status_options.Closed:
          requiredFields = requiredFields.concat(["LiquidationDate"]);
          break;
        default:
          break;
      }
    }
  }
  !!dataState &&
    !checkParentPortfolio(dataState.PortfolioTypeName) &&
    (requiredFields = _.without(requiredFields, "ParentPortfolioCode"));
  return requiredFields;
};

export const checkRequiredFields = (dataState, requiredFields) => {
  const passEsg =
    !_.intersection(requiredFields, ESG_DQ_keys).length ||
    !dataState.ESGFlag ||
    dataState.ESGFlag === "No" ||
    ESG_DQ_keys.some((esgkey) => {
      return (
        !!dataState[esgkey] &&
        dataState[esgkey] === "Yes" &&
        (esgkey !== "ESGSustainability" ||
          (!!dataState.ESGSustainability &&
            dataState.ESGSustainability === "Yes" &&
            !!dataState.ESGSustainabilityObjectiveName))
      );
    });
  let errorFields = [];
  _.without(
    requiredFields,
    ...ESG_DQ_keys,
    "PrimaryPortfolioManager",
    "PortfolioManagerMembers"
  ).forEach((key) => {
    if (!dataState[key]) {
      errorFields = [...errorFields, key];
    }
  });
  return {
    isFailed: !!errorFields.length || !passEsg,
    errorFields: _.uniq(errorFields),
  };
};

export const checkAccessibility = (entitlement, contentView, section) =>
  entitlement.CanSetup ||
  entitlement.CanApprove ||
  (!!entitlement?.OwnedFields &&
    !!entitlement?.OwnedFields.length &&
    (entitlement?.OwnerSections.indexOf(`${contentView}---${section.title}`) >
      -1 ||
      !section.owner.length));

export const genentePortfolioData = (
  data: any[],
  referenceList,
  referenceObjects,
  oldData = null
) => {
  if (!!data && !Array.isArray(data)) {
    return [];
  }

  const referenceObjectKeys = _.chain(Object.values(referenceObjects || {}))
    .values()
    .map((obj) => Object.values(obj.options[obj.keyField]))
    .flatten()
    .value();
  return data.map((item) => {
    const newItem: any = {};
    Object.keys(item).forEach((key) => {
      const referenceItem = referenceList[key];
      const isReferenceObject = referenceObjectKeys.includes(key);
      if (isReferenceObject) {
        const objdata = item[key] || null;
        const referenceObject: any = Object.values(referenceObjects).filter(
          (item: any) =>
            Object.values(item.options[item.keyField]).includes(key)
        )[0];
        const { dataField, keyField, valueField, options, benchmarkType } =
          referenceObject;
        const old_Item =
          !!oldData && !!oldData[dataField]
            ? oldData[dataField].findLast((item) => {
                return (
                  key.includes(item[keyField].replace(Benchmark_Suffix, "")) &&
                  (!benchmarkType ||
                    Object.keys(options[valueField]).includes(
                      `${item[valueField]}`
                    ))
                );
              })
            : {};
        const newKey = !!benchmarkType
          ? `${key.replace(benchmarkType, "")}`
          : key;
        const newValue = !!benchmarkType
          ? Number(_.invert(options[valueField])[objdata])
          : objdata;
        newItem[dataField] = [...(newItem[dataField] || [])];
        (!old_Item || newValue !== old_Item[valueField]) &&
          newItem[dataField].push({
            ...old_Item,
            [keyField]: newKey,
            [valueField]: !!newValue
              ? newValue
              : !!old_Item
              ? old_Item[valueField]
              : null,
            Status: !!objdata,
          });
        newItem[dataField] = newItem[dataField].filter(
          (item) => !(!item.Id && !item[valueField] && !item.Status)
        );
      } else if (
        portfolio_toggle_datafields.includes(key) ||
        key === "Status"
      ) {
        const value = Object.keys(referenceItem).find((itemKey: any) =>
          referenceItem[itemKey].includes(item[key])
        );
        newItem[key] =
          value === "true" || value === "false" ? value === "true" : value;
      } else if (!Object.keys(single_reference_ids).includes(key)) {
        const objdata = item[key] || null;
        newItem[key] = key.toLowerCase().includes("currency")
          ? getSplitValue(objdata, true)
          : !!objdata && portfolio_date_datafields.includes(key)
          ? getDateStringforSaving(new Date(objdata))
          : objdata;
      }
    });
    return newItem;
  });
};

export const genenteGridData = (
  data: any[],
  referenceList,
  referenceObjects
) => {
  if (!!data && !Array.isArray(data)) {
    return [];
  }
  const referenceMapping = _.chain(referenceObjects)
    .mapValues("dataField")
    .values()
    .uniq()
    .value();
  const dataItem = {};
  DEFAULT_VIEW_MODE.detailed.columnDefs.forEach((col) => {
    dataItem[col.field] = null;
  });
  return data.map((item) => {
    const newItem: any = { ...dataItem };
    Object.keys(item).forEach((key) => {
      const referenceItem = referenceList[key];
      const isReferenceObject = referenceMapping.includes(key);
      if (isReferenceObject) {
        const objdata = item[key];
        let referenceObject: any = Object.values(referenceObjects).filter(
          (item: any) => item.dataField === key
        )[0];
        const isBenchmarks = referenceObject.dataField.includes("Benchmark");
        (!!referenceList[referenceObject.keyField] || isBenchmarks) &&
          objdata.forEach((data) => {
            if (isBenchmarks) {
              referenceObject = Object.values(referenceObjects).filter(
                (item: any) => {
                  const { dataField, valueField, options } = item;
                  return (
                    dataField === key &&
                    Object.keys(options[valueField]).includes(
                      `${data[valueField]}`
                    )
                  );
                }
              )[0];
            }
            let { keyField, valueField, options, benchmarkType } =
              referenceObject;
            let fieldKey = data[keyField];
            if (isBenchmarks) {
              fieldKey = fieldKey.replace(Benchmark_Suffix, "");
              if (benchmarkType === "Analytics") {
                fieldKey += benchmarkType;
              }
            }
            !!data.Status &&
              (newItem[fieldKey] = isBenchmarks
                ? options[valueField][data[valueField]]
                : data[valueField]);
          });
      } else if (
        portfolio_toggle_datafields.includes(key) ||
        key === "Status"
      ) {
        newItem[key] = referenceItem[item[key]];
      } else {
        switch (key) {
          case "PortfolioManagerTeamName":
            let value = item[key] || null;
            newItem.PrimaryPortfolioManager = getPrimaryPortfolioManagerValue(
              value,
              referenceItem
            );
            newItem.PortfolioManagerMembers = getPrimaryPortfolioManagerValue(
              value,
              referenceItem,
              1
            );
            newItem[key] = value;
            break;
          case key.toLowerCase().includes("currency") ? key : "":
            newItem[key] = Object.values(referenceItem).find(
              (fieldValue: any) =>
                !!item[key] && fieldValue.includes(`- ${item[key]}`)
            );
            break;
          case "PortfolioTags":
            newItem[key] = _.join(_.map(item[key], "Name"), ", ");
            break;
          default:
            newItem[key] = item[key];
            break;
        }
      }
    });
    return newItem;
  });
};

export const getAllGridFields = (
  referenceList,
  referenceObjects,
  datafields?: any
) => {
  if (!referenceObjects && !referenceList) {
    return [];
  }
  let filter_dataFields = [];
  _.flatten(Object.values(datafields || portfolio_content_datafields)).forEach(
    (data) => {
      let datafields = [];
      data.datafields.forEach((datafield) => {
        if (excluded_filter_fields.includes(datafield)) {
          return;
        }
        const isReferenceObject =
          Object.keys(referenceObjects).includes(datafield);
        if (isReferenceObject) {
          const referenceObject: any = referenceObjects[datafield] || {};
          const isBenchmarks =
            !!referenceObject &&
            referenceObject.dataField.includes("Benchmark");
          (!!referenceList[referenceObject.keyField] || isBenchmarks) &&
            (datafields = datafields.concat(
              Object.values(
                ((isBenchmarks ? referenceObject.options : referenceList) ||
                  {})[referenceObject.keyField] || []
              )
            ));
        } else {
          datafields.push(datafield);
        }
      });
      filter_dataFields = filter_dataFields.concat(datafields);
    }
  );

  !datafields && filter_dataFields.splice(0, 0, "PortfolioTags");
  return _.uniq(filter_dataFields);
};

export const validateInputLength = (
  key: string,
  value: string | string[] | number
) => {
  let isValidationFailed = false;
  const isValidValueType =
    typeof value === "string" || typeof value === "number";
  const maxLength = portfolio_inputs_key_max_length_mapping[key];
  const isValidMaximumLength = typeof maxLength === "number";
  const isFixed = portfolio_inputs_key_fixed_length_mapping.includes(key);
  isValidValueType &&
    isValidMaximumLength &&
    (!isFixed
      ? value.toString().length > maxLength
      : !!value && value.toString().length !== maxLength) &&
    (isValidationFailed = true);
  return isValidationFailed;
};

export const createInputMaxLengthHint = (key: string, isNum = false) => {
  let hint = undefined;
  const maxLength = portfolio_inputs_key_max_length_mapping[key];
  const isValidMaximumLength = typeof maxLength === "number";
  isValidMaximumLength &&
    (hint = `${maxLength} ${isNum ? "Digits" : "Characters"} Long`);
  return hint;
};

export const checkFieldsMaxLength = (dataState, datafields?) => {
  const maxLengthFields =
    datafields || Object.keys(portfolio_inputs_key_max_length_mapping);
  return maxLengthFields.some(
    (key) => dataState[key] && validateInputLength(key, dataState[key])
  );
};

export const getPrimaryPortfolioManagerValue = (
  teamValue,
  referenceItem,
  index = 0
) => {
  const value =
    !!referenceItem && !!teamValue
      ? Object.values(referenceItem)
          .find((team: any) => team.includes(teamValue))
          .toString()
          .split(data_value_split)
          [index].trim()
      : null;
  return !!value && value !== "undefined" ? value : null;
};

export const getSplitValue = (teamValue, isCurrency = false, index = 1) => {
  const stringsArray = !!teamValue
    ? teamValue.split(isCurrency ? currency_data_value_split : data_value_split)
    : [];
  return !!stringsArray.length && stringsArray.length > index
    ? stringsArray[index].trim()
    : teamValue;
};

export const checkXreference = (dataState) => {
  return _.chain(xreference_DQ_key)
    .map((itemkey) => {
      return !!dataState[itemkey] ? dataState[itemkey] : "";
    })
    .uniq()
    .join("|")
    .value()
    .replace("Aladdin", "Blackrock");
};

export const getDataFieldTitle = (field) => {
  return (portfolio_key_name_mapping[field] || field).replaceAll("_", " ");
};

export const getSubOptions = (parentValue, referenceItem) => {
  let newReferenceItem = {};
  if (parentValue === "all") {
    Object.values(referenceItem).forEach((options: any) => {
      newReferenceItem = { ...newReferenceItem, ...options };
    });
  } else {
    newReferenceItem = referenceItem[parentValue] || {};
  }
  return newReferenceItem;
};

const compareStatus = (a, b) => {
  const status1 = _.invert(status_options)[a];
  const status2 = _.invert(status_options)[b];
  if (status1 < status2) {
    return -1;
  } else if (status1 > status2) {
    return 1;
  }
  return 0;
};

export const statusCompare = (a, b, dir) => {
  const correction = dir === "asc" ? 1 : -1;
  return correction * compareStatus(a.Status, b.Status);
};

export const getSpecialDisplayText = (
  str,
  referenceItem,
  type: "currency" | "benchmark"
) => {
  let newStr = str;
  switch (type) {
    case "currency":
      newStr = `${_.invert(referenceItem)[str]} - ${str}`;
      break;
    case "benchmark":
      newStr = `${str} (${referenceItem[str]})`;
      break;
    default:
      break;
  }
  return newStr;
};

export const getErrorMessage = (response) => {
  const { detail, errors } = response || {};
  let errormessage = detail || "";
  if (!errormessage && !!errors) {
    Object.keys(errors).forEach((field) => {
      errormessage += `${field} : ${errors[field]} `;
    });
  }
  !errormessage && (errormessage = defautlErrorMessage);
  return errormessage;
};

export const getDuplicates = (array) => {
  const uniques = (arr) => _.xor(...arr.map((a) => [a]));
  return _.xor(array, uniques(array));
};

export const getReferenceOptions = (
  referenceId,
  referenceList,
  referenceObjects
) => {
  let referenceItem =
    !!referenceList && !!referenceId
      ? referenceList[
          referenceId.includes("Tag") ? "PortfolioTagIds" : referenceId
        ]
      : null;
  let codeReferenceItem = null;
  !!referenceObjects &&
    Object.values(referenceObjects).forEach((referenceObject: any) => {
      const {
        options = null,
        keyField,
        valueField,
        codeKey,
      } = referenceObject || {};
      if (!!options && Object.values(options[keyField]).includes(referenceId)) {
        referenceItem = options[valueField];
        !!codeKey && (codeReferenceItem = options[codeKey]);
      }
    });
  return { referenceItem, codeReferenceItem };
};

export const getFilterRender = (
  referenceItem,
  type: "benchmark" | "currency" = "benchmark"
) => {
  return (li: ReactElement<HTMLLIElement>, itemProps: ListItemProps) => {
    const itemChildren = !!referenceItem ? (
      <span>
        {getSpecialDisplayText(itemProps.dataItem, referenceItem, type)}
      </span>
    ) : (
      <>{li.props.children}</>
    );
    return cloneElement(li, li.props, itemChildren);
  };
};

export const getGridFilterRender = (
  referenceItem,
  type: "benchmark" | "currency" = "benchmark"
) => {
  return (props) => {
    let { dataItem, ...others } = props;
    return (
      <li {...others}>
        {!!referenceItem
          ? getSpecialDisplayText(dataItem.name, referenceItem, type)
          : dataItem.name}
      </li>
    );
  };
};

export const getStatusOptions = () =>
  Object.values(_.omit(status_options, [status_options.Reactivate]));

export const checkValidBenchmark = (benchmark: string) =>
  !!benchmark && !Benchmark_DQ_Values.includes(benchmark);

export const getPortfolioManagerTeamOptions = (referenceItem) => {
  const newReferenceItem = {};
  !!referenceItem &&
    Object.keys(referenceItem).forEach((key) => {
      newReferenceItem[key] = getSplitValue(referenceItem[key], false, 2);
    });
  return newReferenceItem;
};
