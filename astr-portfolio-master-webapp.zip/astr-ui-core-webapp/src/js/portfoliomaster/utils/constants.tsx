import React from "react";
import { statusCompare } from "./utils";
import PortfolioMasterIndex from "../PortfolioMasterIndex";
import { dateFormatterUTCtoLocal } from "../../common/utils/utils";

export const APP_ID = "portfolioMaster";
export const APP_NAME = "Portfolio Master";
export const DEFAULT_CONTEXT_NAME = "portfoliomaster";
export const DEFAULT_HOST_PORT = "3002";
export const PM_URL_PARAMS = {
  portfolio: "portfolio",
  role: "role",
};
export const PM_ROUTERS = {
  home: {
    pageId: "home",
    path: "/",
    desc: APP_NAME,
    visable: true,
    auth: true,
    component: PortfolioMasterIndex,
    isLowerLaneOnly: false,
    entitlments: [],
  },
};
export const defaultSelectItem = "Please select";
export const defautlErrorMessage = "An error occurred, please try again later.";
export const DEV_SUPPORT_EMAIL = "Voya-IM-PortfolioMaster-Support@voya.com";

export const max_pageSize = 1000;

export const DEFAULT_PM_GRID_DEF = {
  sortable: true,
  initialSort: [
    {
      field: "Status",
      dir: "desc",
      compare: (a, b) => statusCompare(a, b, "desc"),
    },
    {
      field: "InceptionDate",
      dir: "desc",
    },
    {
      field: "CreatedOn",
      dir: "desc",
    },
  ],
  pageable: {
    buttonCount: 4,
    pageSizes: [50, 100, 500, "All"],
  },
  filterable: true,
  groupable: true,
  pageSize: 50,
  hasExpandToggle: true,
  hasExportExcel: true,
  exportFileName: "Portfolio Master",
  resizable: true,
  reorderable: false,
  hideColumn: true,
};

export const DEFAULT_SINGLE_GRID_DEF = {
  sortable: true,
  pageable: false,
  filterable: false,
  groupable: false,
  pageSize: 10,
  hasExpandToggle: false,
  hasExportExcel: false,
  resizable: true,
  reorderable: false,
  hideColumn: false,
};

export const home_screen_filterCheckbox = [
  {
    key: "Status_check",
    text: "Include closed portfolios",
    value: "Closed",
    isExclude: true,
    isReverse: true,
    isDefaultFilter: true,
  },
  {
    key: "LegalInvestmentManagerName_check",
    text: "Include externally managed portfolios",
    value: "External Manager",
    isExclude: true,
    isReverse: true,
    isDefaultFilter: true,
  },
];

export const Default_Filters = home_screen_filterCheckbox.filter(
  (item) => item.isDefaultFilter
);

export const Filter_Suffix = "_check";
export const data_value_split = " -$- ";
export const currency_data_value_split = " - ";

export const status_options = {
  WorkInProgress: "In Progress",
  OperationallyReady: "Operationally Ready",
  Active: "Active",
  Closed: "Closed",
  Reactivate: "Reactivate",
};

export const single_reference_ids = {
  PortfolioBenchmarks: ["Benchmarks", "AnalyticsBenchmarks"],
  PortfolioXReferences: ["PortfolioXReferenceCategoryName"],
  ShareClasses: ["ShareClassIdentifierName"],
};

export const entitlment_reference_object = [
  "PerformancePortfolioBenchmarks",
  "AnalyticsPortfolioBenchmarks",
  "PortfolioXReferences",
];

export const reference_data_fields_pair = {
  InvestmentStrategyName: "AssetClassName",
  SubVehicleName: "VehicleName",
};

export const Benchmark_Suffix = " Benchmark";
export const Benchmark_DQ_Values = ["Not Applicable", "No Benchmark"];

export const XReference_Split = " ";
export const XReference_DQ_fields = [
  "sga",
  "star",
  "oncore",
  "investone",
  "blackrock",
];

export const portfolio_required_datafields = [
  "PortfolioCode",
  "VehicleName",
  "PortfolioName",
  "SubVehicleName",
  "PortfolioTypeName",
  "AssetClassName",
  "ParentPortfolioCode",
  "InvestmentStrategyName",
];

export const portfolio_active_required_datafields = [
  "Status",
  "InceptionDate",
  "Primary",
  "PrimaryAnalytics",
  "ManagementStyleName",
  "Discretionary",
  "MultiSector",
  "PrimaryPortfolioManager",
  "PortfolioManagerMembers",
  "PortfolioManagerTeamName",
  "DomicileCountryName",
  "BaseCurrencyName",
  "IBORSystemName",
  "ABORSystemName",
  "InsuranceAccountingSystemName",
  "TradingSystemName",
  "PerformanceBookOfRecordName",
  "AladdinProcessingName",
  "FiscalYearEnd",
  "LotSelectionMethodName",
  "PrimaryAmortizationRuleName",
  "ShortTermDiscountAccrualFlag",
  "TaxAccountingMethodName",
  "TaxId",
  "LegalInvestmentManagerName",
  "RegulatoryStructureName",
  "SECDerivativeRule18f4",
  "ReportingCurrencyName",
  "FinanceAUMSourceName",
  "TransferAgentSystemName",
];

export const editable_for_WorkInProgress_only = ["PortfolioCode"];
export const disable_for_Edit_Mode = ["PortfolioCode", "Status"];
export const enable_for_Closed_only = ["LiquidationDate"];
export const varchar_regexp_fields = {
  PortfolioCode: /^[a-zA-Z0-9_-]+$/,
  LEINumber: /^[a-zA-Z0-9]+$/,
};

export const portfolio_toggle_datafields = [
  "Discretionary",
  "MultiSector",
  "ShortTermDiscountAccrualFlag",
  "ProxyVotingFlag",
  "SECDerivativeRule18f4",
  "ESGFlag",
  "ESGClientDirectedExclusion",
  "ESGFullIntegration",
  "ESGSustainability",
  "MASSFundOfFundsSystem",
  "VoyaSubAdvised",
  "EquityIPOAllowed",
  "SoftDollarsAllowed",
  "CommissionSharingAgreement",
  "CrossTradingAllowed",
  "DirectedBrokerage",
  "MFN",
  "PerformanceBasedFee",
  "LoadCashFlows",
  "NAICDesignations",
];

export const portfolio_date_datafields = [
  "InceptionDate",
  "LiquidationDate",
  "PerformanceInceptionDate",
  "PerformanceStartDate",
  "FiscalYearEnd",
];

export const portfolio_number_datafields = [];

export const ADGroup_mapping = {
  "AS-ASTR-PMAST-Operations": "Client Operations",
  "AS-ASTR-PMAST-ClientOperations": "Client Operations",
  "AS-ASTR-PMAST-Performance": "Performance",
  "AS-ASTR-PMAST-InvDataAnalytics": "Investment Data & Analytics",
  "AS-ASTR-PMAST-Product": "Product Management",
  "AS-ASTR-PMAST-Legal": "Legal",
  "AS-ASTR-PMAST-InvTeamFI": "Investment Team",
  "AS-ASTR-PMAST-Reporting": "Reporting",
  "AS-ASTR-PMAST-Finance": "Finance",
  "AS-ASTR-PMAST-Accounting": "Accounting",
  "AS-ASTR-PMAST-Compliance": "Compliance (Only derivatives and FX)",
  "AS-ASTR-PMAST-Risk": "Risk",
};

export const portfolio_key_name_mapping = {
  PortfolioCode: "Code",
  PortfolioName: "Name",
  PortfolioType: "Type",
  PortfolioTypeName: "Type",
  ParentPortfolio: "Parent Portfolio Code",
  ParentPortfolioCode: "Parent Portfolio Code",
  AssetClassName: "Asset Class",
  VehicleName: "Vehicle Type",
  SubVehicleName: "Sub-Vehicle",
  InceptionDate: "Inception Date",
  LiquidationDate: "Liquidation Date",
  Status: "Status",
  MultiSector: "MultiSector Indicator",
  Primary: "Primary Benchmark",
  Secondary: "Secondary Benchmark",
  Tertiary: "Tertiary Benchmark",
  PrimaryAnalytics: "Analytics (Risk) Benchmark",
  SecondaryAnalytics: "Secondary Analytics (Risk) Benchmark",
  InvestmentStrategyName: "Investment Strategy",
  PerformanceInceptionDate: "Performance Inception Date",
  PerformanceStartDate: "Performance Start Date",
  ManagementStyleName: "Management Style",
  Discretionary: "Discretionary",
  PrimaryPortfolioManager: "Primary Portfolio Manager Name",
  PortfolioManagerMembers: "Portfolio Management Team Members",
  PortfolioManagerTeamName: "Investment Team Name",
  CustodianBankName: "Custodian Bank Name",
  CustodianAccountNumber: "Custodian Account Number",
  BaseCurrencyName: "Base Currency",
  DomicileCountryName: "Portfolio Country of Domicile",
  IBORSystemName: "IBOR Source System",
  ABORSystemName: "ABOR Source System",
  InsuranceAccountingSystemName: "Insurance Accounting System",
  TradingSystemName: "OMS Trading System",
  PerformanceBookOfRecordName: "Performance Book of Record",
  AladdinProcessingName: "Aladdin Processing",
  FiscalYearEnd: "Fiscal Year End",
  LotSelectionMethodName: "Lot Selection Method",
  PrimaryAmortizationRuleName: "Primary Amortization/Accretion Rule",
  ShortTermDiscountAccrualFlag: "Short Term Discount Accrual Flag",
  TaxAccountingMethodName: "Tax (Withholding) Accounting Method",
  TaxId: "Tax ID",
  LEINumber: "LEI Number",
  RegulatoryStructureName: "Regulatory Structure (ERISA) Indicator",
  SECDerivativeRule18f4: "SEC Derivative Rule 18f-4",
  LegalInvestmentManagerName: "Legal Investment Manager",
  ReportingCurrencyName: "Reporting Currency Code",
  InsuranceLegalEntityGroupingName: "Insurance Legal Entity Grouping",
  ClientName: "Client Name",
  FinanceAUMSourceName: "Finance AUM Source",
  FinanceAUMAmountTypeName: "Finance AUM Amount Type",
  FinanceBusinessLineName: "Finance Business Line",
  ESGFlag: "ESG Flag",
  ESGClientDirectedExclusion: "ESG - Client Directed Exclusion",
  ESGFullIntegration: "ESG - Integration",
  ESGSustainability: "ESG - Sustainability Solutions",
  ESGSustainabilityObjectiveName: "ESG Sustainability Objective",
  Tag: "Name",
  PortfolioTags: "Tags",
  PortfolioTagIds: "Tag",
  Description: "Description",
  Team: "Team",
  CreatedBy: "Created By",
  CreatedOn: "Created On",
  ModifiedBy: "Modified By",
  ModifiedOn: "Modified On",
  PortfolioXReferenceCategoryName: "",
  Benchmarks: "",
  AnalyticsBenchmarks: "",
  ProxyVotingFlag: "Proxy Voting Flag",
  TransferAgentSystemName: "Transfer Agent System",
  MASSFundOfFundsSystem: "MASS Fund of Funds System",
  VoyaSubAdvised: "Voya Sub-Advised",
  LegalStructureName: "Legal Structure",
  RiskModelName: "Risk Model",
  EquityIPOAllowed: "Equity IPO/Secondaries Allowed",
  SoftDollarsAllowed: "Soft Dollars Allowed",
  CommissionSharingAgreement: "Commission Sharing Arrangement Allowed",
  CrossTradingAllowed: "Cross Trading Allowed",
  DirectedBrokerage: "Directed Brokerage",
  ComplianceCertification: "Compliance Certification",
  MFN: "MFN (Most Favored Nations)",
  PerformanceBasedFee: "Performance Based Fee",
  AccountingBasisName: "Accounting Basis",
  LoadCashFlows: "Load Cashflows",
  NAICDesignations: "NAIC Designations",
};

export const default_portfolio_content_view = "details";

export const portfolio_menuitems = [
  {
    text: "Details",
    key: "details",
    isEditable: true,
  },
  {
    text: "Operational",
    key: "operational",
    isEditable: true,
  },
  {
    text: "Performance",
    key: "performance",
    isEditable: true,
  },
  {
    text: "Accounting",
    key: "accounting",
    isEditable: true,
  },
  {
    text: "Compliance and Regulatory",
    key: "compliance",
    isEditable: true,
  },
  {
    text: "Risk",
    key: "risk",
    isEditable: true,
  },
  {
    text: "Alternate Identifiers",
    key: "alternate",
    isEditable: true,
  },
  {
    text: "Reporting",
    key: "reporting",
    isEditable: true,
  },
  {
    text: "Tags",
    key: "tags",
  },
  {
    text: "Form Generation",
    key: "form",
  },
];

export const portfolio_content_datafields = {
  details: [
    {
      title: "Core",
      owner: ["Business Implementation Team (Portfolio)"],
      datafields: [
        "PortfolioCode",
        "Status",
        "PortfolioName",
        "PortfolioTypeName",
        "ParentPortfolioCode",
        "VoyaSubAdvised",
        "VehicleName",
        "SubVehicleName",
        "InceptionDate",
        "LiquidationDate",
      ],
    },
    {
      title: "Investment attributes",
      owner: [
        "Business Implementation Team (Portfolio)",
        "Investment Data & Analytics",
      ],
      datafields: [
        "AnalyticsBenchmarks",
        "AssetClassName",
        "InvestmentStrategyName",
        "ManagementStyleName",
        "Discretionary",
      ],
    },
    {
      title: "Management team",
      owner: ["Investment Team"],
      datafields: [
        "PortfolioManagerTeamName",
        "PrimaryPortfolioManager",
        "PortfolioManagerMembers",
      ],
    },
  ],
  performance: [
    {
      title: "Core",
      owner: ["Investment Data & Analytics"],
      datafields: [
        "Benchmarks",
        "PerformanceInceptionDate",
        "PerformanceStartDate",
      ],
    },
  ],
  operational: [
    {
      title: "Core",
      owner: ["Business Implementation Team (Portfolio)", "Accounting"],
      datafields: [
        "DomicileCountryName",
        "BaseCurrencyName",
        "CustodianBankName",
        "CustodianAccountNumber",
      ],
    },
    {
      title: "System Specific",
      owner: [
        "Business Implementation Team (Portfolio)",
        "Performance",
        "Investment Data & Analytics",
      ],
      datafields: [
        "IBORSystemName",
        "ABORSystemName",
        "TransferAgentSystemName",
        "InsuranceAccountingSystemName",
        "TradingSystemName",
        "PerformanceBookOfRecordName",
        "AladdinProcessingName",
        "MASSFundOfFundsSystem",
      ],
    },
  ],
  accounting: [
    {
      title: "Insurance",
      owner: ["Accounting"],
      datafields: [
        "InsuranceLegalEntityGroupingName",
        "AccountingBasisName",
        "LoadCashFlows",
        "NAICDesignations",
      ],
    },
    {
      title: "Core",
      owner: ["Accounting"],
      datafields: [
        "FiscalYearEnd",
        "LotSelectionMethodName",
        "PrimaryAmortizationRuleName",
        "ShortTermDiscountAccrualFlag",
        "TaxAccountingMethodName",
      ],
    },
  ],
  compliance: [
    {
      title: "Compliance",
      owner: ["Business Implementation Team (Portfolio)", "Compliance"],
      datafields: [
        "TaxId",
        "LEINumber",
        "EquityIPOAllowed",
        "SoftDollarsAllowed",
        "CommissionSharingAgreement",
        "CrossTradingAllowed",
        "DirectedBrokerage",
        "ComplianceCertification",
      ],
    },
    {
      title: "Regulatory",
      owner: ["Legal"],
      datafields: [
        "LegalInvestmentManagerName",
        "RegulatoryStructureName",
        // "LegalStructureName",
      ],
    },
    {
      title: "Active Ownership",
      owner: ["Active Ownership"],
      datafields: ["ProxyVotingFlag"],
    },
  ],
  risk: [
    {
      title: "Risk",
      owner: ["Risk" /*, "Investment Data & Analytics"*/],
      datafields: ["SECDerivativeRule18f4" /*, "RiskModelName"*/],
    },
  ],
  alternate: [
    {
      title: "Alternate identifiers",
      owner: [
        "Business Implementation Team (Portfolio)",
        "Investment Data & Analytics",
      ],
      datafields: ["PortfolioXReferenceCategoryName"],
    },
  ],
  reporting: [
    {
      title: "Core",
      owner: ["Accounting" /*, "Business Implementation Team (Portfolio)"*/],
      datafields: ["ReportingCurrencyName" /*, "ClientName"*/, "MultiSector"],
    },
    {
      title: "Finance",
      owner: ["Finance", "Product Management"],
      datafields: [
        "FinanceAUMSourceName",
        "FinanceAUMAmountTypeName",
        "FinanceBusinessLineName",
        "MFN",
        "PerformanceBasedFee",
      ],
    },
    {
      title: "ESG Attributes",
      owner: ["Investment Team"],
      datafields: [
        "ESGFlag",
        "ESGClientDirectedExclusion",
        "ESGFullIntegration",
        "ESGSustainability",
        "ESGSustainabilityObjectiveName",
      ],
    },
  ],
};

export const DEFAULT_VIEW_MODE = {
  simple: {
    columnDefs: [
      { field: "Status", width: "150px" },
      { field: "PortfolioCode", width: "150px" },
      { field: "portfolioName", width: "500px" },
      {
        field: "InvestmentStrategyName",
      },
      {
        field: "VehicleName",
      },
    ],
  },
  detailed: {
    columnDefs: [
      { field: "Status", width: "160px" },
      {
        field: "InceptionDate",
        filter: "date",
        width: "110px",
      },
      { field: "PortfolioCode", width: "120px" },
      { field: "PortfolioName", width: "320px" },
      {
        field: "VehicleName",
        width: "200px",
      },
      {
        field: "SubVehicleName",
        width: "150px",
      },
      {
        field: "AssetClassName",
        width: "120px",
      },
      {
        field: "InvestmentStrategyName",
        width: "300px",
      },
      {
        field: "Primary",
        width: "400px",
      },
      {
        field: "PrimaryAnalytics",
        width: "400px",
      },
      {
        field: "PortfolioManagerTeamName",
        width: "200px",
      },
      {
        field: "PortfolioTypeName",
        width: "100px",
      },
      {
        field: "BaseCurrencyName",
        width: "100px",
      },
      {
        field: "VoyaSubAdvised",
        width: "100px",
      },
      {
        field: "CreatedOn",
        filter: "date",
        width: "110px",
      },
    ],
  },
};

export const tags_columnDefs = [
  { field: "Name", title: "Tag name" },
  { field: "PortfolioTagDescription", title: "Description" },
  {
    field: "ADGroupName",
    title: "Team",
    cell: (props) => {
      return (
        <td>
          {ADGroup_mapping[props.dataItem.ADGroupName] ||
            props.dataItem.ADGroupName}
        </td>
      );
    },
  },
  {
    field: "ModifiedBy",
    title: "Last updated by",
  },
  {
    field: "ModifiedOn",
    title: "Last update date",
    type: "date",
    cell: (props) => {
      return <td>{dateFormatterUTCtoLocal(props.dataItem.ModifiedOn)}</td>;
    },
  },
];

export const form_generation_columnDefs = [
  { field: "formName", title: "Name" },
  {
    field: "LastCompletedTransmissionTimestamp",
    title: "Last Completed Transmission Timestamp",
    cell: (props) => {
      return (
        <td>
          {dateFormatterUTCtoLocal(
            props.dataItem.Job[props.dataItem.formType]
              .LastCompletedTransmissionTimestamp,
            false
          )}
        </td>
      );
    },
  },
];

export const form_generation_data = [
  { formName: "IMDS Setup Form", formType: "IMDS", isDownstream: true },
  { formName: "DMI Setup Form", formType: "DMI", isDownstream: true },
  // { formName: "CSS2 Setup Form", formType: "normal" },
  { formName: "OneStop Setup Form", formType: "OneStop" },
  // { formName: "FXALL Setup Form", formType: "normal" },
  // { formName: "FOF (MASS) Setup Form", formType: "normal" },
  { formName: "SGA Setup Form", formType: "SGA" },
  { formName: "Aladdin Setup Form", formType: "Aladdin" },
];

export const excluded_filter_fields = [];

export const ESG_DQ_keys = [
  "ESGClientDirectedExclusion",
  "ESGFullIntegration",
  "ESGSustainability",
];

export const ABOR_DQ_key = ["Separate Account"];
export const FBL_DQ_Vehicle_key = ["Mutual Fund"];
export const PV_DQ_Vehicle_key = ["Mutual Fund", "Trust Fund"];
export const TAS_Inst_DQ_Sub_Vehicle_key = [
  "Collective Investment Trust",
  "Common Trust Fund",
  "Stable Value - Stabilizer",
];
export const TAS_Retail_DQ_Sub_Vehicle_key = [
  "529 Option",
  "US Mutual Fund",
  "US Listed Closed-End Fund",
  "Variable Portfolio",
  "VACS",
];
export const Shareholder_ID_DQ_Vehicle_key = [];

export const xreference_DQ_key = [
  "IBORSystemName",
  "ABORSystemName",
  "InsuranceAccountingSystemName",
  "TradingSystemName",
];

export const portfolio_inputs_key_max_length_mapping = {
  PortfolioCode: 10,
  PortfolioName: 50,
  CustodianAccountNumber: 20,
  LEINumber: 20,
  TaxId: 50,
  ComplianceCertification: 100,
  "SGA Account Number": 35,
  "STAR Account Number": 35,
  "Blackrock Identifier": 35,
  "Shareholder ID": 35,
  "InvestOne Account Number": 35,
  "OnCore Account Number": 35,
};

export const portfolio_inputs_key_fixed_length_mapping = ["LEINumber"];

export const Aladdin_form_fields = [
  "PortfolioCode",
  "PortfolioName",
  "PortfolioTypeName",
  "InceptionDate",
  "VehicleName",
  "Primary",
  "PrimaryAnalytics",
  "SecondaryAnalytics",
  "AssetClassName",
  "InvestmentStrategyName",
  "PrimaryPortfolioManager",
  "PortfolioManagerMembers",
  "PortfolioManagerTeamName",
  "DomicileCountryName",
  "BaseCurrencyName",
  "CustodianBankName",
  "CustodianAccountNumber",
  "IBORSystemName",
  "AladdinProcessingName",
  "TaxId",
  "RegulatoryStructureName",
  "SECDerivativeRule18f4",
  "InvestOne Account Number",
  "SGA Account Number",
];

export const Aladdin_form_dq_fields = ["AladdinProcessingName"];

export const SGA_form_fields = [
  "PortfolioCode",
  "PortfolioName",
  "SGA Account Number",
  "CustodianBankName",
  "CustodianAccountNumber",
  "InvestOne Account Number",
  "DomicileCountryName",
  "BaseCurrencyName",
  "TaxId",
  "FiscalYearEnd",
  "PrimaryAmortizationRuleName",
  "InceptionDate",
  "VehicleName",
  "InsuranceAccountingSystemName",
  "LotSelectionMethodName",
  "ShortTermDiscountAccrualFlag",
  "TaxAccountingMethodName",
  "TransferAgentSystemName",
];

export const SGA_form_dq_fields = [
  "DomicileCountryName",
  "BaseCurrencyName",
  "CustodianAccountNumber",
  "TransferAgentSystemName",
  "InsuranceAccountingSystemName",
  "FiscalYearEnd",
  "LotSelectionMethodName",
  "PrimaryAmortizationRuleName",
  "ShortTermDiscountAccrualFlag",
  "TaxAccountingMethodName",
  "TaxId",
  "InvestOne Account Number",
  "SGA Account Number",
];

export const IMDS_form_dq_fields = ["BaseCurrencyName"];

export const DMI_form_dq_fields = ["IBORSystemName", "FinanceAUMSourceName"];

export const OneStop_form_fields = [
  "PortfolioCode",
  "PortfolioName",
  "ParentPortfolioCode",
  "PortfolioTypeName",
  "Status",
  "InceptionDate",
  "LiquidationDate",
  "VehicleName",
  "AssetClassName",
  "InvestmentStrategyName",
  "ManagementStyleName",
  "PrimaryPortfolioManager",
  "PortfolioManagerMembers",
  "PortfolioManagerTeamName",
  "Primary",
  "Secondary",
  "Tertiary",
  "PerformanceInceptionDate",
  "PerformanceStartDate",
  "PerformanceBookOfRecordName",
  "BaseCurrencyName",
  "IBORSystemName",
  "ABORSystemName",
  "TransferAgentSystemName",
  "TaxAccountingMethodName",
  "ReportingCurrencyName",
  "SGA Account Number",
  "InvestOne Account Number",
  "Blackrock Identifier",
  "Shareholder ID",
  "SubVehicleName",
  "PerformanceBasedFee",
  // "LegalStructureName",
];

export const OneStop_form_dq_fields = [];

export const Snap_Shot_Fields = ["InvestmentStrategyName", "AssetClassName"];

export const Snap_Shot_Audit_Fields = [
  "ModifiedOn",
  "ModifiedBy",
  "CreatedOn",
  "CreatedBy",
];
