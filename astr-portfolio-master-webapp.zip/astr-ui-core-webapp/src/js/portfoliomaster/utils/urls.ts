export const context_prefix = "v1";
export const backend_port = "";
export const backend_protocol = "https:";
export const backend_hosts = {
  // dev: "astr-api-dev.iam.intranet",
  test: "astr-api-test.iam.intranet",
  // prod: "astr-api.iam.intranet",
  dev: "vim-zue2-dev-astr-mstr-001.vimasezue2intdev002.appserviceenvironment.net",
  // test: "vim-zue2-test-astr-mstr-001.vimasezue2inttest002.appserviceenvironment.net",
  prod: "vim-zue2-prod-astr-mstr-001.vimasezue2intprod001.appserviceenvironment.net",
};

export const entitlementUrl = "/entitlements/PortfolioMaster";
export const settingUrl = "/settings/PortfolioMaster";
export const referenceDataUrl = "/portfolios/referencefields";
export const singleReferenceDataUrl =
  "/portfolios/_referenceId_/referencefields";
export const allPortfolioUrl = "/portfolios";
export const singlePortfolioUrl = "/portfolios/_id_";
export const downstreamUrl = "/portfolios/_id_/loadtodownstream/_downstream_";
