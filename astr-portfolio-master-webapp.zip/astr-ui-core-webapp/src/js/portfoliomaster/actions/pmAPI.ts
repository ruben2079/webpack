import { get, post } from "../../common/utils/api";
import * as urls from "../utils/urls";
import { getAppInfo, getEnv, isLocal } from "../../common/utils/utils";
import { DEFAULT_CONTEXT_NAME } from "../utils/constants";

const env = getEnv();
const localEnv = isLocal();
const host_prefix = localEnv ? "" : urls.backend_hosts[env];
const directUrl_props = { directUrl: !localEnv };

const getBackendUrl = (
  url: string,
  defaultContext: string,
  param?: string
): string => {
  const appInfo = getAppInfo(defaultContext);
  const context = localEnv ? "/" : appInfo.contextPrefix || appInfo.pathname;

  let apiUrl = `${context}${urls.context_prefix}${url}`;

  !!param &&
    (apiUrl += `${apiUrl.includes("?") ? "&" : "?"}${
      param.startsWith("?") || param.startsWith("&") ? param.slice(1) : param
    }`);

  if (!localEnv) {
    apiUrl = `${window.location.protocol}//${window.location.hostname}${
      !!urls.backend_port ? `:${urls.backend_port}` : ""
    }${apiUrl}`;
  }

  return apiUrl;
};

const getDirectUrl = (url: string, param) => {
  return directUrl_props.directUrl
    ? `${urls.backend_protocol || window.location.protocol}//${host_prefix}/${
        urls.context_prefix
      }${url}`
    : getBackendUrl(url, DEFAULT_CONTEXT_NAME, param);
};

const getCall = (url: string, payload: any = {}) =>
  get(getDirectUrl(url, payload.param), directUrl_props);

const postCall = (url: string, payload) =>
  post(getDirectUrl(url, payload.param), payload);

export const getPMEntitlement = () => getCall(urls.entitlementUrl);

export const getUserSettings = () => getCall(urls.settingUrl);

export const updateUserSettings = (userSettings: any) =>
  postCall(urls.settingUrl, {
    method: "PUT",
    body: userSettings,
    ...directUrl_props,
  });

export const getAllPortfolio = () => getCall(urls.allPortfolioUrl);

export const getReferenceData = () => getCall(urls.referenceDataUrl);

export const getSinglePortfolio = (Id: string) =>
  getCall(urls.singlePortfolioUrl.replace("_id_", Id));

export const createPortfolio = (dataItem: string) =>
  postCall(urls.allPortfolioUrl, {
    body: dataItem,
    ...directUrl_props,
  });

export const updatePortfolio = (dataItem: any) =>
  postCall(urls.singlePortfolioUrl.replace("_id_", dataItem.Id), {
    method: "PUT",
    body: dataItem,
    ...directUrl_props,
  });

export const getSingleReferenceData = (referenceId: string) =>
  getCall(urls.singleReferenceDataUrl.replace("_referenceId_", referenceId));

export const updateReference = (referenceId: string, dataItem: any) =>
  !!dataItem.Id
    ? postCall(`${urls.referenceDataUrl}/${referenceId}/${dataItem.Id}`, {
        method: "PUT",
        body: dataItem,
        ...directUrl_props,
      })
    : postCall(`${urls.referenceDataUrl}/${referenceId}`, {
        body: dataItem,
        ...directUrl_props,
      });

export const fetchDownStream = (portfolioId: string, formType: string) =>
  postCall(
    urls.downstreamUrl
      .replace("_id_", portfolioId)
      .replace("_downstream_", formType),
    {
      method: "PUT",
      ...directUrl_props,
    }
  );
