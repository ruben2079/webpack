import { PMState } from "../reducers/pmReducer";
import * as pmTypes from "./pmAction.type";

export const initPM = (): ActionType => ({ type: pmTypes.INIT_PM });

export const tiggerLoadingMask = (isShow: boolean): ActionType => ({
  type: pmTypes.TIGGER_LOADING_MASK,
  payload: isShow,
});

export const setPMState = (payload: PMState): ActionType => ({
  type: pmTypes.SET_PM_STATE,
  payload,
});

export const fetchAllPorfolio = (isCoreDataOnly?: boolean): ActionType => ({
  type: pmTypes.FETCH_ALL,
  payload: { isCoreDataOnly },
});

export const switchScreen = (screen: string, options?: any): ActionType => ({
  type: pmTypes.SWITCH_SCREEN,
  payload: {
    screen,
    options,
  },
});

export const getSinglePortfolio = (
  id: number | string,
  portfolioCode: string
): ActionType => ({
  type: pmTypes.GET_SINGLE_PORTFOLIO,
  payload: { id, portfolioCode },
});

export const openNewPortfolio = (
  isOpen: boolean,
  portfolioCode?: string,
  isClone?: boolean
): ActionType => ({
  type: pmTypes.OPEN_NEW_PORTFOLIO,
  payload: {
    isNewPortfolioOpen: isOpen,
    portfolioCode,
    isClone,
  },
});

export const createPortfolio = (dataItem: any): ActionType => ({
  type: pmTypes.CREATE_NEW_PORTFOLIO,
  payload: dataItem,
});

export const updatePortfolio = (dataItem: any): ActionType => ({
  type: pmTypes.UPDATE_PORTFOLIO,
  payload: dataItem,
});

export const filterPortfolio = (filters: FilterItem[]): ActionType => ({
  type: pmTypes.FILTER_PORTFOLIO,
  payload: filters,
});

export const updateNotification = (
  notification: NotificationItem
): ActionType => ({
  type: pmTypes.UPDATE_NOTIFICATION,
  payload: notification,
});

export const updateReference = (
  referenceId: string,
  dataItem: any,
  isUpdatePorfolio: boolean,
  isUpdatePorfolioOnly?: boolean
): ActionType => ({
  type: pmTypes.UPDATE_REFERENCE,
  payload: {
    referenceId,
    dataItem,
    isUpdatePorfolio,
    isUpdatePorfolioOnly,
  },
});

export const fetchDownStream = (
  portfolioId: string,
  formType: string
): ActionType => ({
  type: pmTypes.FETCH_DOWNSTREAM,
  payload: {
    portfolioId,
    formType,
  },
});

export const updateUserSettings = (userSettings: any): ActionType => ({
  type: pmTypes.UPDATE_USER_SETTINGS,
  payload: userSettings,
});
