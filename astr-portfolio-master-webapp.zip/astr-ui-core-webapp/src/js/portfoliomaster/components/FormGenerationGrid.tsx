import React, { FC, useMemo, useState } from "react";
import classNames from "classnames";
import _ from "lodash";

import DataGrid from "../../common/components/DataGrid";
import * as constants from "../utils/constants";
import StyledDialog from "../../common/components/StyledDialog";
import {
  checkRequiredFields,
  getAllGridFields,
  getDataFieldTitle,
  getRequiredFieldsBasedonStatus,
} from "../utils/utils";

import styles from "./FormGenerationGrid.module.scss";

const { form_grid, view_title, error_info } = styles;

interface IFGGProps {
  className?: string;
  viewItem: any;
  referenceList?: any;
  referenceObjects?: any;
  portfolioData?: any;
  isReadOnly?: boolean;
  switchScreen: (screen: string, options?: any) => void;
  downStreamTigger: (formType: string) => void;
}

type FGGProps = IFGGProps;

const FormGenerationGrid: FC<FGGProps> = (props: FGGProps) => {
  const {
    className,
    viewItem,
    portfolioData = {},
    referenceList = null,
    referenceObjects = null,
    isReadOnly = true,
    switchScreen,
    downStreamTigger,
  } = props;
  const [visibleFormDialog, setVisibleFormDialog] = useState(false);
  const [selectedForm, setSelectedForm] = useState(null);
  const [exportCallback, setExportCallback] = useState(null);
  const [dqResult, setDQResult] = useState({ isFailed: true, errorFields: [] });

  const formGenerationGrid_cn = classNames(form_grid, className);

  const toggleDialog = () => {
    setVisibleFormDialog(!visibleFormDialog);
    if (!!visibleFormDialog) {
      setSelectedForm(null);
    }
  };

  const coreFields = useMemo(() => {
    const filter_dataFields = getAllGridFields(
      referenceList,
      referenceObjects,
      _.pick(constants.portfolio_content_datafields, ["details"])
    );
    return filter_dataFields.map((field) => ({
      field,
      title: getDataFieldTitle(field),
    }));
  }, []);

  const getExportFields = (formType) => {
    let exportFields = [];
    switch (formType) {
      case "normal":
        exportFields = exportFields.concat(coreFields);
        break;
      default:
        exportFields = exportFields.concat(
          constants[`${formType}_form_fields`].map((field) => ({
            field,
            title: getDataFieldTitle(field),
          }))
        );
        break;
    }
    return exportFields;
  };

  const hasEditAccess = !dqResult.isFailed || !isReadOnly;

  const { PortfolioSubscribers } = portfolioData;
  const existingJob = {};
  constants.form_generation_data.forEach((form) => {
    const job = PortfolioSubscribers.find(
      (item) => item.DownstreamSystemName === form.formType
    );
    existingJob[form.formType] = {};
    if (!!job) {
      const transmission = !!job.PortfolioTransmissions
        ? job.PortfolioTransmissions[job.PortfolioTransmissions.length - 1]
        : null;
      existingJob[form.formType] = !!transmission
        ? {
            Status: job.Status,
            LastCompletedTransmissionTimestamp:
              job.LastCompletedTransmissionTimestamp,
          }
        : {};
    }
  });

  return (
    <>
      <DataGrid
        className={formGenerationGrid_cn}
        title={<div className={view_title}>{viewItem.text}</div>}
        gridData={constants.form_generation_data.map((data) => ({
          ...data,
          ...portfolioData,
          Job: existingJob,
        }))}
        gridDef={{
          ...constants.DEFAULT_SINGLE_GRID_DEF,
          rowExportFn: true,
          rowExportFnButtonTextRender: (dataItem) =>
            dataItem.isDownstream ? "Load Downstream" : "Generate form",
          rowExportFnButtonDisabled: (dataItem) =>
            !!existingJob[dataItem.formType].Status,
          rowExportFieldsGenerator: (dataItem, cb) => {
            setSelectedForm(dataItem);
            setExportCallback(() => cb);
            setDQResult(
              checkRequiredFields(
                portfolioData,
                getRequiredFieldsBasedonStatus(
                  portfolioData,
                  true,
                  referenceObjects,
                  false,
                  constants[`${dataItem.formType}_form_dq_fields`]
                )
              )
            );
            toggleDialog();
          },
        }}
        columnDefs={constants.form_generation_columnDefs}
      />
      <StyledDialog
        title={"Generate Form"}
        isOpen={visibleFormDialog}
        onClose={toggleDialog}
        saveText={!dqResult.isFailed ? "Ok" : "Edit Portfolio"}
        disableSave={!hasEditAccess}
        errorMessage={
          !hasEditAccess ? "Please contact Admin to update the portfolio." : ""
        }
        onSave={() => {
          if (!dqResult.isFailed) {
            if (selectedForm.isDownstream) {
              downStreamTigger && downStreamTigger(selectedForm.formType);
            } else {
              exportCallback(getExportFields(selectedForm.formType));
            }
            toggleDialog();
          } else {
            switchScreen("portfolio", {
              portfolioCode: portfolioData.PortfolioCode,
              isEditMode: true,
              feedFormName: selectedForm.formType,
            });
          }
        }}
      >
        <div>
          {!dqResult.isFailed ? (
            `Confirm ${
              !!selectedForm && !!selectedForm.isDownstream
                ? "feed downstream"
                : "generate"
            } form for ${!!selectedForm && selectedForm.formType}`
          ) : (
            <>
              <div>Missing data for below data fields:</div>
              <div className={error_info}>
                {dqResult.errorFields.map(
                  (field, index) =>
                    `${getDataFieldTitle(field)}${
                      index < dqResult.errorFields.length - 1 ? ", " : ""
                    }`
                )}
              </div>
            </>
          )}
        </div>
      </StyledDialog>
    </>
  );
};

export default FormGenerationGrid;
