import React, { FC } from "react";
import classNames from "classnames";

import { getDataFieldTitle, getStatusClass } from "../utils/utils";
import * as constants from "../utils/constants";
import { dateFormatterUTCtoLocal } from "../../common/utils/utils";

import styles from "./PortfolioSnapShot.module.scss";

const { snap_shot, portfolio_info, info_title } = styles;

interface IPSSProps {
  className?: string;
  gridMeta: any[];
  isReadOnly?: boolean;
  isEditMode?: boolean;
  feedFormName?: string;
  portfolioData?: any;
  children?: any;
  switchScreen?: (screen: string, params: any) => void;
}

type PSSProps = IPSSProps;

const PortfolioSnapShot: FC<PSSProps> = (props: PSSProps) => {
  const {
    className,
    gridMeta = [],
    portfolioData = {},
    isEditMode = false,
    feedFormName = null,
    children,
    switchScreen,
  } = props;
  const {
    PortfolioName,
    PortfolioCode,
    Status,
    PortfolioTypeName,
    ParentPortfolioCode,
  } = portfolioData;
  const PortfolioType = PortfolioTypeName || "";
  const isParent = PortfolioType === "Parent" || PortfolioType === "Master";
  const isSleeve = PortfolioType === "Sleeve" && !!ParentPortfolioCode;
  const subPortfolios = isSleeve
    ? !!ParentPortfolioCode
      ? [ParentPortfolioCode]
      : []
    : gridMeta
        .filter((item) => item.ParentPortfolioCode === PortfolioCode)
        .map((item) => item.PortfolioCode);

  const portfolioSnapShot = classNames(snap_shot, className);

  const createInfoItem = (fieldList) =>
    fieldList.map((field) => {
      const text = portfolioData[field];
      return (
        <span key={`Snap_Shot_${field}`}>
          <div className={info_title}>{getDataFieldTitle(field)}</div>
          <div>
            {!!text
              ? field.includes("On")
                ? dateFormatterUTCtoLocal(text)
                : text
              : ""}
          </div>
        </span>
      );
    });

  return (
    <div className={portfolioSnapShot}>
      <div className={portfolio_info}>
        <div>
          <h2>{`${
            isEditMode
              ? `Edit ${!!feedFormName ? ` for ${feedFormName} Form` : ""} - `
              : ""
          }${PortfolioName}`}</h2>
          <span className={classNames("portfolio_code", "disabled")}>
            {PortfolioCode}
          </span>
          <span className={getStatusClass(Status)}>{Status}</span>
        </div>
        <div>{createInfoItem(constants.Snap_Shot_Fields)}</div>
        <div>{createInfoItem(constants.Snap_Shot_Audit_Fields)}</div>
        {(isParent || isSleeve) && !!subPortfolios.length && (
          <div>
            <span className={info_title}>{`${
              isParent ? "Sleeve" : "Parent"
            }:`}</span>
            {subPortfolios.map((subPortfolio, index) => (
              <span
                key={`${subPortfolio}_${index}`}
                className={classNames("portfolio_code")}
                onClick={() =>
                  switchScreen("portfolio", {
                    portfolioCode: subPortfolio,
                  })
                }
              >
                {subPortfolio}
              </span>
            ))}
          </div>
        )}
      </div>
      {children}
    </div>
  );
};

export default PortfolioSnapShot;
