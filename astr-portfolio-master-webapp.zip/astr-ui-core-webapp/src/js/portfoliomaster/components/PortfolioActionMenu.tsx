import React, { FC } from "react";
import classNames from "classnames";
import { moreVerticalIcon } from "@progress/kendo-svg-icons";
import { Menu } from "@progress/kendo-react-layout";
import _ from "lodash";

import {
  checkRequiredFields,
  getNextStatus,
  getRequiredFieldsBasedonStatus,
  getStatusClass,
} from "../utils/utils";
import { status_options } from "../utils/constants";

import styles from "./PortfolioActionMenu.module.scss";

const { action_menu } = styles;

interface IPAMProps {
  className?: string;
  entitlement?: any;
  portfolioData?: any;
  hasEdit?: boolean;
  referenceObjects: any;
  onSelect: (action: string, dataItem) => void;
}

type PAMProps = IPAMProps;

const PortfolioActionMenu: FC<PAMProps> = (props: PAMProps) => {
  const {
    className,
    hasEdit = true,
    entitlement = {},
    portfolioData,
    referenceObjects,
    onSelect,
  } = props;
  const { Status = status_options.WorkInProgress } = portfolioData;
  const portfolioActionMenu_cn = classNames(action_menu, className);

  const menuitems = [
    {
      text: "",
      svgIcon: moreVerticalIcon,
      items: [],
    },
  ];

  const createStatusMenuItem = (status: string) => {
    return {
      text: status,
      render: () => {
        const nextStatus = status;
        return status !== status_options.Reactivate ? (
          <>
            Change status to
            <div
              className={classNames(
                "portfolio_status",
                getStatusClass(nextStatus)
              )}
            >
              {nextStatus}
            </div>
          </>
        ) : (
          status
        );
      },
    };
  };
  if (entitlement?.CanApprove) {
    getNextStatus(Status).map((status) => {
      let requiredFields = getRequiredFieldsBasedonStatus(
        {
          ...portfolioData,
          Status: status,
        },
        false,
        referenceObjects
      );

      status === status_options.Closed &&
        (requiredFields = _.without(requiredFields, "LiquidationDate"));

      return (
        (status === status_options.Reactivate ||
          !checkRequiredFields(portfolioData, requiredFields).isFailed) &&
        menuitems[0].items.push(createStatusMenuItem(status))
      );
    });
  }

  !!hasEdit && menuitems[0].items.push({ text: "Edit" });
  if (entitlement?.CanSetup) {
    menuitems[0].items.push({ text: "Clone" });
  }

  return (
    !!menuitems[0].items.length && (
      <Menu
        items={menuitems}
        className={portfolioActionMenu_cn}
        onSelect={(e) => onSelect(e.item.text, e.item)}
      ></Menu>
    )
  );
};

export default PortfolioActionMenu;
