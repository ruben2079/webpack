import React, { FC, useEffect, useMemo, useState } from "react";
import classNames from "classnames";
import { DropDownList } from "@progress/kendo-react-dropdowns";
import { DatePicker } from "@progress/kendo-react-dateinputs";
import { SvgIcon } from "@progress/kendo-react-common";
import {
  infoCircleIcon,
  trackChangesRejectIcon,
} from "@progress/kendo-svg-icons";
import _ from "lodash";

import * as constants from "../utils/constants";
import {
  checkAccessibility,
  checkFieldsMaxLength,
  checkParentPortfolio,
  checkRequiredFields,
  checkValidBenchmark,
  checkXreference,
  createInputMaxLengthHint,
  getDataFieldTitle,
  getFilterRender,
  getSubOptions,
  getNextStatus,
  getPortfolioManagerTeamOptions,
  getPrimaryPortfolioManagerValue,
  getRequiredFieldsBasedonStatus,
  getSpecialDisplayText,
  getStatusClass,
  validateInputLength,
} from "../utils/utils";
import { dateFormatterUTCtoLocal } from "../../common/utils/utils";
import ValidatedInput from "../../common/components/ValidatedInput";

import styles from "./PortfolioInfoPanel.module.scss";

const {
  container,
  panel_title,
  field_content,
  field_item,
  upper_case,
  required_field,
  error_field,
  editmode_field_item,
  not_editable,
} = styles;

interface IPIPProps {
  className?: string;
  contentView: string;
  isReadOnly?: boolean;
  isEditMode?: boolean;
  feedFormName?: string;
  datafields?: any[];
  portfolioData?: any;
  referenceList?: any;
  referenceObjects?: any;
  entitlement?: any;
  onPortfolioClick?: (portfolioCode: string) => void;
  onStateChange?: (state: any) => void;
}

type PIPProps = IPIPProps;

const PortfolioInfoPanel: FC<PIPProps> = (props: PIPProps) => {
  const {
    className,
    datafields,
    contentView,
    isReadOnly = false,
    isEditMode = false,
    feedFormName = null,
    portfolioData = {},
    referenceList,
    referenceObjects = null,
    entitlement,
    onPortfolioClick,
    onStateChange,
  } = props;

  const [dataState, setDataState] = useState(null);

  const portfolioInfoPanel_cn = classNames(container, className);

  useEffect(() => {
    const dataState = { ...portfolioData };
    datafields.forEach((fieldItem) => {
      fieldItem.datafields.forEach((field) => {
        const key = field;
        !Object.keys(dataState).includes(key) &&
          !Object.keys(referenceObjects).includes(key) &&
          (dataState[key] = null);
      });
    });
    setDataState(dataState);
  }, [portfolioData, isEditMode]);

  const requiredFields = useMemo(
    () =>
      getRequiredFieldsBasedonStatus(
        dataState,
        !!feedFormName,
        referenceObjects,
        !!dataState &&
          !!portfolioData &&
          dataState.Status === portfolioData.Status,
        !!feedFormName ? constants[`${feedFormName}_form_dq_fields`] : null
      ),
    [dataState]
  );

  const onUpdateValue = (data: any) => {
    let newState = {
      ...dataState,
      ...data,
    };
    !checkParentPortfolio(newState.PortfolioTypeName) &&
      (newState = { ...newState, ParentPortfolioCode: null });
    portfolioData.Status === constants.status_options.Active &&
      newState.Status === constants.status_options.Active &&
      (newState = {
        ...newState,
        LiquidationDate: null,
      });
    portfolioData.Status === constants.status_options.Closed &&
      newState.Status === constants.status_options.Reactivate &&
      (newState = {
        ...newState,
        LiquidationDate: null,
        Status: constants.status_options.WorkInProgress,
      });

    //DQ default value
    if (
      !newState.FinanceAUMSourceName ||
      newState.FinanceAUMSourceName === "Do Not Load"
    ) {
      newState.FinanceBusinessLineName = null;
    }

    onStateChange && onStateChange(newState);
    setDataState(newState);
  };

  const onValueChange = (event, type, key) => {
    let value = event.target.value;
    const defaultItem = key !== "Status" ? constants.defaultSelectItem : "";
    value = value !== defaultItem ? value : null;
    type === "date" && (value = !!value ? value.toISOString() : value);
    let newItem: any = {
      [key]: value,
    };

    //DQ Checker
    if (
      key === "CustodianBankName" &&
      (!value || value === "No Custodian Access")
    ) {
      dataState.CustodianAccountNumber = null;
    }

    if (key === "VehicleName" && constants.ABOR_DQ_key.includes(value)) {
      dataState.ABORSystemName = "Not Applicable";
      dataState["InvestOne Account Number"] = null;
    }

    if (
      key === "SubVehicleName" &&
      constants.TAS_Inst_DQ_Sub_Vehicle_key.includes(value)
    ) {
      !dataState.TransferAgentSystemName &&
        (dataState.TransferAgentSystemName = "BNYM Inst TA");
    }

    if (
      key === "SubVehicleName" &&
      constants.TAS_Retail_DQ_Sub_Vehicle_key.includes(value)
    ) {
      !dataState.TransferAgentSystemName &&
        (dataState.TransferAgentSystemName = "BNYM Retail TA");
    }

    if (key === "VehicleName" && constants.PV_DQ_Vehicle_key.includes(value)) {
      !dataState.ProxyVotingFlag && (dataState.ProxyVotingFlag = "Yes");
    }

    if (key === "TradingSystemName" && (!value || value === "Not Applicable")) {
      dataState.AladdinProcessingName = null;
    }

    if (key === "FinanceAUMSourceName") {
      if (!value || value === "Do Not Load") {
        dataState.FinanceAUMAmountTypeName = null;
        dataState.FinanceBusinessLineName = null;
      } else {
        !dataState.FinanceBusinessLineName &&
          (dataState.FinanceBusinessLineName =
            constants.FBL_DQ_Vehicle_key.includes(dataState.VehicleName)
              ? "Intermediary"
              : "Institutional");
      }
    }

    if (
      key === "VehicleName" &&
      dataState.FinanceAUMSourceName &&
      dataState.FinanceAUMSourceName !== "Do Not Load"
    ) {
      !dataState.FinanceBusinessLineName &&
        (dataState.FinanceBusinessLineName =
          constants.FBL_DQ_Vehicle_key.includes(value)
            ? "Intermediary"
            : "Institutional");
    }

    if (key === "ESGFlag" && (!value || value === "No")) {
      dataState.ESGClientDirectedExclusion = null;
      dataState.ESGFullIntegration = null;
      dataState.ESGSustainability = null;
      dataState.ESGSustainabilityObjectiveName = null;
    }

    if (key === "ESGSustainability" && (!value || value === "No")) {
      dataState.ESGSustainabilityObjectiveName = null;
    }

    if (
      key === "PerformanceBookOfRecordName" &&
      (!value || value === "Not Applicable")
    ) {
      dataState.PerformanceInceptionDate = null;
      dataState.PerformanceStartDate = null;
    }

    if (Object.values(constants.reference_data_fields_pair).includes(key)) {
      dataState[_.invert(constants.reference_data_fields_pair)[key]] = null;
    }

    if (key === "TradingSystemName" && value === "Aladdin") {
      !dataState["Blackrock Identifier"] &&
        (dataState["Blackrock Identifier"] = dataState.PortfolioCode);
    }

    if (constants.xreference_DQ_key.includes(key)) {
      const referenceObject = referenceObjects.PortfolioXReferenceCategoryName;
      const { keyField, options } = referenceObject;

      Object.values(options[keyField]).forEach((referenceId: any) => {
        const fieldKey = referenceId.split(" ")[0].toLowerCase();
        let checking = _.chain(constants.xreference_DQ_key)
          .map((itemkey) => {
            return itemkey === key
              ? value
              : !!dataState[itemkey]
              ? dataState[itemkey]
              : "";
          })
          .uniq()
          .join("|")
          .value()
          .replaceAll("BNYM ", "")
          .replace("Aladdin", "Blackrock");
        if (
          !!dataState.TransferAgentSystemName &&
          dataState.TransferAgentSystemName !== "Not Applicable"
        ) {
          checking += "|Shareholder";
        }

        if (checking.toLowerCase().includes(fieldKey)) {
          if (fieldKey === "star") {
            const isExisted = !!dataState[referenceId];
            !!dataState["SGA Account Number"] &&
              !isExisted &&
              (dataState[referenceId] = dataState["SGA Account Number"]);
          }
        } else {
          dataState[referenceId] = null;
        }
      });
    }

    onUpdateValue(newItem);
  };

  const onReferenceObjectValueChange = (event, key, referenceObject) => {
    let value = event.target.value;

    const defaultItem = key !== "Status" ? constants.defaultSelectItem : "";
    value = value !== defaultItem ? value : null;
    let newItem: any = {
      [key]: value !== defaultItem ? value : null,
    };

    //DQ default value
    // if (dataField.includes("Benchmark") && key === "Primary") {
    //   const isExisted =
    //     !!dataState.PrimaryAnalytics &&
    //     dataState.PrimaryAnalytics !== defaultSelectItem;
    //   !isExisted &&
    //     (newItem = {
    //       ...newItem,
    //       PrimaryAnalytics: value,
    //     });
    // }

    // if (dataField.includes("PortfolioXReferences") && key === "SGA Account Number") {
    //   const checking = checkXreference(dataState);
    //   const isExisted = !!dataState['STAR Account Number'];
    //   !isExisted &&
    //     checking.toLowerCase().includes("star") &&
    //     (newItem = {
    //       ...newItem,
    //       "STAR Account Number": value,
    //     });
    // }

    onUpdateValue(newItem);
  };

  const createDataFieldDOM = (fieldItem, isEditable = true) => {
    const key = fieldItem;
    let type = !!fieldItem.type ? fieldItem.type : "text";
    let referenceItem = !!referenceList ? referenceList[key] : null;

    if (key === "PortfolioManagerTeamName") {
      referenceItem = getPortfolioManagerTeamOptions(referenceItem);
    }

    !!referenceItem && (type = "list");

    constants.portfolio_date_datafields.includes(key) && (type = "date");
    constants.portfolio_number_datafields.includes(key) && (type = "number");
    const isVarChar = Object.keys(constants.varchar_regexp_fields).includes(
      fieldItem
    );

    const fieldValue = dataState[key];
    let displayValue = fieldValue;

    !!displayValue &&
      type === "date" &&
      (displayValue = dateFormatterUTCtoLocal(displayValue));

    (key === "PortfolioCode" || key === "ParentPortfolioCode") &&
      (displayValue = (
        <span
          className={classNames("portfolio_code", {
            disabled: key === "PortfolioCode",
          })}
          onClick={() => {
            key === "ParentPortfolioCode" &&
              !!fieldValue &&
              !isEditMode &&
              onPortfolioClick(fieldValue);
          }}
        >
          {displayValue}
        </span>
      ));
    key === "Status" &&
      (displayValue = (
        <span className={getStatusClass(displayValue)}>{displayValue}</span>
      ));

    if (
      key === "PrimaryPortfolioManager" ||
      key === "PortfolioManagerMembers"
    ) {
      displayValue = getPrimaryPortfolioManagerValue(
        dataState.PortfolioManagerTeamName,
        referenceList.PortfolioManagerTeamName,
        key === "PrimaryPortfolioManager" ? 0 : 1
      );
      isEditable = false;
    }

    let statusOptions = [];
    if (key === "Status" && !!portfolioData) {
      const isStatusChanged = portfolioData[key] !== fieldValue;
      if (isStatusChanged) {
        statusOptions =
          portfolioData[key] === constants.status_options.Closed
            ? [constants.status_options.WorkInProgress]
            : [portfolioData[key], fieldValue];
      } else {
        statusOptions = [
          fieldValue,
          ...getNextStatus(fieldValue).map((status) => status),
        ];
      }
    }

    //DQ Editable
    key === "CustodianAccountNumber" &&
      (!dataState.CustodianBankName ||
        dataState.CustodianBankName === "No Custodian Access") &&
      (isEditable = false);

    key === "ABORSystemName" &&
      constants.ABOR_DQ_key.includes(dataState.VehicleName) &&
      (isEditable = false);

    ["FinanceAUMAmountTypeName", "FinanceBusinessLineName"].includes(key) &&
      (!dataState.FinanceAUMSourceName ||
        dataState.FinanceAUMSourceName === "Do Not Load") &&
      (isEditable = false);

    [
      "ESGClientDirectedExclusion",
      "ESGFullIntegration",
      "ESGSustainability",
      "ESGSustainabilityObjectiveName",
    ].includes(key) &&
      (!dataState.ESGFlag || dataState.ESGFlag === "No") &&
      (isEditable = false);

    if (
      key === "ESGSustainabilityObjectiveName" &&
      isEditable &&
      (!dataState.ESGSustainability || dataState.ESGSustainability === "No")
    ) {
      isEditable = false;
    }

    isEditable = isEditable && (key !== "Status" || entitlement.CanApprove);

    if (portfolioData.Status !== constants.status_options.WorkInProgress) {
      isEditable =
        isEditable && !constants.editable_for_WorkInProgress_only.includes(key);
      if (portfolioData.Status === constants.status_options.Closed) {
        isEditable =
          isEditable || constants.enable_for_Closed_only.includes(key);
      }
    }

    const defaultItem =
      key !== "Status"
        ? {
            defaultItem: constants.defaultSelectItem,
          }
        : {};

    const isRequired =
      requiredFields.includes(key) ||
      (key === "LiquidationDate" &&
        dataState.Status === constants.status_options.Closed);

    let options = type === "list" ? Object.values(referenceItem).sort() : null;

    if (
      !!options &&
      !!referenceItem &&
      Object.keys(constants.reference_data_fields_pair).includes(fieldItem)
    ) {
      options = Object.values(
        getSubOptions(
          dataState[constants.reference_data_fields_pair[fieldItem]],
          referenceItem
        )
      );
    }

    let isVisible = true;

    isVisible =
      key !== "ParentPortfolioCode" ||
      checkParentPortfolio(dataState.PortfolioTypeName);

    if (constants.disable_for_Edit_Mode.includes(key)) {
      isVisible = isEditMode && isEditable;
    }

    if (constants.enable_for_Closed_only.includes(key)) {
      isVisible = dataState.Status === constants.status_options.Closed;
    }

    return (
      isVisible && (
        <div
          key={`${key}`}
          className={classNames(field_item, {
            [editmode_field_item]: isEditMode,
            [error_field]:
              isRequired &&
              (checkRequiredFields(dataState, [key]).isFailed ||
                checkFieldsMaxLength(dataState, [key])),
          })}
        >
          <div
            className={classNames({
              [required_field]: isRequired,
            })}
          >
            {getDataFieldTitle(key)}
          </div>
          <div
            className={classNames({
              [upper_case]: key === "PortfolioCode",
              [not_editable]: isEditMode && !isEditable,
            })}
            title={typeof displayValue === "object" ? fieldValue : displayValue}
          >
            {isEditMode && isEditable ? (
              type === "list" ? (
                <DropDownList
                  {...defaultItem}
                  value={displayValue || defaultItem.defaultItem}
                  data={
                    key !== "Status"
                      ? key === "ParentPortfolioCode"
                        ? options.filter(
                            (key) => key !== dataState.PortfolioCode
                          )
                        : options || []
                      : statusOptions
                  }
                  onChange={(e) => onValueChange(e, type, key)}
                />
              ) : type === "date" ? (
                <DatePicker
                  value={
                    !!dataState && !!displayValue
                      ? new Date(displayValue)
                      : null
                  }
                  {...(key === "LiquidationDate"
                    ? { min: new Date(dataState.InceptionDate) }
                    : {})}
                  placeholder="MM/DD/YYYY"
                  onChange={(e) => onValueChange(e, type, key)}
                />
              ) : (
                <ValidatedInput
                  type={type}
                  value={fieldValue || ""}
                  onChange={(e) => onValueChange(e, type, key)}
                  hint={createInputMaxLengthHint(
                    key.toString(),
                    type === "number"
                  )}
                  isValidationFailed={validateInputLength(
                    key.toString(),
                    fieldValue
                  )}
                  isVarchar={isVarChar}
                  {...(isVarChar
                    ? { regpattern: constants.varchar_regexp_fields[fieldItem] }
                    : {})}
                />
              )
            ) : (
              displayValue
            )}
          </div>
        </div>
      )
    );
  };

  const createReferenceObjectDOM = (
    fieldItem,
    referenceObject,
    canEdit = true
  ) => {
    const { keyField, valueField, codeKey, benchmarkType, options } =
      referenceObject || {};
    let { type } = referenceObject || {};
    const obj = !!referenceObject && !!options ? options[keyField] : {};

    return Object.values(obj).map((referenceId: any) => {
      let referenceItem = options[valueField];
      let isEditable = canEdit;

      constants.portfolio_date_datafields.includes(referenceId) &&
        (type = "date");
      constants.portfolio_number_datafields.includes(referenceId) &&
        (type = "number");

      let listOptions = !!referenceItem
        ? Object.values(referenceItem).sort()
        : [];
      let defaultItem = constants.defaultSelectItem;

      //DQ Editable
      if (canEdit && keyField === "PortfolioXReferenceCategoryName") {
        if (!referenceId.includes("Shareholder")) {
          const checking = checkXreference(dataState);
          const checkingKey = referenceId
            .split(constants.XReference_Split)[0]
            .toLowerCase();
          isEditable =
            checking.toLowerCase().includes(checkingKey) ||
            !constants.XReference_DQ_fields.includes(checkingKey);
        } else {
          isEditable =
            (!!dataState.TransferAgentSystemName &&
              dataState.TransferAgentSystemName !== "Not Applicable") ||
            constants.Shareholder_ID_DQ_Vehicle_key.includes(
              dataState.VehicleName
            );
        }
        !isEditable &&
          !referenceId.includes("Blackrock") &&
          (dataState[referenceId] = null);
      }

      if (canEdit && keyField === "BenchmarkPrecedenceName") {
        const benchmarkFields: string[] = Object.values(options[keyField]);
        const currentIndex = benchmarkFields.indexOf(referenceId);
        const maxIndex = benchmarkType === "Analytics" ? 1 : 2;
        const validValue = dataState[benchmarkFields[currentIndex - 1]];
        const currentValue = dataState[benchmarkFields[currentIndex]];
        const nextValue = dataState[benchmarkFields[currentIndex + 1]];
        if (currentIndex > 0) {
          if (checkValidBenchmark(validValue)) {
            listOptions = _.difference(listOptions, [validValue]);
          } else {
            dataState[referenceId] = null;
            isEditable = false;
          }
        }
        if (currentIndex < maxIndex && !!currentValue && !!nextValue) {
          defaultItem = null;
        }
      }

      isEditable =
        isEditable && (fieldItem !== "Status" || entitlement.CanApprove);

      let displayValue = dataState[referenceId];

      !!displayValue &&
        type === "date" &&
        (displayValue = dateFormatterUTCtoLocal(displayValue));
      if (!!displayValue && keyField === "BenchmarkPrecedenceName") {
        displayValue = getSpecialDisplayText(
          displayValue,
          options[codeKey],
          "benchmark"
        );
      }

      const isRequired = requiredFields.includes(referenceId);
      return (
        <div
          key={`${fieldItem}_${referenceId}`}
          className={classNames(field_item, {
            [editmode_field_item]: isEditMode,
            [error_field]:
              isRequired &&
              (checkRequiredFields(dataState, [referenceId]).isFailed ||
                checkFieldsMaxLength(dataState, [referenceId])),
          })}
        >
          <div
            className={classNames({
              [required_field]: isRequired,
            })}
          >
            {getDataFieldTitle(referenceId)}
          </div>
          <div
            title={displayValue}
            className={classNames({
              [not_editable]: isEditMode && !isEditable,
            })}
          >
            {isEditMode && isEditable ? (
              type === "list" ? (
                <DropDownList
                  {...(!!defaultItem ? { defaultItem } : {})}
                  value={displayValue || defaultItem}
                  data={listOptions}
                  itemRender={getFilterRender(options[codeKey])}
                  onChange={(e) =>
                    onReferenceObjectValueChange(
                      e,
                      referenceId,
                      referenceObject
                    )
                  }
                />
              ) : type === "date" ? (
                <DatePicker
                  value={
                    !!dataState && !!displayValue
                      ? new Date(displayValue)
                      : null
                  }
                  placeholder="MM/DD/YYYY"
                  onChange={(e) =>
                    onReferenceObjectValueChange(
                      e,
                      referenceId,
                      referenceObject
                    )
                  }
                />
              ) : (
                <ValidatedInput
                  type={type}
                  value={displayValue || ""}
                  onChange={(e) =>
                    onReferenceObjectValueChange(
                      e,
                      referenceId,
                      referenceObject
                    )
                  }
                  hint={createInputMaxLengthHint(
                    referenceId,
                    type === "number"
                  )}
                  isValidationFailed={validateInputLength(
                    referenceId,
                    displayValue
                  )}
                />
              )
            ) : (
              displayValue
            )}
          </div>
        </div>
      );
    });
  };

  return (
    <>
      {!!dataState &&
        datafields.map((field, index) => {
          const isEditable =
            !isReadOnly &&
            (!entitlement.OwnerSections.length ||
              checkAccessibility(entitlement, contentView, field));

          const isActiveStatus =
            (!!portfolioData &&
              !!portfolioData.Status &&
              portfolioData.Status !== constants.status_options.Closed) ||
            (!!dataState &&
              !!dataState.Status &&
              dataState.Status !== constants.status_options.Closed);

          let ownerinfo = "Owned by:";
          field.owner.forEach((owner) => (ownerinfo += `\r${owner}`));
          return (
            <div
              key={`${field.title}_${index}`}
              className={portfolioInfoPanel_cn}
            >
              <div className={panel_title}>
                <div> {field.title}</div>
                <div>
                  {!(
                    isEditable &&
                    (isActiveStatus || field.datafields.includes("Status"))
                  ) && (
                    <span title="Read Only">
                      <SvgIcon
                        icon={trackChangesRejectIcon}
                        size="large"
                        themeColor="error"
                      />
                    </span>
                  )}
                  {!!field.owner.length && (
                    <span title={ownerinfo}>
                      <SvgIcon
                        icon={infoCircleIcon}
                        size="large"
                        themeColor="error"
                      />
                    </span>
                  )}
                </div>
              </div>
              <div className={field_content}>
                {field.datafields.map((fieldItem) => {
                  const isReferenceObject =
                    !!referenceObjects && !!referenceObjects[fieldItem];
                  const canEdit =
                    isEditable &&
                    (entitlement.CanSetup ||
                      entitlement.CanApprove ||
                      !entitlement.OwnedFields.length ||
                      !field.owner.length ||
                      entitlement.OwnedFields.includes(fieldItem)) &&
                    (isActiveStatus || fieldItem === "Status");
                  return isReferenceObject
                    ? createReferenceObjectDOM(
                        fieldItem,
                        referenceObjects[fieldItem],
                        canEdit
                      )
                    : createDataFieldDOM(fieldItem, canEdit);
                })}
              </div>
            </div>
          );
        })}
    </>
  );
};

export default PortfolioInfoPanel;
