import React, { FC, useEffect, useMemo, useState } from "react";
import classNames from "classnames";
import { DropDownList } from "@progress/kendo-react-dropdowns";
import { Button } from "@progress/kendo-react-buttons";
import { moreVerticalIcon } from "@progress/kendo-svg-icons";
import { filterBy } from "@progress/kendo-data-query";
import { Menu } from "@progress/kendo-react-layout";
import _ from "lodash";

import DataGrid from "../../common/components/DataGrid";
import { DEFAULT_SINGLE_GRID_DEF, tags_columnDefs } from "../utils/constants";
import NewTagDialog from "./NewTagDialog";
import StyledDialog from "../../common/components/StyledDialog";

import styles from "./PortfolioTagGrid.module.scss";
import homeStyles from "../pages/HomeScreen.module.scss";

const { tag_grid, action_menu, view_title, tool_bar } = styles;
const { link } = homeStyles;

interface IPTGProps {
  className?: string;
  viewItem: any;
  isReadOnly: boolean;
  entitlement?: any;
  referenceList?: any;
  referenceData?: any;
  portfolioData?: any;
  filterPortfolio?: (filters: FilterItem[]) => void;
  updateReference?: (
    referenceId: string,
    dataItem: any,
    isUpdatePortfolio: boolean,
    isUpdatePorfolioOnly?: boolean
  ) => void;
}

type PTGProps = IPTGProps;

const PortfolioTagGrid: FC<PTGProps> = (props: PTGProps) => {
  const {
    className,
    viewItem,
    isReadOnly,
    entitlement,
    referenceList = {},
    referenceData = {},
    portfolioData = {},
    filterPortfolio,
    updateReference,
  } = props;
  const [visibleTagDialog, setVisibleTagDialog] = useState(false);
  const [visibleRemoveDialog, setVisibleRemoveDialog] = useState(false);
  const [isEditTag, setIsEditTag] = useState(false);
  const [filterFields, setFilterFields] = useState([]);
  const [dataState, setDataState] = useState(null);
  const [gridData, setGridData] = useState([]);
  const [selectedTagData, setSelectedTagData] = useState(null);

  useEffect(() => {
    const dataState = _.pick(portfolioData, ["Id", "PortfolioTagIds"]);
    !!referenceData &&
      !!referenceData.all &&
      !!dataState.PortfolioTagIds &&
      setGridData(
        dataState.PortfolioTagIds.filter((tagItem) => !!tagItem.Status).map(
          (tagItem) => {
            return {
              ...referenceData.all
                .find((item) => item.FieldName === "PortfolioTags")
                .Options.find((item) => {
                  return item.Id === tagItem.PortfolioTagId;
                }),
              ModifiedBy: tagItem.ModifiedBy,
              ModifiedOn: tagItem.ModifiedOn,
            };
          }
        )
      );
    setDataState(dataState);
  }, [portfolioData]);

  const portfolioTagGrid_cn = classNames(tag_grid, className);
  const canModifyTag =
    !!entitlement && (entitlement.CanSetup || entitlement.CanApprove);

  const allFilterFields = useMemo(() => {
    const tags = [];
    Object.keys(referenceList?.PortfolioTagIds || {}).forEach((key) => {
      const tagKey = Number(key);
      const existedTags = _.chain(!!dataState ? dataState?.PortfolioTagIds : {})
        .filter((item) => !!item.Status)
        .mapValues("PortfolioTagId")
        .values()
        .value();
      !existedTags.includes(tagKey) &&
        tags.push({
          id: tagKey,
          text: referenceList?.PortfolioTagIds[tagKey],
        });
    });
    setFilterFields(tags);
    return tags;
  }, [referenceList, dataState]);

  const tagMenuitems = [
    {
      text: "",
      svgIcon: moreVerticalIcon,
      items: canModifyTag
        ? [
            {
              text: "Edit",
            },
            {
              text: "Remove",
            },
          ]
        : [
            {
              text: "Remove",
            },
          ],
    },
  ];

  const toggleDialog = (key: string) => {
    switch (key) {
      case "tag":
        setVisibleTagDialog(!visibleTagDialog);
        if (visibleTagDialog) {
          setIsEditTag(false);
        }
        break;
      case "remove":
        setVisibleRemoveDialog(!visibleRemoveDialog);
        break;
    }
  };

  const handleTagActionSelect = (menuText, dataItem) => {
    switch (menuText) {
      case "Edit":
        setSelectedTagData(dataItem);
        setIsEditTag(true);
        setVisibleTagDialog(true);
        break;
      case "Remove":
        setSelectedTagData(dataItem);
        setVisibleRemoveDialog(true);
        break;
      default:
        break;
    }
  };

  const createGridToolbar = () =>
    !isReadOnly && (
      <div className={tool_bar}>
        <DropDownList
          value={null}
          data={filterFields}
          textField="text"
          filterable={true}
          defaultItem={{
            id: null,
            text: "Add existing tag",
          }}
          onFilterChange={(event) => {
            setFilterFields(filterBy(allFilterFields, event.filter));
          }}
          style={{
            width: "200px",
          }}
          onChange={(e) => {
            updateReference(
              "PortfolioTags",
              {
                ...referenceData.all
                  .find((item) => item.FieldName === "PortfolioTags")
                  .Options.find((item) => item.Id === e.target.value.id),
                Status: true,
              },
              true,
              true
            );
          }}
        />
        {canModifyTag && (
          <Button themeColor="primary" onClick={() => toggleDialog("tag")}>
            Create Tag
          </Button>
        )}
      </div>
    );

  const colMenu: any = {
    field: "",
    title: "",
    filterable: false,
    width: "40px",
    cell: (props) => (
      <td>
        <Menu
          items={tagMenuitems}
          className={action_menu}
          onSelect={(e) => handleTagActionSelect(e.item.text, props.dataItem)}
        ></Menu>
      </td>
    ),
  };

  const colDefs = tags_columnDefs.map((col) => {
    let newCol = { ...col };
    if (col.field === "Name") {
      newCol.cell = (props) => {
        return (
          !props.dataItem.aggregates && (
            <td>
              <div
                className={classNames(link)}
                onClick={() =>
                  filterPortfolio([
                    {
                      isExclude: false,
                      key: "PortfolioTags",
                      value: props.dataItem.Name,
                    },
                  ])
                }
              >
                {props.dataItem.Name}
              </div>
            </td>
          )
        );
      };
    }
    return newCol;
  });

  !isReadOnly && colDefs.push(colMenu);
  return (
    <>
      <DataGrid
        className={portfolioTagGrid_cn}
        title={<div className={view_title}>{viewItem.text}</div>}
        gridData={gridData}
        gridDef={{
          ...DEFAULT_SINGLE_GRID_DEF,
          toolbarRender: createGridToolbar,
        }}
        columnDefs={colDefs}
      />
      <NewTagDialog
        isVisible={visibleTagDialog}
        isEdit={isEditTag}
        tagData={isEditTag ? selectedTagData : null}
        portfolioName={portfolioData.PortfolioName}
        referenceList={referenceList}
        onClose={() => toggleDialog("tag")}
        onSave={(dataItem, isUpdatePortfolio) => {
          updateReference("PortfolioTags", dataItem, isUpdatePortfolio);
          toggleDialog("tag");
        }}
      />
      <StyledDialog
        title={"Remove Tag"}
        isOpen={visibleRemoveDialog}
        onClose={() => toggleDialog("remove")}
        onSave={() => {
          updateReference(
            "PortfolioTags",
            { ...selectedTagData, Status: false },
            true,
            true
          );
          toggleDialog("remove");
        }}
        saveText="ok"
      >
        <div>{`Confirm to remove "${
          !!selectedTagData ? selectedTagData.Name : ""
        }" from "${portfolioData.PortfolioName}".`}</div>
      </StyledDialog>
    </>
  );
};

export default PortfolioTagGrid;
