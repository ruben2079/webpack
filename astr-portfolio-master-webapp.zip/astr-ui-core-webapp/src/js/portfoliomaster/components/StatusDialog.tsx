import React, { FC, useEffect, useState } from "react";
import classNames from "classnames";
import { SvgIcon } from "@progress/kendo-react-common";
import { DropDownList } from "@progress/kendo-react-dropdowns";
import { arrowRightIcon } from "@progress/kendo-svg-icons";
import { DatePicker } from "@progress/kendo-react-dateinputs";

import StyledDialog from "../../common/components/StyledDialog";
import {
  getDataFieldTitle,
  getNextStatus,
  getStatusClass,
} from "../utils/utils";
import { status_options } from "../utils/constants";
import { convertDateLocalfromUTC } from "../../common/utils/utils";

import styles from "./StatusDialog.module.scss";

const { container, field_content, field_item, status_field } = styles;

interface ISDProps {
  className?: string;
  isVisible?: boolean;
  portfolioData?: any;
  onClose?: () => void;
  onSave?: (dataItem: any) => void;
}

type SDProps = ISDProps;

const StatusDialog: FC<SDProps> = (props: SDProps) => {
  const {
    className,
    isVisible = false,
    portfolioData = {},
    onClose,
    onSave,
  } = props;
  const { Status, InceptionDate } = portfolioData || {};
  const isClosedStatus = Status === status_options.Closed;
  const nextStatus = !isClosedStatus
    ? getNextStatus(Status)
    : [status_options.WorkInProgress];
  const displayValue = Status;
  const displayNextValue = nextStatus;
  const [selectedStatus, setSelectedStatus] = useState(null);
  const [selectedInceptionDate, setSelectedInceptionDate] = useState(null);
  const [selectedLiquidationDate, setSelectedLiquidationDate] = useState(null);

  useEffect(() => {
    setSelectedInceptionDate(
      !!InceptionDate ? convertDateLocalfromUTC(InceptionDate) : null
    );
  }, [portfolioData]);

  useEffect(() => {
    setSelectedLiquidationDate(null);
    setSelectedStatus(!!Status ? nextStatus[0] : null);
  }, [Status]);

  const statusDialog_cn = classNames(container, className);

  return (
    <StyledDialog
      className={statusDialog_cn}
      isOpen={isVisible}
      title={"Change Status"}
      onClose={onClose}
      onSave={() =>
        onSave({
          Status: selectedStatus,
          InceptionDate: !!selectedInceptionDate
            ? selectedInceptionDate.toLocaleDateString()
            : selectedInceptionDate,
          LiquidationDate: !!selectedLiquidationDate
            ? selectedLiquidationDate.toLocaleDateString()
            : selectedLiquidationDate,
        })
      }
      disableSave={
        Status === status_options.Active
          ? !selectedLiquidationDate
          : Status !== status_options.Closed
          ? !selectedInceptionDate
          : false
      }
    >
      <div className={field_content}>
        {!isClosedStatus ? (
          <>
            <div className={status_field}>
              <div className={getStatusClass(displayValue)}>{displayValue}</div>
              <SvgIcon icon={arrowRightIcon} />
              <div className={getStatusClass(displayNextValue[0])}>
                {displayNextValue[0]}
              </div>
            </div>
            {Status === status_options.Active && (
              <div className={field_item}>
                <div>{getDataFieldTitle("LiquidationDate")}</div>
                <DatePicker
                  {...(selectedInceptionDate
                    ? { min: selectedInceptionDate }
                    : {})}
                  value={selectedLiquidationDate}
                  placeholder="MM/DD/YYYY"
                  onChange={(e) => setSelectedLiquidationDate(e.target.value)}
                />
              </div>
            )}
          </>
        ) : (
          <div className={field_item}>
            <div>Status</div>
            <DropDownList
              defaultValue={displayNextValue[0]}
              data={displayNextValue}
              onChange={(e) => {
                selectedInceptionDate(InceptionDate);
                selectedLiquidationDate(null);
                setSelectedStatus(e.target.value);
              }}
            />
          </div>
        )}
        <div className={field_item}>
          <div>{getDataFieldTitle("InceptionDate")}</div>
          <DatePicker
            value={selectedInceptionDate}
            placeholder="MM/DD/YYYY"
            onChange={(e) => setSelectedInceptionDate(e.target.value)}
          />
        </div>
      </div>
    </StyledDialog>
  );
};

export default StatusDialog;
