import React, { FC, useEffect, useState } from "react";
import classNames from "classnames";
import { DropDownList } from "@progress/kendo-react-dropdowns";
import { DatePicker } from "@progress/kendo-react-dateinputs";
import _ from "lodash";

import StyledDialog from "../../common/components/StyledDialog";
import {
  ABOR_DQ_key,
  FBL_DQ_Vehicle_key,
  PV_DQ_Vehicle_key,
  TAS_Inst_DQ_Sub_Vehicle_key,
  TAS_Retail_DQ_Sub_Vehicle_key,
  portfolio_date_datafields,
  portfolio_required_datafields,
  reference_data_fields_pair,
  status_options,
  varchar_regexp_fields,
} from "../utils/constants";
import {
  checkFieldsMaxLength,
  checkParentPortfolio,
  checkRequiredFields,
  createInputMaxLengthHint,
  getDataFieldTitle,
  getSubOptions,
  getRequiredFieldsBasedonStatus,
  validateInputLength,
} from "../utils/utils";
import ValidatedInput from "../../common/components/ValidatedInput";

import styles from "./NewPortfolioDialog.module.scss";

const { container, field_content, field_item } = styles;

interface INPDProps {
  className?: string;
  isClone?: boolean;
  isVisible?: boolean;
  portfolioData?: any;
  referenceList?: any;
  errorMessage?: string;
  onClose?: () => void;
  onCreate?: (dataItem: any) => void;
}

type NPDProps = INPDProps;

const NewPortfolioDialog: FC<NPDProps> = (props: NPDProps) => {
  const {
    className,
    isClone = false,
    isVisible = false,
    portfolioData = null,
    referenceList = {},
    errorMessage,
    onClose,
    onCreate,
  } = props;

  const [dataState, setDataState] = useState(null);
  const [disableSave, setDisableSave] = useState(true);

  const newPortfolioDialog_cn = classNames(container, className);

  useEffect(() => {
    let dataState = { ...(isClone ? portfolioData : {}) };
    if (isVisible) {
      portfolio_required_datafields.forEach((fieldItem) => {
        const key = fieldItem;
        let value = isClone && !!portfolioData ? portfolioData[key] : null;
        if (isClone) {
          switch (key) {
            case "PortfolioName":
              value = `${value} - Copy`;
              break;
            case "PortfolioCode":
              value = "";
              break;
            case "InceptionDate":
              value = null;
              break;
            default:
              break;
          }
        }
        dataState[key] = value;
      });
      setDataState(dataState);
    }
  }, [isVisible, isClone, portfolioData]);

  useEffect(() => {
    !!dataState &&
      setDisableSave(
        checkRequiredFields(
          dataState,
          getRequiredFieldsBasedonStatus(dataState, false, null, true)
        ).isFailed || checkFieldsMaxLength(dataState)
      );
  }, [dataState]);

  const onUpdateValue = (field, value) => {
    let newState = {
      ...dataState,
      [field]: value,
    };
    !checkParentPortfolio(newState.PortfolioTypeName) &&
      (newState = { ...newState, ParentPortfolioCode: null });

    if (Object.values(reference_data_fields_pair).includes(field)) {
      newState[_.invert(reference_data_fields_pair)[field]] = null;
    }
    setDataState(newState);
  };

  const onValueChange = (event, key) => {
    const value = event.target.value;
    onUpdateValue(key, typeof value === "object" ? value.toISOString() : value);
  };

  const createDataFieldDOM = (fieldItem) => {
    let type = !!fieldItem.type ? fieldItem.type : "text";
    const referenceItem = !!referenceList ? referenceList[fieldItem] : null;
    !!referenceItem && (type = "list");
    portfolio_date_datafields.indexOf(fieldItem) > -1 && (type = "date");
    const isVarChar = Object.keys(varchar_regexp_fields).includes(fieldItem);
    const onChange = (e) => onValueChange(e, fieldItem);

    let options = type === "list" ? Object.values(referenceItem).sort() : null;

    if (
      !!options &&
      !!referenceItem &&
      Object.keys(reference_data_fields_pair).includes(fieldItem)
    ) {
      options = Object.values(
        getSubOptions(
          dataState[reference_data_fields_pair[fieldItem]],
          referenceItem
        )
      );
    }

    return (
      !!dataState &&
      (fieldItem !== "ParentPortfolioCode" ||
        checkParentPortfolio(dataState.PortfolioTypeName)) && (
        <div key={`${fieldItem}`} className={field_item}>
          <div>{getDataFieldTitle(fieldItem)}</div>
          <div>
            {type === "list" ? (
              <DropDownList
                value={dataState[fieldItem]}
                data={options || []}
                onChange={onChange}
              />
            ) : type === "date" ? (
              <DatePicker
                value={
                  !!dataState && !!dataState[fieldItem]
                    ? new Date(dataState[fieldItem])
                    : null
                }
                placeholder="MM/DD/YYYY"
                onChange={onChange}
              />
            ) : (
              <ValidatedInput
                value={dataState[fieldItem] || ""}
                onChange={onChange}
                hint={createInputMaxLengthHint(fieldItem)}
                isValidationFailed={validateInputLength(
                  fieldItem,
                  dataState[fieldItem]
                )}
                isVarchar={isVarChar}
                {...(isVarChar
                  ? { regpattern: varchar_regexp_fields[fieldItem] }
                  : {})}
              />
            )}
          </div>
        </div>
      )
    );
  };

  return (
    !!dataState && (
      <StyledDialog
        className={newPortfolioDialog_cn}
        isOpen={isVisible}
        title={`${isClone ? "Clone" : "New"} Portfolio`}
        onClose={onClose}
        onSave={() => {
          let newItem = {
            ...dataState,
          };
          if (!isClone) {
            newItem = {
              ...newItem,
              //for DQ default value
              MultiSector: false,
              DomicileCountryName: "UNITED STATES",
              BaseCurrencyName: "US Dollar",
              PerformanceBookOfRecordName: "Anova",
              FinanceAUMSourceName: "IMDS BNY TA",
              FinanceAUMAmountTypeName: "Market Value",
            };
          }
          newItem = {
            ...newItem,
            Status: Object.values(status_options)[0],
            InceptionDate: null,
            LiquidationDate: null,
            FinanceBusinessLineName:
              !!newItem.FinanceAUMSourceName &&
              newItem.FinanceAUMSourceName !== "Do Not Load" &&
              FBL_DQ_Vehicle_key.includes(newItem.VehicleName)
                ? "Intermediary"
                : "Institutional",
            ProxyVotingFlag: PV_DQ_Vehicle_key.includes(newItem.VehicleName)
              ? "Yes"
              : null,
            ABORSystemName: ABOR_DQ_key.includes(newItem.VehicleName)
              ? "Not Applicable"
              : newItem.ABORSystemName,
            TransferAgentSystemName: TAS_Inst_DQ_Sub_Vehicle_key.includes(
              newItem.SubVehicleName
            )
              ? "BNYM Inst TA"
              : TAS_Retail_DQ_Sub_Vehicle_key.includes(newItem.SubVehicleName)
              ? "BNYM Retail TA"
              : newItem.TransferAgentSystemName,
          };
          onCreate(newItem);
        }}
        disableSave={disableSave}
        saveText="Create"
        errorMessage={errorMessage}
      >
        <div className={field_content}>
          {portfolio_required_datafields.map((field) =>
            createDataFieldDOM(field)
          )}
        </div>
      </StyledDialog>
    )
  );
};

export default NewPortfolioDialog;
