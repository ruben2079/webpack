import React, { FC, useEffect, useState } from "react";
import classNames from "classnames";
import { Checkbox } from "@progress/kendo-react-inputs";
import { DropDownList } from "@progress/kendo-react-dropdowns";
import _ from "lodash";

import StyledDialog from "../../common/components/StyledDialog";
import ValidatedInput from "../../common/components/ValidatedInput";
import { createInputMaxLengthHint, validateInputLength } from "../utils/utils";
import { ADGroup_mapping } from "../utils/constants";

import styles from "./NewTagDialog.module.scss";

const { container, field_content, field_item, default_checkbox } = styles;

interface INTDProps {
  className?: string;
  isEdit?: boolean;
  isVisible?: boolean;
  tagData?: any;
  portfolioName?: string;
  referenceList: any;
  onClose?: () => void;
  onSave?: (dataItem: any, addToPortfolio: boolean) => void;
}

type NTDProps = INTDProps;

const datafields = [
  {
    key: "Name",
    title: "Name",
  },
  {
    key: "PortfolioTagDescription",
    title: "Description",
  },
  {
    key: "ADGroupName",
    title: "Team",
    type: "list",
  },
];

const NewTagDialog: FC<NTDProps> = (props: NTDProps) => {
  const {
    className,
    isEdit = false,
    isVisible = false,
    tagData = {},
    portfolioName = "",
    referenceList = null,
    onClose,
    onSave,
  } = props;
  const [addToPortfolio, setAddToPortfolio] = useState(true);
  const [dataState, setDataState] = useState({});
  const [disableSave, setDisableSave] = useState(true);

  useEffect(() => {
    let dataState = {};
    if (isVisible) {
      dataState = {
        ..._.pick(tagData, _.map(datafields, "key").concat(["Id"])),
        Status: true,
      };
      setDataState(dataState);
      setAddToPortfolio(true);
    }
  }, [isVisible, isEdit, tagData]);

  useEffect(() => {
    setDisableSave(
      !Object.keys(dataState).length ||
        _.map(datafields, "key").some((key) => !dataState[key])
    );
  }, [dataState]);

  const newTagDialog_cn = classNames(container, className);

  const onValueChange = (event, key, referenceItem) => {
    let value = event.target.value;
    !!referenceItem && (value = _.invert(ADGroup_mapping)[value] || value);
    onUpdateValue(key, value);
  };

  const onUpdateValue = (field, value) => {
    let newState = {
      ...dataState,
      [field]: value,
    };
    setDataState(newState);
  };

  const createDataFieldDOM = (fieldItem) => {
    const { key, title, type } = fieldItem;
    const referenceItem =
      !!referenceList && !!referenceList[key] ? referenceList[key] : null;
    const onChange = (e) => onValueChange(e, key, referenceItem);
    const options = !!referenceItem
      ? Object.values(referenceItem)
          .sort()
          .map((item: any) => ADGroup_mapping[item] || item)
      : [];

    return (
      <div key={`${key}`} className={field_item}>
        <div>{title}</div>
        <div>
          {!!type && type === "list" ? (
            <DropDownList
              onChange={onChange}
              value={ADGroup_mapping[dataState[key]] || dataState[key]}
              data={options}
            />
          ) : (
            <ValidatedInput
              value={dataState[key]}
              onChange={onChange}
              hint={createInputMaxLengthHint(key)}
              isValidationFailed={validateInputLength(key, dataState[key])}
            />
          )}
        </div>
      </div>
    );
  };

  return (
    <StyledDialog
      className={newTagDialog_cn}
      isOpen={isVisible}
      title={`${isEdit ? "Edit" : "Create"} Portfolio Tag`}
      onClose={onClose}
      onSave={() => onSave(dataState, isEdit || addToPortfolio)}
      disableSave={disableSave}
      saveText={isEdit ? "Save" : "Create Tag"}
    >
      <div className={field_content}>
        {datafields.map((field) => createDataFieldDOM(field))}
        {!isEdit && (
          <Checkbox
            className={default_checkbox}
            value={addToPortfolio}
            onChange={() => setAddToPortfolio(!addToPortfolio)}
            label={`Add tag to current porfolio (${portfolioName})`}
          />
        )}
      </div>
    </StyledDialog>
  );
};

export default NewTagDialog;
