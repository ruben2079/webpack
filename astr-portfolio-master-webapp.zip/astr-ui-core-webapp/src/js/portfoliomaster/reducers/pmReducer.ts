import { produce } from "immer";
import * as pmTypes from "../actions/pmAction.type";

export type PMState = {
  screen: "home" | "portfolio";
  showLoadingMask: boolean;
  isMock: boolean;
  isEditMode: boolean;
  isClone: boolean;
  feedFormName: string;
  isNewPortfolioOpen: boolean;
  portfolioCode?: string;
  meta?: any[];
  gridMeta?: any[];
  allDataFields?: string[];
  filteredMeta?: any[];
  filters?: FilterItem[];
  entitlement: any;
  portfolioData?: any;
  referenceData?: any;
  referenceList?: any;
  referenceObjects?: any;
  notification?: NotificationItem;
  userSettings?: any;
};

const initPMState: PMState = {
  screen: "home",
  showLoadingMask: false,
  isMock: false,
  isEditMode: false,
  isClone: false,
  feedFormName: null,
  isNewPortfolioOpen: false,
  portfolioCode: null,
  meta: [],
  gridMeta: [],
  allDataFields: [],
  filteredMeta: [],
  filters: [],
  entitlement: null,
  portfolioData: null,
  referenceData: null,
  referenceList: null,
  referenceObjects: null,
  notification: null,
  userSettings: {},
};

const pmReducer = produce((state = initPMState, { type, payload } = {}) => {
  switch (type) {
    case pmTypes.SET_PM_STATE:
      state = payload;
      break;
    case pmTypes.SWITCH_SCREEN:
      state.screen = !payload.options?.portfolioCode ? "home" : payload.screen;
      state.isEditMode =
        state.screen !== "home" && !!payload.options?.isEditMode;
      state.portfolioCode =
        state.screen !== "home" ? payload.options?.portfolioCode : null;
      !state.portfolioCode && (state.portfolioData = null);
      state.feedFormName =
        state.screen === "portfolio" && payload.options?.feedFormName;
      break;
    case pmTypes.UPDATE_NOTIFICATION:
      state.notification = payload;
      break;
    case pmTypes.TIGGER_LOADING_MASK:
      state.showLoadingMask = payload;
      break;
    default:
      break;
  }
  return state;
});
export default pmReducer;
