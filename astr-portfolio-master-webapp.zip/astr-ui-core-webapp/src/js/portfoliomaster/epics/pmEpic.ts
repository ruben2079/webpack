import { ofType } from "redux-observable";
import { Observable, combineLatestAll, of, switchMap } from "rxjs";
import _ from "lodash";
import * as pmTypes from "../actions/pmAction.type";
import * as pmActions from "../actions/pmAction";
import * as pmAPI from "../actions/pmAPI";
import { PMState } from "../reducers/pmReducer";
import { checkAjaxErrors } from "../../common/epics/operators/catchAjaxError";
import {
  Default_Filters,
  PM_URL_PARAMS,
  currency_data_value_split,
  data_value_split,
  entitlment_reference_object,
  reference_data_fields_pair,
} from "../utils/constants";
import {
  getDateStringforSaving,
  getLocationParam,
  getRandomInt,
  isDev,
} from "../../common/utils/utils";
import { all_portfolio } from "../../mock/allPortfolio";
import { entitlement } from "../../mock/entitlement";
import {
  Benchmark_Suffix,
  Filter_Suffix,
  portfolio_content_datafields,
  portfolio_toggle_datafields,
  single_reference_ids,
  status_options,
} from "../utils/constants";
import { portfolio_reference } from "../../mock/reference";
import {
  genenteGridData,
  genentePortfolioData,
  getAllGridFields,
} from "../utils/utils";
import { URL_PARAMS } from "../../common/utils/constants";

export const initPMEpic = (action$: Observable<ActionType>) =>
  action$.pipe(
    ofType(pmTypes.INIT_PM),
    switchMap((action) => {
      const steps = [pmAPI.getPMEntitlement(), pmAPI.getUserSettings()];
      return of(...steps).pipe(combineLatestAll());
    }),
    switchMap((args: any[]) => {
      const errors = checkAjaxErrors(args);
      const portfolioCode = getLocationParam(PM_URL_PARAMS.portfolio);
      const isDevEnv = isDev();
      const isMock = !!getLocationParam(URL_PARAMS.mock) && isDevEnv;
      const mockEntitlement = getLocationParam(PM_URL_PARAMS.role);
      const pmState: PMState = {
        screen: !portfolioCode ? "home" : "portfolio",
        showLoadingMask: false,
        isMock,
        isEditMode: false,
        isClone: false,
        feedFormName: null,
        isNewPortfolioOpen: false,
        portfolioCode: getLocationParam(PM_URL_PARAMS.portfolio),
        entitlement: processEntitlement(
          !!mockEntitlement && isDevEnv
            ? entitlement[getLocationParam(PM_URL_PARAMS.role)]
            : !errors.length
            ? args[0]
            : entitlement.user
        ),
        userSettings: args[1],
      };
      return [
        ...errors,
        pmActions.setPMState(pmState),
        pmActions.fetchAllPorfolio(),
      ];
    })
  );

export const fetchAllPorfolioDataEpic = (
  action$: Observable<ActionType>,
  state$
) =>
  action$.pipe(
    ofType(pmTypes.FETCH_ALL),
    switchMap((action: ActionType) => {
      const { isCoreDataOnly = false } = action.payload;
      let steps = [pmAPI.getAllPortfolio(), pmAPI.getReferenceData()];
      !isCoreDataOnly &&
        (steps = [
          ...steps,
          pmAPI.getSingleReferenceData("PortfolioTags"),
          ...Object.keys(single_reference_ids).map((id) =>
            pmAPI.getSingleReferenceData(id)
          ),
        ]);
      return of(...steps).pipe(combineLatestAll());
    }),
    switchMap((args: any[]) => {
      const errors = checkAjaxErrors(args);
      const { isMock, portfolioCode, referenceData, filters, entitlement } =
        state$.value.pmState;
      const meta = isMock
        ? state$.value.pmState.meta || all_portfolio
        : !errors.length && Array.isArray(args[0])
        ? args[0]
        : [];
      let newReferenceData = {
        ...(referenceData || {}),
      };
      newReferenceData = isMock
        ? referenceData || portfolio_reference
        : !errors.length
        ? {
            ...newReferenceData,
            all: [
              ..._.unionBy(
                args[1],
                newReferenceData.all || [],
                "FieldToUpdate"
              ),
              ...(args.length > 2 ? args[2] : []),
            ],
          }
        : newReferenceData;
      !errors.length &&
        args.length > 2 &&
        !isMock &&
        Object.keys(single_reference_ids).forEach((id, index) => {
          newReferenceData[id] = args[3 + index];
        });
      const referenceList = processReference(newReferenceData);
      const referenceObjects = processReferenceObject(newReferenceData);
      const gridMeta = genenteGridData(meta, referenceList, referenceObjects);
      const allDataFields = getAllGridFields(referenceList, referenceObjects);
      const portfolioData = !!portfolioCode
        ? gridMeta.find((item) => item.PortfolioCode === portfolioCode)
        : null;
      const newFilters = filters || Default_Filters;
      const pmState: PMState = {
        ...state$.value.pmState,
        screen: !portfolioCode || !portfolioData ? "home" : "portfolio",
        showLoadingMask: false,
        entitlement: processEntitlement(entitlement, referenceObjects),
        meta,
        gridMeta,
        allDataFields,
        filters: newFilters,
        filteredMeta: processFilters(gridMeta, newFilters),
        referenceData: newReferenceData,
        referenceList,
        referenceObjects,
        portfolioCode: !!portfolioData ? portfolioCode : null,
        portfolioData,
      };
      return [...errors, pmActions.setPMState(pmState)];
    })
  );

const processFilters = (meta: any[], filters?: FilterItem[]): any[] => {
  if (!filters || !filters.length) return meta;
  let newdata = [...meta];
  filters.forEach((filter) => {
    newdata = newdata.filter((item) => {
      const { isExclude = false } = filter;
      const key = filter.key.replace(Filter_Suffix, "");
      const value = filter.value;
      let dataValue = Object.keys(item).includes(key) ? item[key] || "" : "";
      if (Array.isArray(item[key])) {
        dataValue = _.join(_.map(item[key], "Name"), "|");
      }
      dataValue = dataValue.toLowerCase();
      let isIncluded = false;
      if (Array.isArray(value)) {
        value.forEach((filterValue) => {
          isIncluded =
            isIncluded || dataValue.includes(filterValue.toLowerCase());
        });
      } else if (
        typeof value === "object" &&
        Object.keys(value).includes("min")
      ) {
        if (!!dataValue) {
          const mindate = getDateStringforSaving(value.min);
          const maxdate = getDateStringforSaving(value.max);
          const isMin = !mindate || dataValue >= mindate;
          const isMax = !maxdate || dataValue <= maxdate;
          isIncluded = isMin && isMax;
        }
      } else {
        isIncluded = dataValue.includes(`${filter.value}`.toLowerCase());
      }
      return !isExclude ? isIncluded : !isIncluded;
    });
  });
  return newdata;
};

const processEntitlement = (entitlement, referenceObjects?) => {
  const OwnerSections = [];
  let OwnedFields = [...entitlement.OwnedFields];
  !!referenceObjects &&
    entitlement.OwnedFields.forEach((field) => {
      if (entitlment_reference_object.includes(field)) {
        OwnedFields = _.without(OwnedFields, field);
        const referenceKey: any = Object.keys(referenceObjects).find(
          (key: any) =>
            field.includes(
              referenceObjects[key].benchmarkType ||
                referenceObjects[key].dataField
            )
        );
        OwnedFields.push(referenceKey);
      }
    });
  Object.keys(portfolio_content_datafields).forEach((contentView) => {
    portfolio_content_datafields[contentView].forEach((sectionData) => {
      const { title, datafields } = sectionData;
      const hasSome = datafields.some((key) => {
        const referenceObject = !!referenceObjects
          ? referenceObjects[key]
          : null;
        return entitlement.OwnedFields.includes(
          !!referenceObject
            ? `${referenceObject.benchmarkType || ""}${
                referenceObject.dataField
              }`
            : key
        );
      });
      hasSome && OwnerSections.push(`${contentView}---${title}`);
    });
  });
  return { ...entitlement, OwnerSections, OwnedFields };
};

const processReference = (referenceData) => {
  let reference = {};
  !!referenceData &&
    _.flatten(
      Object.values(_.omit(referenceData, "PortfolioBenchmarks"))
    ).forEach((item) => {
      const key = item.FieldToUpdate || item.FieldName;
      let newReference = {};
      const options = item?.Options;
      !!item &&
        !!options &&
        !!options.length &&
        options.forEach((option, index) => {
          const referenceId = option.Code || option.Id || index;
          let referenceValue = (
            option.Name ||
            option.PortfolioCode ||
            option
          ).trim();

          if (key === "PortfolioManagerTeamName") {
            const members = _.chain(option.PortfolioManagerTeamMembers)
              .map("TeamMemberName")
              .join(", ")
              .value();
            referenceValue = `${option.PrimaryPortfolioManagerName}${data_value_split}${members}${data_value_split}${referenceValue}`;
          }
          if (key.toLowerCase().includes("currency")) {
            referenceValue = `${referenceId}${currency_data_value_split}${referenceValue}`;
          }
          if (!Object.keys(reference_data_fields_pair).includes(key)) {
            !!option.Status &&
              (key !== "ParentPortfolioCode" ||
                option.Status !== status_options.Closed) &&
              (newReference[referenceId] = referenceValue);
          } else {
            const parent_key = reference_data_fields_pair[key];
            if (key === "InvestmentStrategyName") {
              const group_key = option[parent_key];
              !newReference[group_key] && (newReference[group_key] = {});
              newReference[group_key] = {
                ...newReference[group_key],
                [referenceId]: referenceValue,
              };
            } else if (key === "SubVehicleName") {
              let newReferenceValue = null;
              const { Id, Name, ParentVehicleName } = option;
              if (!!option && !!ParentVehicleName) {
                !newReferenceValue && (newReferenceValue = {});
                newReferenceValue[Id] = Name;
              }
              if (!!newReferenceValue) {
                !newReference[ParentVehicleName] &&
                  (newReference[ParentVehicleName] = {});
                newReference[ParentVehicleName] = {
                  ...newReference[ParentVehicleName],
                  ...newReferenceValue,
                };
              }
            }
          }
        });
      if (key === "Status") {
        newReference = status_options;
      }
      (!!Object.keys(newReference).length || key === "ParentPortfolioCode") &&
        (reference[key] = newReference);
    });
  portfolio_toggle_datafields.forEach((datafield) => {
    reference[datafield] = {
      true: "Yes",
      false: "No",
    };
  });
  return reference;
};

const processReferenceObject = (referenceData) => {
  let reference: any = null;
  !!referenceData &&
    Object.keys(single_reference_ids).forEach((id) => {
      !reference && (reference = {});
      const referenceObject = referenceData[id];
      single_reference_ids[id].forEach((fieldId) => {
        const isBenchmarks = id.includes("Benchmarks");
        const isXReference = id.includes("XReference");
        reference[fieldId] = {
          type: isBenchmarks ? "list" : "text",
          dataField: id,
          options: null,
          keyField: isBenchmarks ? "BenchmarkPrecedenceName" : fieldId,
          valueField: isBenchmarks
            ? "BenchmarkId"
            : isXReference
            ? "PortfolioXReferenceValue"
            : fieldId,
        };
        if (isBenchmarks) {
          reference[fieldId] = {
            ...reference[fieldId],
            benchmarkType: fieldId.includes("Analytics")
              ? "Analytics"
              : "Performance",
            codeKey: `${reference[fieldId].valueField}-Code`,
          };
        }
        !!referenceObject &&
          !!Array.isArray(referenceObject) &&
          !!referenceObject.length &&
          referenceObject.forEach((obj) => {
            const objId = obj.FieldToUpdate || obj.FieldName;
            let options = obj.Options;
            reference[fieldId].options = {
              ...(reference[fieldId].options || {}),
              [objId]: {},
            };
            options
              .filter((option) => !option.status)
              .forEach((option, index) => {
                const referenceId = option.Id || index;
                let referenceValue =
                  option.BenchmarkId || option.Name || option;
                if (isBenchmarks && objId === reference[fieldId].keyField) {
                  const fieldKey = referenceValue.replace(Benchmark_Suffix, "");
                  const isAnalyticsField = fieldId.includes("Analytics");
                  if (
                    !isAnalyticsField ||
                    (isAnalyticsField && fieldKey !== "Tertiary")
                  ) {
                    reference[fieldId].options[objId][
                      referenceId
                    ] = `${fieldKey}${isAnalyticsField ? "Analytics" : ""}`;
                  }
                } else if (
                  isBenchmarks &&
                  objId === reference[fieldId].valueField
                ) {
                  const isAnalyticsField = fieldId.includes("Analytics");
                  const isAnalyticsType = option.Type === "Analytics";
                  if (
                    (isAnalyticsType && isAnalyticsField) ||
                    (!isAnalyticsType && !isAnalyticsField)
                  ) {
                    reference[fieldId].options[objId][referenceId] =
                      referenceValue;
                    const codeKey = reference[fieldId].codeKey;
                    !reference[fieldId].options[codeKey] &&
                      (reference[fieldId].options[codeKey] = {});
                    reference[fieldId].options[codeKey][referenceValue] =
                      option.Code;
                  }
                } else {
                  reference[fieldId].options[objId][referenceId] =
                    referenceValue;
                }
              });
          });
      });
    });
  return reference;
};

export const getSinglePortfolioEpic = (
  action$: Observable<ActionType>,
  state$
) =>
  action$.pipe(
    ofType(pmTypes.GET_SINGLE_PORTFOLIO),
    switchMap((action: ActionType) => {
      let { portfolioCode } = action.payload;
      const { gridMeta, screen } = state$.value.pmState;
      const portfolioData = gridMeta.find(
        (item) => item.PortfolioCode === portfolioCode
      );
      !portfolioData && (portfolioCode = null);
      const pmState: PMState = {
        ...state$.value.pmState,
        portfolioCode,
        portfolioData: portfolioData,
        screen: !!portfolioCode ? screen : "home",
      };
      return [pmActions.setPMState(pmState)];
    })
  );

export const openNewPortfolioEpic = (action$: Observable<ActionType>, state$) =>
  action$.pipe(
    ofType(pmTypes.OPEN_NEW_PORTFOLIO),
    switchMap((action: ActionType) => {
      const { portfolioCode, isClone, isNewPortfolioOpen } = action.payload;
      const isNewCode = portfolioCode !== state$.value.pmState.portfolioCode;
      const { gridMeta } = state$.value.pmState;
      const portfolioData = !isNewCode
        ? state$.value.pmState.portfolioData
        : gridMeta.find((item) => item.PortfolioCode === portfolioCode);
      const steps = [
        pmActions.setPMState({
          ...state$.value.pmState,
          portfolioCode: isNewCode
            ? portfolioCode
            : state$.value.pmState.portfolioCode,
          isClone,
          isNewPortfolioOpen,
          portfolioData,
        }),
      ];
      return steps;
    })
  );

export const createPortfolioEpic = (action$: Observable<ActionType>, state$) =>
  action$.pipe(
    ofType(pmTypes.CREATE_NEW_PORTFOLIO),
    switchMap((action: ActionType) => {
      const { isMock, referenceList, referenceObjects } = state$.value.pmState;
      const dataItem = genentePortfolioData(
        [action.payload],
        referenceList,
        referenceObjects
      )[0];
      const steps = [of(dataItem)];
      !isMock && steps.push(pmAPI.createPortfolio(dataItem));
      return of(...steps).pipe(combineLatestAll());
    }),
    switchMap((args) => {
      const errors = checkAjaxErrors(args);
      const {
        referenceList,
        referenceObjects,
        isMock,
        filters,
        isClone,
        screen,
      } = state$.value.pmState;
      const dataItem = isMock ? args[0] : args[1];
      const notification = !errors.length
        ? {
            level: "success",
            message: "Portfolio created successfully!",
          }
        : null;
      let pmState: PMState = {
        ...state$.value.pmState,
        showLoadingMask: !isMock && !errors.length,
        notification,
        screen: !!errors.length ? screen : "portfolio",
        isEditMode: !errors.length,
        portfolioCode: !errors.length ? dataItem.PortfolioCode : null,
        isClone: !!errors.length && isClone,
        isNewPortfolioOpen: !!errors.length,
      };
      if (!errors.length && isMock) {
        dataItem.Id = getRandomInt(50);
        dataItem.CreatedOn = new Date().toISOString();
        const meta = [...pmState.meta, dataItem];
        const gridMeta = genenteGridData(meta, referenceList, referenceObjects);
        pmState = {
          ...pmState,
          meta,
          gridMeta,
          filteredMeta: processFilters(gridMeta, filters),
          portfolioData: gridMeta.find(
            (item) => item.PortfolioCode === dataItem.PortfolioCode
          ),
        };
      }
      const nextStep = [...errors, pmActions.setPMState(pmState)];
      if (!isMock) {
        !errors.length && nextStep.push(pmActions.fetchAllPorfolio(true));
      }
      return nextStep;
    })
  );

export const updatePortfolioEpic = (action$: Observable<ActionType>, state$) =>
  action$.pipe(
    ofType(pmTypes.UPDATE_PORTFOLIO),
    switchMap((action: ActionType) => {
      const { isMock, referenceList, referenceObjects, meta } =
        state$.value.pmState;
      const old_Item = meta.find((item) => item.Id === action.payload.Id);
      const dataItem = genentePortfolioData(
        [action.payload],
        referenceList,
        referenceObjects,
        old_Item
      )[0];
      const new_Item = { ...old_Item, ...dataItem };
      const steps = [of(new_Item)];
      !isMock && steps.push(pmAPI.updatePortfolio(new_Item));
      return of(...steps).pipe(combineLatestAll());
    }),
    switchMap((args) => {
      const errors = checkAjaxErrors(args);
      const {
        referenceList,
        referenceObjects,
        isMock,
        feedFormName,
        filters,
        screen,
        portfolioCode,
      } = state$.value.pmState;
      const dataItem = isMock ? args[0] : args[1];
      const notification = !errors.length
        ? {
            level: "success",
            message: "Portfolio updated successfully!",
          }
        : null;
      let pmState: PMState = {
        ...state$.value.pmState,
        showLoadingMask: !isMock && !errors.length,
        isEditMode: !!errors.length,
        feedFormName: !!errors.length ? feedFormName : null,
        notification,
      };
      if (!errors.length && isMock) {
        !dataItem.Id && (dataItem.Id = getRandomInt(50));
        const meta = _.unionBy([dataItem], pmState.meta, "Id");
        const gridMeta = genenteGridData(meta, referenceList, referenceObjects);
        pmState = {
          ...pmState,
          meta,
          gridMeta,
          filteredMeta: processFilters(gridMeta, filters),
          isEditMode: false,
          portfolioCode:
            screen === "portfolio" ? dataItem.PortfolioCode : portfolioCode,
          portfolioData:
            screen === "portfolio"
              ? gridMeta.find(
                  (item) => item.PortfolioCode === dataItem.PortfolioCode
                )
              : null,
        };
      }
      const nextStep = [...errors, pmActions.setPMState(pmState)];
      if (!isMock) {
        !errors.length && nextStep.push(pmActions.fetchAllPorfolio(true));
      }
      return nextStep;
    })
  );

export const filterPortfolioEpic = (action$: Observable<ActionType>, state$) =>
  action$.pipe(
    ofType(pmTypes.FILTER_PORTFOLIO),
    switchMap((action: ActionType) => {
      const newFilters = action.payload;
      const { gridMeta } = state$.value.pmState;
      const pmState: PMState = {
        ...state$.value.pmState,
        filteredMeta: processFilters(gridMeta, newFilters),
        filters: newFilters,
      };
      return [pmActions.setPMState(pmState), pmActions.switchScreen("home")];
    })
  );

export const updateReferenceEpic = (action$: Observable<ActionType>, state$) =>
  action$.pipe(
    ofType(pmTypes.UPDATE_REFERENCE),
    switchMap((action: ActionType) => {
      const {
        referenceId,
        dataItem,
        isUpdatePorfolioOnly = false,
      } = action.payload;
      const { isMock } = state$.value.pmState;
      const steps = [of(action.payload)];
      !isMock &&
        !isUpdatePorfolioOnly &&
        steps.push(pmAPI.updateReference(referenceId, dataItem));
      return of(...steps).pipe(combineLatestAll());
    }),
    switchMap((args) => {
      const errors = checkAjaxErrors(args);
      const { referenceId, dataItem, isUpdatePorfolio, isUpdatePorfolioOnly } =
        args[0];
      const {
        isMock,
        referenceList,
        referenceObjects,
        referenceData,
        meta,
        portfolioData,
      } = state$.value.pmState;
      const newDataItem =
        !isMock && !errors.length && !isUpdatePorfolioOnly
          ? args[1]
          : { Id: getRandomInt(50), ...dataItem };
      let referenceItem = referenceData.all.find(
        (item) => item.FieldName === referenceId
      );
      const oldItem = !!portfolioData[referenceItem.FieldToUpdate]
        ? portfolioData[referenceItem.FieldToUpdate].find(
            (item) => item.PortfolioTagId === newDataItem.Id
          )
        : { Id: getRandomInt(50) };
      const newPortfolioData = genentePortfolioData(
        [
          {
            ...portfolioData,
            [referenceItem.FieldToUpdate]: _.unionBy(
              [
                {
                  ...oldItem,
                  PortfolioTagId: newDataItem.Id,
                  Status: newDataItem.Status,
                },
              ],
              portfolioData[referenceItem.FieldToUpdate],
              "Id"
            ),
          },
        ],
        referenceList,
        referenceObjects,
        meta.find((item) => item.Id === portfolioData.Id)
      )[0];
      const steps = [
        of({
          referenceId,
          dataItem: newDataItem,
          isUpdatePorfolio,
        }),
        isUpdatePorfolio && !isMock
          ? !errors.length
            ? pmAPI.updatePortfolio(newPortfolioData)
            : of(args[1])
          : of(newPortfolioData),
      ];
      return of(...steps).pipe(combineLatestAll());
    }),
    switchMap((args) => {
      const errors = checkAjaxErrors(args);
      const { referenceId, dataItem, isUpdatePorfolio } = args[0];
      const { referenceData, isMock, filters, portfolioData, portfolioCode } =
        state$.value.pmState;
      const notification = !errors.length
        ? {
            level: "success",
            message: "Portfolio tag updated successfully!",
          }
        : null;
      let pmState: PMState = {
        ...state$.value.pmState,
        showLoadingMask: !isMock && !errors.length,
        notification,
      };
      if (!errors.length && isMock) {
        !dataItem.Id && (dataItem.Id = getRandomInt(50));
        !dataItem.PortfolioTagId && (dataItem.PortfolioTagId = dataItem.Id);
        let referenceItem = referenceData.all.find(
          (item) => item.FieldName === referenceId
        );
        referenceItem = {
          ...referenceItem,
          Options: _.unionBy(
            [{ ...dataItem, Status: true }],
            referenceItem.Options,
            "Id"
          ),
        };
        const newPortfolioData = isUpdatePorfolio
          ? !!args[1]
            ? args[1]
            : {
                ...portfolioData,
                [referenceItem.FieldToUpdate]: _.unionBy(
                  [dataItem],
                  portfolioData[referenceItem.FieldToUpdate],
                  "Id"
                ),
              }
          : portfolioData;
        const meta = _.unionBy(
          [newPortfolioData],
          state$.value.pmState.meta,
          "Id"
        );
        const newReferenceData = {
          ...referenceData,
          all: _.unionBy([referenceItem], referenceData.all, "FieldName"),
        };
        const referenceObjectData = {};
        Object.keys(single_reference_ids).forEach((id) => {
          referenceObjectData[id] = newReferenceData[id];
        });
        const referenceList = processReference(newReferenceData);
        const referenceObjects = processReferenceObject(newReferenceData);
        const gridMeta = genenteGridData(meta, referenceList, referenceObjects);
        const allDataFields = getAllGridFields(referenceList, referenceObjects);
        pmState = {
          ...pmState,
          meta,
          gridMeta,
          allDataFields,
          filteredMeta: processFilters(gridMeta, filters),
          referenceData: newReferenceData,
          referenceList,
          referenceObjects,
          portfolioData: gridMeta.find(
            (item) => item.PortfolioCode === portfolioCode
          ),
        };
      }
      const nextStep = [...errors, pmActions.setPMState(pmState)];
      if (!isMock) {
        !errors.length && nextStep.push(pmActions.fetchAllPorfolio(true));
      }
      return nextStep;
    })
  );

export const fetchDownStreamEpic = (action$: Observable<ActionType>, state$) =>
  action$.pipe(
    ofType(pmTypes.FETCH_DOWNSTREAM),
    switchMap((action: ActionType) => {
      const portfolioId = action.payload.portfolioId;
      const formType = action.payload.formType;
      const steps = [pmAPI.fetchDownStream(portfolioId, formType)];
      return of(...steps).pipe(combineLatestAll());
    }),
    switchMap((args) => {
      const errors = checkAjaxErrors(args);
      const { feedFormName } = state$.value.pmState;
      const notification = !errors.length
        ? {
            level: "success",
            message: "Load downstream successfully!",
          }
        : null;
      let pmState: PMState = {
        ...state$.value.pmState,
        showLoadingMask: !errors.length,
        notification,
        feedFormName: !!errors.length ? feedFormName : null,
      };
      const nextStep = [...errors, pmActions.setPMState(pmState)];
      !errors.length && nextStep.push(pmActions.fetchAllPorfolio(true));
      return nextStep;
    })
  );

export const updateUserSettingsEpic = (
  action$: Observable<ActionType>,
  state$
) =>
  action$.pipe(
    ofType(pmTypes.UPDATE_USER_SETTINGS),
    switchMap((action: ActionType) => {
      const userSettings = action.payload;
      const steps = [pmAPI.updateUserSettings(userSettings)];
      return of(...steps).pipe(combineLatestAll());
    }),
    switchMap((args) => {
      const errors = checkAjaxErrors(args);
      const { userSettings } = state$.value.pmState;
      const notification = !errors.length
        ? {
            level: "success",
            message: "User settings updated successfully!",
          }
        : null;
      let pmState: PMState = {
        ...state$.value.pmState,
        showLoadingMask: false,
        notification,
        userSettings: !errors.length ? args[0] : userSettings,
      };
      const nextStep = [...errors, pmActions.setPMState(pmState)];
      return nextStep;
    })
  );
