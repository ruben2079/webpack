import React, { FC, createElement, useEffect, useState } from "react";
import { connect } from "react-redux";
import classNames from "classnames";
import { AutoComplete } from "@progress/kendo-react-dropdowns";
import { Button } from "@progress/kendo-react-buttons";
import {
  envelopIcon,
  fileTxtIcon,
  searchIcon,
  userIcon,
} from "@progress/kendo-svg-icons";
import { SvgIcon } from "@progress/kendo-react-common";
import { Badge, BadgeContainer } from "@progress/kendo-react-indicators";

import { AppState } from "../common/reducers/appReducer";
import { PMState } from "./reducers/pmReducer";
import { ErrorState } from "../common/reducers/errorReducer";
import { clearErrors, initApp } from "../common/actions/appAction";
import {
  createPortfolio,
  fetchAllPorfolio,
  fetchDownStream,
  filterPortfolio,
  getSinglePortfolio,
  initPM,
  openNewPortfolio,
  switchScreen,
  tiggerLoadingMask,
  updateNotification,
  updatePortfolio,
  updateReference,
  updateUserSettings,
} from "./actions/pmAction";
import { RootState } from "../common/store/reducers";
import { useErrorMonitor } from "../common/HOC/useErrorMonitor";
import { UseAuthorizeProps } from "../common/HOC/withAuthorize";
import AppHeader from "../common/components/AppHeader";
import HomeScreen from "./pages/HomeScreen";
import PortfolioScreen from "./pages/PortfolioScreen";
import Notifications from "../common/components/Notifications";
import { getUserInfo } from "../common/utils/ajaxManager";
import NewPortfolioDialog from "./components/NewPortfolioDialog";
import { ROUTERS } from "../common/utils/router";
import { APP_NAME, DEV_SUPPORT_EMAIL } from "./utils/constants";
import LoadingMask from "../common/components/LoadingMask";
import { getErrorMessage } from "./utils/utils";

import styles from "./PortfolioMasterIndex.module.scss";

const {
  container,
  search_bar,
  user_badge,
  user_info,
  content,
  notification_popup,
} = styles;

interface IPMIProps {
  className?: string;
}

interface IPMIStateProps extends UseAuthorizeProps {
  app: AppState;
  pm: PMState;
  error: ErrorState;
}

interface IPMIDispatchProps {
  initApp: () => void;
  initPM: () => void;
  clearErrors: () => void;
  switchScreen: (screen: string, options?: any) => void;
  getSinglePortfolio: (id: number | string, portfolioCode: string) => void;
  openNewPortfolio: (
    isOpen: boolean,
    portfolioCode?: string,
    isClone?: boolean
  ) => void;
  createPortfolio: (dataItem: any) => void;
  updatePortfolio: (dataItem: any) => void;
  filterPortfolio: (filters: FilterItem[]) => void;
  updateNotification: (notification: NotificationItem) => void;
  updateReference: (
    referenceId: string,
    dataItem: any,
    isUpdatePortfolio: boolean,
    isUpdatePortfolioOnly: boolean
  ) => void;
  tiggerLoadingMask: (isShow: boolean) => void;
  fetchDownStream?: (portfolioId: string, formType: string) => void;
  updateUserSettings?: (userUserSettings: any) => void;
  fetchAllPorfolio?: (isCoreDataOnly: boolean) => void;
}

const mapDProps = (state: RootState) => ({
  app: state.appState,
  pm: state.pmState,
  error: state.error,
});

const mapDispatch = {
  initApp: initApp,
  initPM: initPM,
  clearErrors: clearErrors,
  switchScreen: switchScreen,
  getSinglePortfolio: getSinglePortfolio,
  openNewPortfolio: openNewPortfolio,
  createPortfolio: createPortfolio,
  updatePortfolio: updatePortfolio,
  filterPortfolio: filterPortfolio,
  updateNotification: updateNotification,
  updateReference: updateReference,
  tiggerLoadingMask: tiggerLoadingMask,
  fetchDownStream: fetchDownStream,
  updateUserSettings: updateUserSettings,
  fetchAllPorfolio: fetchAllPorfolio,
};

type PMIProps = IPMIProps & IPMIStateProps & IPMIDispatchProps;

const screenSetting = {
  home: HomeScreen,
  portfolio: PortfolioScreen,
};

const PortfolioMasterIndex: FC<PMIProps> = (props: PMIProps) => {
  const {
    className,
    app,
    pm,
    error,
    isAuthorized = false,
    initApp,
    initPM,
    clearErrors,
    redirect,
    resetRouterState,
    refreshAuthToken,
    switchScreen,
    getSinglePortfolio,
    openNewPortfolio,
    createPortfolio,
    updatePortfolio,
    filterPortfolio,
    updateNotification,
    updateReference,
    tiggerLoadingMask,
    fetchDownStream,
    updateUserSettings,
    fetchAllPorfolio,
  } = props;
  const { isReady } = app;
  const {
    screen,
    showLoadingMask,
    isEditMode,
    isClone,
    feedFormName,
    isNewPortfolioOpen,
    portfolioCode,
    entitlement,
    notification,
    gridMeta,
    allDataFields,
    filteredMeta,
    filters,
    referenceData,
    referenceList,
    referenceObjects,
    portfolioData,
    userSettings,
  } = pm;
  const [isReadOnly, setIsReadOnly] = useState(true);
  const pmi_cn = classNames(container, className);
  const [role, setRole] = useState(null);

  useErrorMonitor(
    error,
    (url) => {
      if (!!url) {
        if (url === "notification") {
          const errorMessage = error?.authorize
            ? "Session expired, please try again."
            : getErrorMessage(error.response);
          error?.authorize && refreshAuthToken();
          updateNotification({
            level: "error",
            message: errorMessage,
          });
        } else {
          redirect({ pathname: url });
        }
      }
    },
    clearErrors
  );

  useEffect(() => {
    !isReady && initApp();
    !!isReady && !!isAuthorized && initPM();
  }, [isReady, isAuthorized]);

  useEffect(() => {
    if (isReady) {
      const index = window.location.search.indexOf("portfolio");
      const cleanSearch =
        index > -1
          ? window.location.search.substring(0, index - 1)
          : window.location.search;
      resetRouterState(
        null,
        !!portfolioCode
          ? `${
              cleanSearch.indexOf("?") > -1 ? `${cleanSearch}&` : "?"
            }portfolio=${portfolioCode}`
          : cleanSearch
      );
    }
  }, [portfolioCode]);

  useEffect(() => {
    const portfolioItem =
      !!portfolioCode && !!gridMeta
        ? gridMeta.find((item) => item.PortfolioCode === portfolioCode)
        : null;
    screen === "portfolio" &&
      !!portfolioItem &&
      getSinglePortfolio(portfolioItem.Id, portfolioCode);
  }, [screen, portfolioCode]);

  useEffect(() => {
    !!isReady &&
      !!isAuthorized &&
      !entitlement.CanRead &&
      redirect({ pathname: ROUTERS.usernotallowed?.path });
    if (!!entitlement) {
      const isReadOnly = !(
        entitlement?.CanSetup ||
        entitlement?.CanUpdate ||
        entitlement?.CanApprove ||
        (!!entitlement?.OwnedFields && !!entitlement?.OwnedFields.length)
      );
      setIsReadOnly(isReadOnly);
      setRole(
        isReadOnly
          ? "Reader"
          : entitlement?.CanApprove
          ? "Approver"
          : entitlement?.CanSetup
          ? "Admin"
          : "Data Owner"
      );
    }
  }, [entitlement]);

  const toggleDialog = () => {
    if (isNewPortfolioOpen) {
      openNewPortfolio(
        false,
        screen === "portfolio" ? portfolioCode : null,
        false
      );
    }
  };

  const createPortfolioHandler = (dataItem: any) => {
    tiggerLoadingMask(true);
    createPortfolio(dataItem);
  };

  const updatePortfolioHandler = (dataItem) => {
    tiggerLoadingMask(true);
    updatePortfolio(dataItem);
  };

  const updateReferenceHandler = (
    referenceId: string,
    dataItem: any,
    isUpdatePortfolio: boolean,
    isUpdatePortfolioOnly: boolean
  ) => {
    tiggerLoadingMask(true);
    updateReference(
      referenceId,
      dataItem,
      isUpdatePortfolio,
      isUpdatePortfolioOnly
    );
  };

  const fetchDownStreamHandler = (formType: string) => {
    tiggerLoadingMask(true);
    fetchDownStream(portfolioData.Id, formType);
  };

  const updateUserSettingsHandler = (userSettings: any) => {
    tiggerLoadingMask(true);
    updateUserSettings(userSettings);
  };

  const fetchAllPorfolioHandler = (isCoreDataOnly: any) => {
    tiggerLoadingMask(true);
    fetchAllPorfolio(isCoreDataOnly);
  };

  let screenProps = {
    entitlement,
    referenceList,
    referenceObjects,
    isReadOnly,
    allDataFields,
    switchScreen,
    openNewPortfolio,
    updatePortfolio: updatePortfolioHandler,
    filterPortfolio,
    ...(screen === "portfolio"
      ? {
          gridMeta,
          isEditMode,
          feedFormName,
          referenceData,
          portfolioCode,
          portfolioData,
          updateReference: updateReferenceHandler,
          fetchDownStream: fetchDownStreamHandler,
          fetchAllPorfolio: fetchAllPorfolioHandler,
        }
      : {
          allData: filteredMeta,
          filters,
          userSettings,
          updateUserSettings: updateUserSettingsHandler,
        }),
  };

  return (
    isReady && (
      <div className={pmi_cn}>
        <AppHeader
          appName={APP_NAME}
          // menuContentRender={() => (
          //   <AutoComplete
          //     className={search_bar}
          //     placeholder="Search Portfolio"
          //     suffix={() => <Button fillMode={"flat"} svgIcon={searchIcon} />}
          //   />
          // )}
          rightContentRender={() => (
            <div className={user_info}>
              <BadgeContainer>
                <SvgIcon icon={userIcon} />
                {!!role && (
                  <Badge
                    className={user_badge}
                    align={{
                      vertical: "top",
                      horizontal: "start",
                    }}
                    position={"outside"}
                    themeColor="secondary"
                  >
                    {role}
                  </Badge>
                )}
              </BadgeContainer>
              <div>{`${getUserInfo()?.givenName} ${
                getUserInfo()?.surname
              }`}</div>
              <a href={`mailto:${DEV_SUPPORT_EMAIL}`} title="Contact Dev Team">
                <SvgIcon icon={envelopIcon} />
              </a>
              <a
                href={`https://voya0.sharepoint.com/:w:/r/sites/IM-finance/IMPMO/VIMFS/Shared%20Documents/2%20-%20Workstreams/C.%20Data%20Platforms%20%26%20Distribution/C1.%20Voya%20Astra/C1.2%20Master%20Data%20(Portfolio%20and%20Security)/5.3%20Portfolio%20(Account)%20Master/User%20manual.docx?d=wdcd2c1607bbb40a1b360b89b7e220a91&csf=1&web=1&e=fbFpAf`}
                target="_blank"
                rel="noreferrer"
                title="User Manual"
              >
                <SvgIcon icon={fileTxtIcon} />
              </a>
            </div>
          )}
        />
        <div className={content}>
          {!!notification && (
            <Notifications
              className={notification_popup}
              level={notification?.level || "success"}
              isTriggered={!!notification}
              message={notification?.message || ""}
              onClose={() => {
                if (!!notification) {
                  updateNotification(null);
                  clearErrors();
                }
              }}
            />
          )}
          {(!isReady || !gridMeta || showLoadingMask) && <LoadingMask />}
          {createElement(screenSetting[screen], screenProps)}
          <NewPortfolioDialog
            isVisible={isNewPortfolioOpen}
            isClone={isClone}
            onClose={toggleDialog}
            onCreate={createPortfolioHandler}
            portfolioData={portfolioData}
            referenceList={referenceList}
            errorMessage={
              !!notification && notification.level === "error"
                ? notification.message
                : null
            }
          />
        </div>
      </div>
    )
  );
};

export default connect(mapDProps, mapDispatch)(PortfolioMasterIndex);
