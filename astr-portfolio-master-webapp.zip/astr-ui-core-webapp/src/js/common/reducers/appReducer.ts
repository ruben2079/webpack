import { produce } from 'immer';
import * as appTypes from '../actions/appAction.type';

export type AppState = {
  isReady: boolean;
  env?: string;
};

export const initAppState: AppState = {
  isReady: false,
  env: 'dev',
};

const appReducer = produce((state = initAppState, { type, payload } = {}) => {
  switch (type) {
    case appTypes.SET_APP_STATE:
      state = payload;
      break;
    default:
      break;
  }
  return state;
});

export default appReducer;
