import { produce } from "immer";
import * as appTypes from "../actions/appAction.type";

export type ErrorState = {
  epic: boolean;
  authorize: boolean;
  api: boolean;
  response: any;
};

const initErrorState: ErrorState = {
  epic: false,
  authorize: false,
  api: false,
  response: null,
};

const errorReducer = produce(
  (state = initErrorState, { type, payload } = {}) => {
    switch (type) {
      case appTypes.EPIC_ERROR:
        !state.epic && (state.epic = !!payload);
        state.response = payload.response;
        break;
      case appTypes.AUTHORIZE_ERROR:
        !state.authorize && (state.authorize = !!payload);
        state.response = payload.response;
        break;
      case appTypes.API_ERROR:
        !state.api && (state.api = !!payload);
        state.response = payload.response;
        break;
      case appTypes.CLEAR_ERRORS:
        state = initErrorState;
        break;
      default:
        break;
    }
    return state;
  }
);

export default errorReducer;
