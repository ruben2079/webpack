import { Observable, asyncScheduler, catchError, scheduled } from 'rxjs';

interface errorCallback {
  otherCallback?: (error: any) => void;
  backendCallback?: (error: any) => void;
  errorHandler?: (error: any) => void;
}

export const catchAjaxError = (callbacks?: errorCallback) => (source$) =>
  source$.pipe(
    catchError((error) => {
      if (!error.message) {
        return scheduled(
          [
            callbacks.errorHandler && callbacks.errorHandler(error),
            ...parseResult(callbacks.otherCallback, error),
          ],
          asyncScheduler
        );
      }

      const nextStep: any[] = [];
      return scheduled(
        [...nextStep, ...parseResult(callbacks.backendCallback, error)],
        asyncScheduler
      );
    })
  );

const parseResult = (callback: any, error: any) => {
  if (!callback) {
    return [];
  }

  const result: any[] | Observable<any> = callback(error) || [];
  return Array.isArray(result) ? result : [result];
};

export const checkAjaxErrors = (response: any[] | any) =>
  (Array.isArray(response) ? response : [response]).filter(
    (item: any) =>
      typeof item === 'object' &&
      !Array.isArray(item) &&
      !!item.type &&
      item.type.toLowerCase().includes('error')
  );
