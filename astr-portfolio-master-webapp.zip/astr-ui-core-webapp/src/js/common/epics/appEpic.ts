import { ofType } from "redux-observable";
import { Observable, switchMap } from "rxjs";
import * as appTypes from "../actions/appAction.type";
import * as appActions from "../actions/appAction";
import { AppState } from "../reducers/appReducer";
import { getEnv } from "../utils/utils";
import { checkAjaxErrors } from "./operators/catchAjaxError";

export const initAppEpic = (action$: Observable<ActionType>) =>
  action$.pipe(
    ofType(appTypes.INIT_APP),
    switchMap((args) => {
      const errors = checkAjaxErrors(args);
      const appState: AppState = {
        isReady: true,
        env: getEnv(),
      };
      return !!errors.length ? errors : [appActions.setAppState(appState)];
    })
  );
