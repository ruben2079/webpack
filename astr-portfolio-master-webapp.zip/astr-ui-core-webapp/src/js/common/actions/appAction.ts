import { AppState } from '../reducers/appReducer';
import * as appTypes from './appAction.type';

export const globalErrorHandler = (error: any) => ({
  type: appTypes.EPIC_ERROR,
  payload: error,
});

export const authorizeErrorHandler = (error: any) => ({
  type: appTypes.AUTHORIZE_ERROR,
  payload: error,
});

export const apiErrorHandler = (error: any) => ({
  type: appTypes.API_ERROR,
  payload: error,
});

export const clearErrors = () => ({
  type: appTypes.CLEAR_ERRORS,
});

export const initApp = (): ActionType => ({ type: appTypes.INIT_APP });

export const setAppState = (payload: AppState): ActionType => ({
  type: appTypes.SET_APP_STATE,
  payload,
});
