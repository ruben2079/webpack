export const AUTHORIZE_ERROR = 'AUTHORIZE_ERROR';
export const API_ERROR = 'API_ERROR';
export const EPIC_ERROR = 'EPIC_ERROR';
export const CLEAR_ERRORS = 'CLEAR_ERRORS';
export const INIT_APP = 'INIT_APP';
export const SET_APP_STATE = 'SET_APP_STATE';
