import React, { FC } from "react";
import classNames from "classnames";
import { MsalAuthenticationResult } from "@azure/msal-react";

import styles from "./UserNotAllowed.module.scss";

const { container } = styles;

interface IUNAProps extends MsalAuthenticationResult {
  className?: string;
  appName: string;
}

type UNAProps = IUNAProps;

const UserNotAllowed: FC<UNAProps> = (props: UNAProps) => {
  const { className, appName = "Application" } = props;

  const una_cn = classNames(container, className);

  return (
    <div className={una_cn}>
      <h1>User Not Allowed</h1>
      <div>
        {`Session expired or no access of ${appName}. Please try `}
        <a href="/">{appName}</a>
        {` again or contact the `}
        <a href="mailto:VoyaIMHelpDesk@voya.com">HelpDesk Team</a>
      </div>
    </div>
  );
};

export default UserNotAllowed;
