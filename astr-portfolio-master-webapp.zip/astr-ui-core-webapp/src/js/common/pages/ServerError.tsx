import React, { FC, useEffect } from "react";
import classNames from "classnames";

import styles from "./ServerError.module.scss";

const { container } = styles;

interface ISEProps {
  className?: string;
  appName: string;
  email: string;
}

type SEProps = ISEProps;

const ServerError: FC<SEProps> = (props: SEProps) => {
  const { className, appName = "Application", email = "" } = props;

  const se_cn = classNames(container, className);

  useEffect(() => {
    setTimeout(() => {
      window.location.href = "/";
    }, 60 * 1000);
  });

  return (
    <div className={se_cn}>
      <h1>Server Error</h1>
      <div>
        {`Please try `}
        <a href="/">{appName}</a>
        {` again or contact the `}
        <a href={`mailto:${email}`}>Dev Team</a>
      </div>
    </div>
  );
};

export default ServerError;
