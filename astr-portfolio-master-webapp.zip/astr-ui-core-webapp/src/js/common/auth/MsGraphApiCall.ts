import { addHTPHeader } from "../utils/ajaxManager";
import { AUTH_HTTP_HEADER } from "../utils/constants";

export async function callMsGraph(
  msalInstance,
  scope,
  graphConfig,
  isneedGraph = true
) {
  const account = msalInstance.getActiveAccount();
  if (!account) {
    throw Error(
      "No active account! Verify a user has been signed in and setActiveAccount has been called."
    );
  }

  const response = await msalInstance.acquireTokenSilent({
    ...scope,
    account: account,
  });

  const headers = new Headers();
  const bearer = `Bearer ${response.accessToken}`;

  headers.append(AUTH_HTTP_HEADER, bearer);

  !isneedGraph && addHTPHeader(AUTH_HTTP_HEADER, bearer);

  const options = {
    method: "GET",
    headers: headers,
  };
  return isneedGraph
    ? fetch(graphConfig.graphMeEndpoint, options)
        .then((response) => response.json())
        .catch((error) => console.log(error))
    : new Promise((resolve) => resolve(bearer));
}
