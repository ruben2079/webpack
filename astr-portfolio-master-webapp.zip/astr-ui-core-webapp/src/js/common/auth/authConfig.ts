import {
  BrowserCacheLocation,
  Configuration,
  PopupRequest,
} from "@azure/msal-browser";
import { isDebugMode } from "../utils/utils";
import { ROUTERS } from "../utils/router";

// Config object to be passed to Msal on creation
export const msalConfig: Configuration = {
  auth: {
    clientId: null,
    authority:
      "https://login.microsoft.com/e3054106-a46a-4dc0-b86d-2ba84a24cdc4",
    redirectUri: "/",
    postLogoutRedirectUri: ROUTERS.usernotallowed.path,
    navigateToLoginRequestUrl: true,
  },
  cache: {
    cacheLocation: BrowserCacheLocation.LocalStorage,
    storeAuthStateInCookie: false,
  },
  system: {
    allowNativeBroker: false, // Disables WAM Broker
    loggerOptions: {
      loggerCallback: (level, message) => {
        isDebugMode() && console.log("[MSAL] Logger: ", message);
      },
      piiLoggingEnabled: false,
    },
  },
};

// Add here scopes for id token to be used at MS Identity Platform endpoints.
export const protectedResources = {
  apiTodoList: {
    endpoint: "/Portfolios",
    scopes: {
      read: ["api://54d57f3b-6bc6-4f5c-a4cf-23168bfe9c12/PortfolioMaster.User"],
    },
  },
};

export const loginRequest: PopupRequest = {
  scopes: ["User.Read"],
  redirectUri: "/",
};

export const apiRequest: any = {
  dev: {
    scopes: ["api://MasterDev/PortfolioMaster.User"],
    redirectUri: "/",
  },
  test: {
    scopes: ["api://MasterTest/PortfolioMaster.User"],
    redirectUri: "/",
  },
  prod: {
    scopes: ["api://Master/PortfolioMaster.User"],
    redirectUri: "/",
  },
};

export const graphConfig = {
  graphMeEndpoint: "https://graph.microsoft.com/v1.0/me",
};

export const clientId: any = {
  dev: "54d57f3b-6bc6-4f5c-a4cf-23168bfe9c12",
  test: "cec5d933-976d-4a9d-acbc-3d622367ebc8",
  prod: "9a15041a-8b25-415f-b0ff-d63c1ae1aa0e",
};
