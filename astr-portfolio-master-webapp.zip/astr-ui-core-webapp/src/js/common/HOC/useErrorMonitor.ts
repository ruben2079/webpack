import { useEffect } from "react";
import { ErrorState } from "../reducers/errorReducer";
import { ROUTERS } from "../utils/router";

export const useErrorMonitor = (
  error: ErrorState,
  redirect?: Function,
  reset?: Function
) => {
  useEffect(() => {
    const redirect_url = error?.authorize
      ? "notification"
      : error?.api
      ? ROUTERS.servererror?.path
      : error?.epic
      ? "notification"
      : null;
    !!redirect && redirect(redirect_url);
    return () => {
      (error?.api || error?.authorize) && !!reset && reset();
    };
  }, [error]);
};
