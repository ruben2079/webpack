import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import hoistNonReactStatics from "hoist-non-react-statics";
import { MsalAuthenticationTemplate, useMsal } from "@azure/msal-react";
import {
  AccountInfo,
  InteractionRequiredAuthError,
  InteractionStatus,
  InteractionType,
} from "@azure/msal-browser";

import { callMsGraph } from "../auth/MsGraphApiCall";
import { getUserInfo, setUserInfo } from "../utils/ajaxManager";
import { CustomNavigationClient } from "../auth/NavigationClient";
import { getEnv, getLocationParam } from "../utils/utils";
import { URL_PARAMS } from "../utils/constants";
import { ROUTERS } from "../utils/router";

type routerParams = {
  pathname: string;
  search?: string;
  state?: any;
  isReplace?: boolean;
};

export type UseAuthorizeProps = {
  routerLocation?: any;
  isAuthorized?: boolean;
  redirect?: (params: routerParams) => void;
  resetRouterState?: (state?: any, search?: string) => void;
  refreshAuthToken: () => void;
};

export const withAuthorize = (
  WrappedComponent: any,
  authConfig: AuthConfig
) => {
  const AuthorizeComponent = (props: any) => {
    const navigate = useNavigate();
    const location = useLocation();
    const { instance, inProgress } = useMsal();
    let [graphData, setGraphData] = useState<any>(null);
    const navigationClient = new CustomNavigationClient(navigate);
    const env = getEnv();
    const { apiRequest, loginRequest, graphConfig } = authConfig;
    instance.setNavigationClient(navigationClient);
    const needLoginPage =
      env === "test" && getLocationParam(URL_PARAMS.test) === "true";
    const requestLogin = () => {
      callMsGraph(instance, loginRequest, graphConfig, authConfig.graphConfig)
        .then((response) => {
          setUserInfo(response);
          callMsGraph(instance, apiRequest[env], graphConfig, false).then(
            (response) => {
              setGraphData(response);
            }
          );
        })
        .catch((e) => {
          if (e instanceof InteractionRequiredAuthError) {
            instance.acquireTokenRedirect({
              ...loginRequest,
              account: instance.getActiveAccount() as AccountInfo,
            });
          }
        });
    };

    const requestAuthToken = () => {
      needLoginPage
        ? instance
            .loginPopup({
              ...loginRequest,
              prompt: "select_account",
              popupWindowAttributes: {
                popupPosition: {
                  top: 100,
                },
              },
            })
            .then((response: any) => {
              setGraphData(response);
              requestLogin();
            })
            .catch((e) => {
              redirectFC({ pathname: ROUTERS.usernotallowed.path });
            })
        : requestLogin();
    };

    useEffect(() => {
      if (
        !getUserInfo() &&
        !graphData &&
        inProgress === InteractionStatus.None
      ) {
        requestAuthToken();
      }
    }, [inProgress, graphData, instance]);

    const redirectFC = ({
      pathname,
      search,
      state,
      isReplace = false,
    }: routerParams) => {
      search === undefined && (search = window.location.search || "");
      const path = {
        pathname,
        queryString: search,
      };
      navigate(`${path.pathname}${path.queryString}`, {
        replace: isReplace,
        state,
      });
    };

    const authProps: UseAuthorizeProps = {
      routerLocation: location,
      isAuthorized: !!getUserInfo() && graphData !== null,
      redirect: redirectFC,
      resetRouterState: (state?: any, search?: string) => {
        redirectFC({
          pathname: location.pathname,
          search,
          state,
          isReplace: true,
        });
      },
      refreshAuthToken: () => {
        requestAuthToken();
      },
    };

    const wrappedComponent = <WrappedComponent {...props} {...authProps} />;

    const authRequest = {
      ...loginRequest,
    };

    return (
      <MsalAuthenticationTemplate
        interactionType={InteractionType.Redirect}
        authenticationRequest={authRequest}
      >
        {wrappedComponent}
      </MsalAuthenticationTemplate>
    );
  };

  AuthorizeComponent.displayName = `withAuthorize(${getDisplayName(
    WrappedComponent
  )})`;

  return hoistNonReactStatics(AuthorizeComponent, WrappedComponent);
};

const getDisplayName = (WrappedComponent: any): string => {
  return WrappedComponent.displayName || WrappedComponent.name || "Component";
};
