import { AjaxConfig } from "rxjs/ajax";
import { ajax } from "./ajaxManager";
import { isDev, isLocal } from "./utils";
import { map } from "rxjs";
import { catchAjaxError } from "../epics/operators/catchAjaxError";
import {
  apiErrorHandler,
  authorizeErrorHandler,
  globalErrorHandler,
} from "../actions/appAction";

const fetch = (request: AjaxConfig) => {
  return ajax(request).pipe(
    map((response) => {
      const str = response.response as string;

      try {
        return JSON.parse(str);
      } catch (error) {
        return str;
      }
    }),
    catchAjaxError({
      backendCallback: (error: any) => {
        if (!isLocal() && !isDev()) {
          if (error?.status === 401 || error?.status === 403) {
            return authorizeErrorHandler(error);
          }
          if (error?.status === 504 || error?.status === 404) {
            return apiErrorHandler(error);
          }
        }
        return globalErrorHandler(error);
      },
      errorHandler: globalErrorHandler,
    })
  );
};

export const get = (
  url: string,
  payload?: {
    contentType?: string;
    param?: string;
    timeout?: number;
    directUrl?: boolean;
  }
) => {
  const {
    contentType = "application/json",
    timeout,
    directUrl = false,
  } = payload || {};

  let headers = { "Content-Type": contentType };

  !!directUrl &&
    (headers = {
      ...headers,
      // ...{ "Access-Control-Allow-Origin": "*" },
    });

  const request: AjaxConfig = {
    url: url,
    method: "GET",
    headers: headers,
    timeout,
  };
  return fetch(request);
};

export const post = (
  url: string,
  payload?: {
    contentType?: string;
    param?: string;
    body?: any;
    method?: "POST" | "PUT" | "DELETE";
    responseType?: "arraybuffer" | "blob" | "document" | "json" | "text";
    timeout?: number;
    directUrl?: boolean;
  }
) => {
  const {
    contentType = "application/json",
    body = "",
    method = "POST",
    responseType = "json",
    timeout,
    directUrl = false,
  } = payload || {};

  let headers = { "Content-Type": contentType };

  !!directUrl &&
    (headers = {
      ...headers,
      // ...{ "Access-Control-Allow-Origin": "*" },
    });

  const request: AjaxConfig = {
    url: url,
    method,
    headers,
    body,
    responseType,
    timeout,
  };

  !!directUrl && (request.withCredentials = true);

  return fetch(request);
};
