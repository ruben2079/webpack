import ServerError from "../pages/ServerError";
import UserNotAllowed from "../pages/UserNotAllowed";

export const ROUTERS: RouterConfig = {
  servererror: {
    pageId: "servererror",
    path: "/servererror",
    desc: "Server Error",
    visable: false,
    auth: false,
    component: ServerError,
    isLowerLaneOnly: false,
    entitlments: [],
  },
  usernotallowed: {
    pageId: "usernotallowed",
    path: "/usernotallowed",
    desc: "User Not Allowed",
    visable: false,
    auth: false,
    component: UserNotAllowed,
    isLowerLaneOnly: false,
    entitlments: [],
  },
};
