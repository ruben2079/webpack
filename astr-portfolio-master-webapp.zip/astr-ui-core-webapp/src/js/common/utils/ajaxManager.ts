import { Observable, Subject, takeUntil } from "rxjs";
import { ajax as rsAjax, AjaxConfig, AjaxResponse } from "rxjs/ajax";

let httpHeaders = {};
const abortAllAjaxNotifier: Subject<void> = new Subject<void>();
let userInfo: any = null;
const timeout: number = 30 * 1000;
// const timeout: number = 10 * 1000;
const defaultMethod: string = "POST";
const defaultResponseType: XMLHttpRequestResponseType = "text";

export const abort = () => {
  abortAllAjaxNotifier.next();
  window.stop();
};

export const addHTPHeader = (headerName: string, headerValue: string) => {
  httpHeaders = { ...httpHeaders, [headerName]: headerValue };
};

export const getHTPHeader = (headerName: string) => {
  return httpHeaders[headerName];
};

export const getUserInfo = (): any => userInfo;

export const setUserInfo = (info?: any) => {
  userInfo = info;
};

const supportMethod = (method: string): boolean =>
  ["GET", "POST", "PUT", "DELETE"].includes(method.toUpperCase());

export const ajax = (request: AjaxConfig): Observable<AjaxResponse<any>> => {
  const { method = defaultMethod } = request;

  request.headers = { ...httpHeaders, ...request.headers };
  request.timeout =
    !!request.timeout || request.timeout === 0 ? request.timeout : timeout;

  if (!supportMethod(method)) {
    request.method = defaultMethod;
    request.headers.set("X-HTTP-Method-Override", request.method);
  }
  !request.responseType && (request.responseType = defaultResponseType);

  const ajax$ = rsAjax(request);

  return ajax$.pipe(takeUntil(abortAllAjaxNotifier));
};
