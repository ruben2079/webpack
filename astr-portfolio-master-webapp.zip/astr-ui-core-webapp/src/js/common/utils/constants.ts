export const URL_PARAMS = {
  debug: "debug",
  theme: "theme",
  mock: "mock",
  test: "test",
};

export const AUTH_HTTP_HEADER = "Authorization";
