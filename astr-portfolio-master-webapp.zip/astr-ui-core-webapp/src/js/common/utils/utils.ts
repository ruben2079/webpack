import { URL_PARAMS } from "./constants";

export const getLocationParam = (paramName: string) => {
  let { search } = window.location;
  const { href } = window.location;
  search === "" && (search = href.split("?")[1] || "");
  const key = `${paramName}=`;
  let value = "";
  if (search.indexOf(key) > -1) {
    value = search.split(key)[1].split("&")[0];
  }
  return !!value ? decodeURIComponent(value) : null;
};

export const getEnv = (): string => {
  const env = isLocal()
    ? "dev"
    : window.location.hostname.includes("dev")
    ? "dev"
    : window.location.hostname.includes("test")
    ? "test"
    : "prod";
  return env;
};

export const isLocal = (): boolean => {
  return process.env.NODE_ENV !== "production";
};

export const isDev = (): boolean => {
  return getEnv() === "dev";
};

export const isDebugMode = (): boolean => {
  const debug = getLocationParam(URL_PARAMS.debug);
  return !!debug ? debug === "true" : isLocal();
};

export const getAppInfo = (defaultContext: string): AppInfoItem => {
  const { pathname } = window.location;
  const contextIndex = pathname.indexOf(defaultContext ?? "/");
  const endContextIndex = pathname.indexOf("/", contextIndex);
  const context =
    endContextIndex > -1 ? pathname.substring(0, endContextIndex) : pathname;
  const contextPrefix = pathname.substring(0, contextIndex);
  const appName =
    endContextIndex > -1 ? pathname.substring(context.length + 1) : "";
  return {
    pathname,
    context,
    contextPrefix,
    appName,
  };
};

export const getAppUrl = (defaultContext: string, appName?: string): string => {
  const appInfo = getAppInfo(defaultContext);
  const { context } = appInfo;
  return appName ? `${context}/${appName}` : context;
};

export const getRandomInt = (max: number) => {
  return Math.floor(Math.random() * max);
};

export const getDateStringforSaving = (date?: Date | string): string => {
  try {
    return (!!date ? (typeof date === "string" ? new Date(date) : date) : null)
      .toISOString()
      .split("T")[0];
  } catch (error) {
    return null;
  }
};

export const convertDateLocalfromUTC = (date: string): Date => {
  const dateStr = date.split("-");
  try {
    const newDate = new Date(
      Date.UTC(Number(dateStr[0]), Number(dateStr[1]) - 1, Number(dateStr[2]))
    );
    newDate.setDate(newDate.getDate() + 1);
    return newDate;
  } catch (error) {
    return null;
  }
};

export const dateFormatterUTCtoLocal = (date: string, isDateOnly = true) => {
  //UTC -> Local
  const newDate = !!date
    ? date.includes("Z")
      ? new Date(date)
      : convertDateLocalfromUTC(date)
    : null;
  return !!newDate
    ? isDateOnly
      ? newDate.toLocaleDateString()
      : newDate.toLocaleString()
    : null;
};
