import React, { createContext, useEffect, useState } from "react";

export const THEMES = { DARK: "dark", LIGHT: "light" };
export const DEFAULT_THEME = THEMES.LIGHT;

export interface IThemeContext {
  theme: string;
  toggleTheme: (newTheme?: string) => void | any;
}

interface IThemeContextProps {
  App: string;
  children: any;
}

export const ThemeContext = createContext<IThemeContext>({
  theme: DEFAULT_THEME,
  toggleTheme: () => {},
});

const ThemeProvider = ({ App, children }: IThemeContextProps) => {
  const [theme, setTheme] = useState(DEFAULT_THEME);
  const [appId, setAppId] = useState(App);

  const switchTheme = (theme: string) => {
    document.getElementById(appId)?.classList.toggle(`${appId}-${theme}`);
    document.body?.classList.toggle(`vim-ds-${theme}-theme`);
  };

  const toggleTheme = (newTheme?: string) => {
    !newTheme && (newTheme = theme);
    if (newTheme !== theme) {
      switchTheme(theme);
      setTheme(
        Object.values(THEMES).includes(newTheme) ? newTheme : DEFAULT_THEME
      );
    }
  };

  useEffect(() => {
    switchTheme(theme);
  }, [theme]);

  useEffect(() => {
    document.body.classList.add("vim-ds");
    setAppId(App);
  }, [App]);

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export default ThemeProvider;
