import logger from 'redux-logger';
import { RootState, rootReducer } from './reducers';
import { createEpicMiddleware } from 'redux-observable';
import { configureStore } from '@reduxjs/toolkit';
import { rootEpic } from './epics';
import { isDebugMode, isLocal } from '../utils/utils';

export default function configureAppStore(preloadedState?: RootState) {
  const epicMiddleware = createEpicMiddleware();
  const middlewares = [epicMiddleware];

  isDebugMode() && middlewares.push(logger as any);

  const store = configureStore({
    reducer: rootReducer(),
    preloadedState,
    middleware: (getDefaultMiddleware) =>
      getDefaultMiddleware({ serializableCheck: false }).concat(middlewares),
  });

  if (isLocal() && module.hot) {
    module.hot.accept('./reducers', () => {
      store.replaceReducer(rootReducer());
    });
  }

  epicMiddleware.run(rootEpic as any);

  return store;
}
