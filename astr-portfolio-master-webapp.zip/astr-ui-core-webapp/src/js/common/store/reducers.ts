import { combineReducers } from 'redux';
import appState, { AppState } from '../reducers/appReducer';
import pmState, { PMState } from '../../portfoliomaster/reducers/pmReducer';
import error, { ErrorState } from '../reducers/errorReducer';

export type RootState = {
  appState: AppState;
  error: ErrorState;
  pmState: PMState;
};

export const rootReducer = () => combineReducers({ appState, error, pmState });
