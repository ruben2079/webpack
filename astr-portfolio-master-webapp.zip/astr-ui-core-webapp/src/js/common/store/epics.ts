import { combineEpics } from 'redux-observable';
import * as appEpic from '../epics/appEpic';
import * as pmEpic from '../../portfoliomaster/epics/pmEpic';

export const rootEpic = combineEpics(
  ...Object.values({ ...appEpic, ...pmEpic })
);
