import React, { FC, useEffect, useRef, useState } from "react";
import classNames from "classnames";
import { Button } from "@progress/kendo-react-buttons";
import { DatePicker } from "@progress/kendo-react-dateinputs";
import { calendarIcon } from "@progress/kendo-svg-icons";
import { SvgIcon } from "@progress/kendo-react-common";
import { Popup } from "@progress/kendo-react-popup";

import StyledDialog from "./StyledDialog";

import styles from "./StyledRangeDatePicker.module.scss";

const {
  styled_range_datepicker,
  range_datepicker_popup,
  range_datepicker_content,
  cal_icon,
} = styles;

export type Date_Range_Data = {
  min: Date;
  max: Date;
};

interface ISRDPProps {
  className?: string;
  title?: string;
  value?: Date_Range_Data;
  isDialog?: boolean;
  isOpen?: boolean;
  onSave?: (e, value: Date_Range_Data) => any;
  onClose?: () => any;
}

type SRDPProps = ISRDPProps;

const StyledRangeDatePicker: FC<SRDPProps> = (props: SRDPProps) => {
  const {
    className,
    title,
    value,
    isDialog = false,
    isOpen = false,
    onSave,
    onClose,
  } = props;
  const ref = useRef(null);
  const [visibleFormDialog, setVisibleFormDialog] = useState(isOpen);
  const [min, setMin] = useState(null);
  const [max, setMax] = useState(null);

  const resetDates = () => {
    const min = !!value ? value.min : null;
    const max = !!value ? value.max : null;
    setMin(min);
    setMax(max);
    return { min, max };
  };

  useEffect(() => {
    !!value && resetDates();
  }, [value]);

  const styledRangeDatePicker_cn = classNames(
    styled_range_datepicker,
    "k-input k-datepicker k-input-md k-rounded-md k-input-solid",
    className
  );

  const toggleDialog = () => {
    setVisibleFormDialog(!visibleFormDialog);
  };

  const getDisplayText = (date: Date) =>
    date ? date.toLocaleDateString() : "";

  const onSubmit = (e) => {
    onSave && onSave(e, { min, max });
    toggleDialog();
  };

  const children = (
    <div className={range_datepicker_content}>
      <DatePicker
        width={150}
        placeholder="Start - MM/DD/YYYY"
        defaultValue={!!value ? value.min : null}
        value={min}
        {...(max ? { max } : {})}
        onChange={(e) => {
          setMin(e.target.value);
        }}
      />
      <div>_</div>
      <DatePicker
        width={150}
        defaultValue={!!value ? value.min : null}
        placeholder="End - MM/DD/YYYY"
        value={max}
        {...(min ? { min } : {})}
        onChange={(e) => {
          setMax(e.target.value);
        }}
      />
      <Button
        onClick={(e) => {
          setMin(null);
          setMax(null);
        }}
      >
        Clear
      </Button>
      {isDialog ? (
        <Button
          onClick={(e) => {
            resetDates();
          }}
        >
          Reset
        </Button>
      ) : (
        <Button
          themeColor="primary"
          onClick={(e) => {
            onSubmit(e);
          }}
        >
          Ok
        </Button>
      )}
    </div>
  );

  return (
    <>
      <div
        className={styledRangeDatePicker_cn}
        onClick={() => {
          toggleDialog();
          resetDates();
          onClose && onClose();
        }}
        ref={ref}
      >
        <div className={"k-input-inner"}>{`${getDisplayText(
          min
        )} - ${getDisplayText(max)}`}</div>
        <div className={cal_icon}>
          <SvgIcon icon={calendarIcon} themeColor="primary" />
        </div>
      </div>
      {isDialog ? (
        <StyledDialog
          title={title || "Select Date Range"}
          isOpen={!isDialog || visibleFormDialog}
          onClose={() => {
            resetDates();
            toggleDialog();
          }}
          saveText={"Filter"}
          onSave={(e) => {
            onSubmit(e);
          }}
        >
          {children}
        </StyledDialog>
      ) : (
        <Popup
          anchor={ref.current}
          show={visibleFormDialog}
          popupClass={range_datepicker_popup}
        >
          {children}
        </Popup>
      )}
    </>
  );
};

export default StyledRangeDatePicker;
