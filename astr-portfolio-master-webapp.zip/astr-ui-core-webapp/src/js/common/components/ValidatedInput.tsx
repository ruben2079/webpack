import React, { FC } from "react";
import classNames from "classnames";
import { Input, InputProps } from "@progress/kendo-react-inputs";
import { Hint } from "@progress/kendo-react-labels";

import VarcharInput from "./VarcharInput";

import styles from "./ValidatedInput.module.scss";

const { container, validated_input_hint, validated_input_error_hint } = styles;

interface ICustomProps {
  hint?: string;
  isVarchar?: boolean;
  isValidationFailed?: boolean;
}

type VIProps = InputProps & ICustomProps;

const ValidatedInput: FC<VIProps> = (props: VIProps) => {
  const {
    hint,
    isValidationFailed = false,
    isVarchar = false,
    ...restProps
  } = props;

  const hintClassName = classNames(validated_input_hint, {
    [validated_input_error_hint]: isValidationFailed,
  });

  return (
    <div className={container}>
      {isVarchar ? <VarcharInput {...restProps} /> : <Input {...restProps} />}
      {hint && <Hint className={hintClassName}>{hint}</Hint>}
    </div>
  );
};

export default ValidatedInput;
