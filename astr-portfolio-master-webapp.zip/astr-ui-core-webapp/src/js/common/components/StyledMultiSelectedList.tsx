import React, { FC, useEffect, useRef, useState } from "react";
import classNames from "classnames";
import { Button } from "@progress/kendo-react-buttons";
import { caretAltDownIcon, searchIcon } from "@progress/kendo-svg-icons";
import { SvgIcon } from "@progress/kendo-react-common";
import { Popup } from "@progress/kendo-react-popup";
import {
  ListBox,
  ListBoxDragEvent,
  ListBoxItemClickEvent,
  ListBoxToolbar,
  ListBoxToolbarClickEvent,
  processListBoxData,
  processListBoxDragAndDrop,
} from "@progress/kendo-react-listbox";
import _ from "lodash";

import StyledDialog from "./StyledDialog";

import styles from "./StyledMultiSelectedList.module.scss";
import { Input } from "@progress/kendo-react-inputs";

const {
  styled_multiselected_list,
  multiselected_list_popup,
  multiselected_list_content,
  arrow_icon,
  list_container,
  list_panel,
  btn_content,
  option_list,
  option_input,
  search_icon,
} = styles;

interface ISMSLProps {
  className?: string;
  title?: string;
  value?: string[];
  options?: any[];
  itemRender?: any;
  isDialog?: boolean;
  isOpen?: boolean;
  onSave?: (e, value: string[]) => any;
  onClose?: () => any;
}

type SMSLProps = ISMSLProps;

const NAME_FIELD = "name";
const SELECTED_FIELD = "selected";

const StyledMultiSelectedList: FC<SMSLProps> = (props: SMSLProps) => {
  const {
    className,
    title,
    value = null,
    options = null,
    itemRender,
    isDialog = false,
    isOpen = false,
    onSave,
    onClose,
  } = props;
  const ref = useRef(null);
  const [visibleFormDialog, setVisibleFormDialog] = useState(isOpen);
  const [filteredOptions, setFilteredOptions] = useState([]);
  const [filterValue, setFilterValue] = useState(null);
  const [state, setState] = useState({
    allOptions: [],
    selectedItems: [],
    draggedItem: {},
  });
  const { allOptions, selectedItems, draggedItem } = state;
  const inputRef = useRef(null);

  const sort = (list: any[]) => _.sortBy(list, NAME_FIELD);

  const createListItem = (list: string[]) =>
    list.map((item) => ({
      [NAME_FIELD]: item,
      [SELECTED_FIELD]: false,
    }));

  const updateState = (newState) =>
    setState({
      ...newState,
      allOptions: sort(newState.allOptions),
      selectedItems: sort(newState.selectedItems),
    });

  const resetOptions = (isClear = false) => {
    const newValue =
      !isClear && !!value ? (Array.isArray(value) ? value : [value]) : [];
    updateState({
      ...state,
      allOptions: createListItem(_.difference(options || [], newValue)),
      selectedItems: createListItem(newValue),
    });
  };

  useEffect(() => {
    !!options && resetOptions();
  }, [options, value]);

  const styledMultiSelectedList_cn = classNames(
    styled_multiselected_list,
    "k-dropdownlist k-picker k-picker-md k-rounded-md k-picker-solid",
    className
  );

  const toggleDialog = () => {
    setVisibleFormDialog(!visibleFormDialog);
  };

  const onSubmit = (e) => {
    onSave &&
      onSave(
        e,
        selectedItems.map((item) => item[NAME_FIELD])
      );
    toggleDialog();
  };
  const handleDragStart = (e: ListBoxDragEvent) => {
    setState({
      ...state,
      draggedItem: e.dataItem,
    });
  };

  const handleDrop = (e: ListBoxDragEvent) => {
    let result: any = processListBoxDragAndDrop(
      allOptions,
      selectedItems,
      draggedItem,
      e.dataItem,
      NAME_FIELD
    );
    updateState({
      ...state,
      allOptions: result.listBoxOneData,
      selectedItems: result.listBoxTwoData,
    });
  };

  const handleItemClick = (e, data, connectedData) => {
    const newState = {
      ...state,
      [data]: state[data].map((item) => {
        if (item.name === e.dataItem.name) {
          item[SELECTED_FIELD] = !item[SELECTED_FIELD];
        } else if (!e.nativeEvent.ctrlKey) {
          item[SELECTED_FIELD] = false;
        }
        return item;
      }),
      [connectedData]: state[connectedData].map((item) => {
        item[SELECTED_FIELD] = false;
        return item;
      }),
    };
    updateState(newState);
  };

  const handleToolBarClick = (e: ListBoxToolbarClickEvent) => {
    let toolName: string = e.toolName || "";
    let result: any = processListBoxData(
      allOptions,
      selectedItems,
      toolName,
      SELECTED_FIELD
    );
    updateState({
      ...state,
      allOptions: result.listBoxOneData,
      selectedItems: result.listBoxTwoData,
    });
  };

  const onOptionsChange = (e) => {
    const filterValue = e.target.value;
    setFilterValue(!!filterValue ? filterValue : null);
  };

  useEffect(() => {
    setFilteredOptions(
      !!filterValue
        ? allOptions.filter((item) =>
            item.name.toLowerCase().includes(filterValue.toLowerCase())
          )
        : allOptions
    );
  }, [filterValue, selectedItems]);

  const children = (
    <div className={multiselected_list_content}>
      <div className={list_container}>
        <div className={classNames(list_panel, option_list)}>
          <h4>Options</h4>
          <Input
            className={option_input}
            ref={inputRef}
            type="text"
            value={filterValue || ""}
            onChange={onOptionsChange}
          />
          <SvgIcon icon={searchIcon} className={search_icon} />
          <ListBox
            style={{ height: 300, width: 350 }}
            data={!!filterValue ? filteredOptions : allOptions}
            textField={NAME_FIELD}
            selectedField={SELECTED_FIELD}
            item={itemRender}
            onItemClick={(e: ListBoxItemClickEvent) => {
              handleItemClick(e, "allOptions", "selectedItems");
            }}
            onDragStart={handleDragStart}
            onDrop={handleDrop}
            toolbar={() => {
              return (
                <ListBoxToolbar
                  tools={[
                    "transferTo",
                    "transferFrom",
                    "transferAllTo",
                    "transferAllFrom",
                  ]}
                  data={allOptions}
                  dataConnected={selectedItems}
                  onToolClick={handleToolBarClick}
                />
              );
            }}
          />
        </div>
        <div className={list_panel}>
          <h4>Selected</h4>
          <ListBox
            style={{ height: 300, width: 300 }}
            data={selectedItems}
            textField={NAME_FIELD}
            selectedField={SELECTED_FIELD}
            item={itemRender}
            onItemClick={(e: ListBoxItemClickEvent) =>
              handleItemClick(e, "selectedItems", "allOptions")
            }
            onDragStart={handleDragStart}
            onDrop={handleDrop}
          />
        </div>
      </div>
      <div className={btn_content}>
        <Button onClick={(e) => resetOptions()}>Reset</Button>
        <Button
          themeColor="primary"
          onClick={(e) => {
            onSubmit(e);
          }}
        >
          Ok
        </Button>
      </div>
    </div>
  );

  const dispalyTitle = title || "Select List";

  return (
    <>
      <div
        className={styledMultiSelectedList_cn}
        onClick={() => {
          toggleDialog();
          resetOptions();
          onClose && onClose();
        }}
        ref={ref}
      >
        <div className={"k-input-inner"}>
          {!!selectedItems.length
            ? `${selectedItems.length} selected`
            : dispalyTitle}
        </div>
        <div className={arrow_icon}>
          <SvgIcon icon={caretAltDownIcon} themeColor="primary" />
        </div>
      </div>
      {isDialog ? (
        <StyledDialog
          title={dispalyTitle}
          isOpen={!isDialog || visibleFormDialog}
          onClose={() => {
            resetOptions();
            toggleDialog();
          }}
          saveText={"Filter"}
          onSave={(e) => {
            onSubmit(e);
          }}
        >
          {children}
        </StyledDialog>
      ) : (
        <Popup
          anchor={ref.current}
          show={visibleFormDialog}
          popupClass={multiselected_list_popup}
        >
          {children}
        </Popup>
      )}
    </>
  );
};

export default StyledMultiSelectedList;
