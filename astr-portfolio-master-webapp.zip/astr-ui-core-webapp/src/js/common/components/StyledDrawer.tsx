import React, { FC, useEffect, useState } from "react";
import classNames from "classnames";
import {
  Drawer,
  DrawerContent,
  DrawerItemProps,
  DrawerSelectEvent,
} from "@progress/kendo-react-layout";
import { Button } from "@progress/kendo-react-buttons";
import { menuIcon } from "@progress/kendo-svg-icons";

import styles from "./StyledDrawer.module.scss";

const { styled_drawer, drawer_title } = styles;

interface ISDProps {
  className?: string;
  children?: any;
  title?: any;
  isMulti?: boolean;
  indexField?: string;
  shortcutItems?: DrawerItemProps[];
  onSelect?: (selectedItems) => void;
}

type SDProps = ISDProps;

const StyledDrawer: FC<SDProps> = (props: SDProps) => {
  const {
    className,
    children,
    title,
    isMulti = false,
    indexField,
    shortcutItems = [],
    onSelect,
  } = props;

  const styledDrawer_cn = classNames(styled_drawer, className);
  const [expanded, setExpanded] = useState(false);
  const [selectedItems, setSelectedItems] = useState([]);

  useEffect(() => {
    const selected = [];
    shortcutItems.map(
      (item, index) =>
        !!item.selected &&
        selected.push(!!indexField ? item[indexField] : index)
    );
    setSelectedItems(selected);
  }, [shortcutItems]);

  const handleClick = () => {
    setExpanded(!expanded);
  };

  const handleMultiSelect = (newItem) => {
    let newSelected = isMulti ? [...selectedItems] : [newItem];
    if (isMulti) {
      if (!newSelected.includes(newItem)) {
        newSelected.push(newItem);
      } else {
        newSelected.splice(newSelected.indexOf(newItem), 1);
      }
    }
    setSelectedItems(newSelected);
    return newSelected;
  };

  const onSelectHandler = (index) => {
    onSelect && onSelect(handleMultiSelect(index));
  };

  return (
    <div className={styledDrawer_cn}>
      <div className="custom-toolbar">
        <Button
          svgIcon={menuIcon}
          fillMode="flat"
          onClick={handleClick}
          title={expanded ? "Close" : "Open"}
        />
        {expanded && <div className={drawer_title}>{title}</div>}
      </div>
      <Drawer
        expanded={expanded}
        position={"start"}
        mode={"push"}
        mini={true}
        width={300}
        items={shortcutItems.map((item, index) => ({
          ...item,
          selected: selectedItems.includes(
            !!indexField ? item[indexField] : index
          ),
        }))}
        onSelect={(e: DrawerSelectEvent) =>
          onSelectHandler(
            !!indexField ? shortcutItems[e.itemIndex][indexField] : e.itemIndex
          )
        }
      >
        <DrawerContent>{children}</DrawerContent>
      </Drawer>
    </div>
  );
};

export default StyledDrawer;
