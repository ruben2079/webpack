import React, {
  FC,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import classNames from "classnames";
import {
  Grid,
  GridColumn,
  GridColumnMenuCheckboxFilter,
  GridColumnMenuFilter,
  GridColumnReorderEvent,
  GridToolbar,
} from "@progress/kendo-react-grid";
import {
  setGroupIds,
  getGroupIds,
  setExpandedState,
} from "@progress/kendo-react-data-tools";
import { filterBy, process } from "@progress/kendo-data-query";
import { Button } from "@progress/kendo-react-buttons";
import _ from "lodash";
import {
  ExcelExport,
  ExcelExportColumn,
} from "@progress/kendo-react-excel-export";
import {
  chevronDoubleDownIcon,
  chevronDoubleUpIcon,
  fileExcelIcon,
  rotateIcon,
  saveIcon,
} from "@progress/kendo-svg-icons";

import { CustomLockedCell } from "./CustomLockedCell";
import StyledDrawer from "./StyledDrawer";
import { dateFormatterUTCtoLocal } from "../utils/utils";
import StyledMultiSelectedList from "./StyledMultiSelectedList";
import StyledRangeDatePicker from "./StyledRangeDatePicker";

import styles from "./DataGrid.module.scss";

const { container, data_grid, grid_title, col_drawer } = styles;

const exclude_filed = ["InnerExport", "Action"];

export type columnDefProps = {
  field: string;
  title: string;
  width?: string;
  filterable?: boolean;
  filter?: "boolean" | "text" | "numeric" | "date";
  filterMenu?: boolean;
  filter_type?: "list";
  filter_options?: string[];
  filter_item_render?: (props: any) => any;
  locked?: boolean;
  reorderable?: boolean;
  hide?: boolean;
  colindex?: number;
  cell?: (props) => any;
  filterCell?: (props) => any;
};

export type GridDefProps = {
  sortable: boolean;
  initialSort?: any[];
  pageable: boolean | object;
  filterable: boolean;
  groupable: boolean;
  pageSize: number;
  hasExpandToggle?: boolean;
  hasExportExcel?: boolean;
  exportFileName?: string;
  groupConfig?: any[];
  resizable: boolean;
  reorderable: boolean;
  hideColumn: boolean;
  rowExportFn?: boolean;
  rowExportFnButtonTextRender?: (dataItem) => any;
  rowExportFnButtonDisabled?: (dataItem) => boolean | boolean;
  rowExportFieldsGenerator?: (
    rowProps: any,
    cb: (exportFields: any) => void
  ) => void;
  toolbarRender?: () => void;
};

interface IDGProps {
  className?: string;
  gridDef?: GridDefProps;
  columnDefs?: columnDefProps[];
  gridData?: any[];
  title?: any;
  isResetFilter?: boolean;
  resetCallback?: () => any;
  onSaveUserSettings?: (colDefs: columnDefProps[]) => void;
}

type DGProps = IDGProps;

const gridDefProps = [
  "sortable",
  "pageable",
  "filterable",
  "groupable",
  "pageSize",
  "resizable",
  "reorderable",
];

const row_export_def = {
  field: "InnerExport",
  title: " ",
  filterable: false,
  sortable: false,
  Locked: true,
  width: "250px",
};

export const default_gridDef = {
  sortable: false,
  initialSort: null,
  pageable: false,
  filterable: false,
  groupable: false,
  pageSize: 5,
  hasExpandToggle: false,
  hasExportExcel: false,
  exportFileName: "Export",
  groupConfig: [],
  resizable: false,
  reorderable: false,
  hideColumn: false,
  toolbarRender: null,
  rowExportFn: false,
  rowExportFnButtonTextRender: null,
  rowExportFnButtonDisabled: false,
  rowExportFieldsGenerator: null,
};

const DataGrid: FC<DGProps> = (props: DGProps) => {
  const {
    className,
    gridDef = default_gridDef,
    columnDefs = [],
    gridData = null,
    title,
    isResetFilter = false,
    resetCallback,
    onSaveUserSettings,
  } = props;
  const createDataState = (data, dataState) => {
    const newDataState = process(data, dataState);
    gridDef.groupable &&
      setGroupIds({
        data: newDataState.data,
        group: dataState.group,
      });
    return newDataState;
  };

  const initDataState = {
    filter: null,
    take: gridDef.pageSize,
    skip: 0,
    group: gridDef.groupConfig || [],
    sort: gridDef.initialSort || [],
  };

  const [dataState, setDataState] = useState(initDataState);
  const [gridColumnDefs, setGridColumnDefs] = useState(columnDefs);
  const [resultState, setResultState] = useState({ data: [] });
  const [collapsedState, setCollapsedState] = useState([]);
  const [pageSizeValue, setPageSizeValue] = useState();
  const [exportFields, setExportFields] = useState(null);
  const [selectedDataItem, setSelectedDataItem] = useState(null);

  useEffect(() => {
    !!gridData && setResultState(createDataState(gridData, dataState));
  }, [gridData, dataState]);

  useEffect(() => {
    !!exportFields && setTimeout(() => excelExport(), 1000);
  }, [exportFields]);

  useEffect(() => {
    if (
      !!isResetFilter &&
      !!dataState.filter &&
      !!dataState.filter.filters &&
      !!dataState.filter.filters.length
    ) {
      setDataState({ ...dataState, filter: [] });
    }
    resetCallback && resetCallback();
  }, [isResetFilter]);

  useEffect(() => {
    setGridColumnDefs(columnDefs || []);
  }, [columnDefs]);

  const dataGrid_cn = classNames(container, className);

  const ColumnMenu = (props) => {
    return (
      <div>
        <GridColumnMenuFilter {...props} expanded={true} />
      </div>
    );
  };
  const ColumnMenuCheckboxFilter = (props) => {
    return (
      <div>
        <GridColumnMenuCheckboxFilter
          {...props}
          data={gridData}
          expanded={true}
        />
      </div>
    );
  };

  const onDataStateChange = useCallback((event) => {
    setDataState(event.dataState);
  }, []);

  const pageChange = (event) => {
    const targetEvent = event.targetEvent;
    const take =
      targetEvent.value === "All" ? gridData.length : event.page.take;
    if (targetEvent.value) {
      setPageSizeValue(targetEvent.value);
    }
    onDataStateChange({
      dataState: {
        ...dataState,
        ...event.page,
        take,
      },
    });
  };

  const onExpandChange = useCallback(
    (event) => {
      const item = event.dataItem;
      if (item.groupId) {
        const collapsedIds = !event.value
          ? [...collapsedState, item.groupId]
          : collapsedState.filter((groupId) => groupId !== item.groupId);
        setCollapsedState(collapsedIds);
      }
    },
    [collapsedState]
  );

  const onGroupsToggle = useCallback(() => {
    const dataStateWithoutPaging = createDataState(gridData, {
      group: dataState.group,
    });
    setCollapsedState(
      collapsedState.length
        ? []
        : getGroupIds({
            data: dataStateWithoutPaging.data,
          })
    );
  }, [collapsedState, dataState]);

  const newData = setExpandedState({
    data: resultState.data,
    collapsedIds: collapsedState,
  });

  const groupProps = !!gridDef.groupable
    ? { onExpandChange: onExpandChange, expandField: "expanded" }
    : {};

  const pageProps = !!gridDef.pageable
    ? {
        onPageChange: pageChange,
        skip: dataState.skip,
        take: dataState.take,
        total: !!gridData
          ? !!dataState.filter
            ? filterBy(gridData, dataState.filter).length
            : gridData.length
          : 0,
        pageable:
          !!gridDef.pageable && typeof gridDef.pageable === "object"
            ? {
                ...gridDef.pageable,
                ...{ pageSizeValue: pageSizeValue, responsive: true },
              }
            : gridDef.pageable,
      }
    : {};

  const reorderProps = !!gridDef.reorderable
    ? {
        onColumnReorder: (event: GridColumnReorderEvent) => {
          let newCols = _.unionBy(
            event.target["_columns"],
            gridColumnDefs,
            "field"
          );
          setGridColumnDefs(newCols);
        },
      }
    : {};

  const _export = useRef(null);
  const excelExport = () => {
    if (_export.current !== null) {
      _export.current.save();
    }
  };

  const rowExportCallback = (exportFields: any) => {
    !!exportFields && setExportFields(exportFields);
  };

  const fileName = `${(!!gridDef.rowExportFn && !!selectedDataItem
    ? selectedDataItem.formName
    : gridDef.exportFileName || "Export"
  ).replace(/ /g, "_")}_${new Date().toISOString()}.xlsx`;

  const handleListFilterChange = (e, selected, field) => {
    let newState = { ...dataState };
    const { filter = { filters: [] } } = newState;
    const newfilter = !!selected.length
      ? [
          {
            logic: "or",
            filters: (selected || []).map((item) => ({
              field,
              operator: "eq",
              value: item,
            })),
          },
        ]
      : [];
    newState = {
      ...newState,
      filter: {
        ...filter,
        filters: _.concat(
          !!filter && !!filter.filters
            ? filter.filters.filter(
                (item) =>
                  (!!item.filters ? item.filters[0].field : item.field) !==
                  field
              )
            : [],
          newfilter
        ),
        logic: "and",
      },
    };
    !newState.filter.filters.length &&
      (newState = {
        ...newState,
        filter: null,
      });
    setDataState(newState);
  };

  const handleDateFilterChange = (e, dates, field) => {
    const { min, max } = dates;
    const filters = [];
    let newState = { ...dataState };
    const { filter = { filters: [] } } = newState;
    if (!!min) {
      filters.push({
        field: field,
        operator: "gte",
        value: min.toISOString(),
      });
    }
    if (!!max) {
      filters.push({
        field: field,
        operator: "lte",
        value: max.toISOString(),
      });
    }
    newState = {
      ...newState,
      filter: {
        ...filter,
        filters: _.concat(
          filters,
          !!filter && !!filter.filters
            ? filter.filters.filter((item) => item.field !== field)
            : []
        ),
        logic: "and",
      },
    };
    setDataState(newState);
  };

  const { colDefs, allDrawerCol } = useMemo(() => {
    const allDrawerCol = [];
    const colDefs = [];
    !!gridColumnDefs &&
      !!gridColumnDefs.length &&
      gridColumnDefs.forEach((colProps, index) => {
        let newCol = {
          ...colProps,
          reorderable: !colProps.locked,
          colindex: index,
        };
        if (!!colProps.locked) {
          const oldcellFn = newCol.cell;
          newCol = {
            ...newCol,
            cell: (props) => CustomLockedCell(props, oldcellFn),
          };
        }
        if (!!gridDef.hideColumn) {
          !!newCol.title &&
            !exclude_filed.includes(newCol.field) &&
            allDrawerCol.push({
              text: newCol.title,
              selected: !colProps.hide,
              field: newCol.field,
            });
        }
        colDefs.push(newCol);
      });
    return {
      colDefs,
      allDrawerCol: _.sortBy(allDrawerCol, "text"),
    };
  }, [gridColumnDefs, gridDef]);

  const dataFilters = useMemo(() => {
    let dataFilters = {};
    const { filter } = dataState;
    !!filter &&
      !!filter.filters &&
      !!filter.filters.length &&
      filter.filters.forEach((item) => {
        const { field, value, operator, filters } = item;
        if (!filters) {
          const colDef = gridColumnDefs.find((col) => col.field === field);
          const isDate = colDef.filter === "date";
          !dataFilters[field] &&
            (dataFilters = {
              ...dataFilters,
              [field]: isDate ? { min: null, max: null } : [],
            });
          operator.includes("eq") && dataFilters[field].push(value);
          operator.includes("gt") && (dataFilters[field].min = new Date(value));
          operator.includes("lt") && (dataFilters[field].max = new Date(value));
        } else {
          filters.forEach((subFilter) => {
            const {
              field: subfield,
              value: subValue,
              operator: subOperator,
            } = subFilter;
            !dataFilters[subfield] &&
              (dataFilters = {
                ...dataFilters,
                [subfield]: [],
              });
            subOperator.includes("eq") && dataFilters[subfield].push(subValue);
          });
        }
      });
    return dataFilters;
  }, [dataState]);

  return (
    <div className={dataGrid_cn}>
      <ExcelExport
        data={
          !!selectedDataItem
            ? [selectedDataItem]
            : !!dataState.filter
            ? filterBy(gridData, dataState.filter)
            : gridData
        }
        ref={_export}
        fileName={fileName}
      >
        {(exportFields || gridColumnDefs)
          .filter((col) => !exclude_filed.includes(col.field))
          .map((col, index) => {
            return (
              <ExcelExportColumn
                key={`export_${index}`}
                {..._.omit(col, ["width"])}
              />
            );
          })}
      </ExcelExport>
      {!!gridDef.hideColumn && (
        <StyledDrawer
          className={col_drawer}
          title={
            <>
              <div>Columns</div>
              <Button
                svgIcon={rotateIcon}
                title="Reset"
                fillMode="flat"
                onClick={(e) => {
                  setGridColumnDefs(columnDefs || []);
                }}
              />
              <Button
                svgIcon={saveIcon}
                title="Save"
                fillMode="flat"
                onClick={(e) => {
                  onSaveUserSettings &&
                    onSaveUserSettings(
                      gridColumnDefs.filter(
                        (col) => !exclude_filed.includes(col.field)
                      )
                    );
                }}
              />
            </>
          }
          isMulti={true}
          shortcutItems={allDrawerCol}
          indexField={"field"}
          onSelect={(selectedItems) => {
            const newColDefs = gridColumnDefs.map((item) => {
              const isHide =
                !exclude_filed.includes(item.field) &&
                !selectedItems.includes(item.field);
              const isLocked = !!item.locked;
              return {
                ...item,
                locked: isLocked && !isHide,
                hide: !!item.title && isHide,
              };
            });
            setGridColumnDefs(newColDefs);
          }}
        />
      )}
      <Grid
        className={data_grid}
        data={newData}
        {...dataState}
        onDataStateChange={onDataStateChange}
        {..._.pick(gridDef, gridDefProps)}
        {...groupProps}
        {...pageProps}
        {...reorderProps}
      >
        <GridToolbar>
          <div>
            {typeof title === "string" ? (
              <h2 className={grid_title}>{title}</h2>
            ) : (
              <div className={grid_title}>{title}</div>
            )}
            {!!gridDef.hasExpandToggle && !!(dataState.group || []).length && (
              <Button
                onClick={onGroupsToggle}
                className="k-button-flat k-button-flat-base"
                svgIcon={
                  collapsedState.length
                    ? chevronDoubleDownIcon
                    : chevronDoubleUpIcon
                }
              >
                {collapsedState.length ? "Expand" : "Collapse"} Groups
              </Button>
            )}
            {!!gridDef.hasExportExcel && (
              <Button
                title="Export Excel"
                svgIcon={fileExcelIcon}
                onClick={excelExport}
                className="k-button-flat k-button-flat-base"
              >
                Export
              </Button>
            )}
          </div>
          {gridDef.toolbarRender && gridDef.toolbarRender()}
        </GridToolbar>
        {colDefs.map(
          (colProps) =>
            !colProps.hide && (
              <GridColumn
                key={`${colProps.field}_col`}
                {...colProps}
                columnMenu={
                  !!colProps?.filterMenu
                    ? (colProps?.filter || "text") === "numeric"
                      ? ColumnMenu
                      : ColumnMenuCheckboxFilter
                    : null
                }
                {...(colProps.filter_type === "list"
                  ? {
                      filterCell: (props) => {
                        return (
                          <div className="k-filtercell">
                            <StyledMultiSelectedList
                              value={dataFilters[colProps.field]}
                              options={colProps.filter_options}
                              title={`Select ${colProps.title}`}
                              itemRender={colProps.filter_item_render}
                              onSave={(e, value) =>
                                handleListFilterChange(e, value, colProps.field)
                              }
                            />
                          </div>
                        );
                      },
                    }
                  : colProps.filter === "date"
                  ? {
                      filterCell: (props) => (
                        <StyledRangeDatePicker
                          title={`Filter Date Range${
                            !!colProps.title ? ` - ${colProps.title}` : ""
                          }`}
                          value={dataFilters[props.field]}
                          onSave={(event, dates) => {
                            handleDateFilterChange(
                              event,
                              dates,
                              colProps.field
                            );
                          }}
                        />
                      ),
                      cell: (props) => {
                        return (
                          <td>
                            {dateFormatterUTCtoLocal(
                              props.dataItem[props.field]
                            )}
                          </td>
                        );
                      },
                    }
                  : {})}
              />
            )
        )}
        {!!gridDef.rowExportFn && (
          <GridColumn
            key={`row_export_col`}
            {...row_export_def}
            cell={(props) => (
              <td>
                <Button
                  themeColor="primary"
                  disabled={
                    typeof gridDef.rowExportFnButtonDisabled === "boolean"
                      ? gridDef.rowExportFnButtonDisabled
                      : gridDef.rowExportFnButtonDisabled(props.dataItem)
                  }
                  onClick={() => {
                    gridDef.rowExportFieldsGenerator(
                      props.dataItem,
                      rowExportCallback
                    );
                    setSelectedDataItem(props.dataItem);
                  }}
                >
                  {!!gridDef.rowExportFnButtonTextRender
                    ? gridDef.rowExportFnButtonTextRender(props.dataItem)
                    : "Export"}
                </Button>
              </td>
            )}
          />
        )}
      </Grid>
    </div>
  );
};

export default DataGrid;
