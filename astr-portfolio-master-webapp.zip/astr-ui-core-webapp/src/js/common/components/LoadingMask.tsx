import React, { FC } from "react";
import classNames from "classnames";
import { Loader } from "@progress/kendo-react-indicators";

import styles from "./LoadingMask.module.scss";

const { loading_mask, loading_mask_icon } = styles;

interface ILMProps {
  className?: string;
  type?: "pulsing" | "infinite-spinner" | "converging-spinner";
}

type LMProps = ILMProps;

const LoadingMask: FC<LMProps> = (props: LMProps) => {
  const { className, type = "converging-spinner" } = props;

  const loadingMask_cn = classNames(loading_mask, "k-loading-mask", className);

  return (
    <div className={loadingMask_cn}>
      <Loader type={type} className={loading_mask_icon} />
    </div>
  );
};

export default LoadingMask;
