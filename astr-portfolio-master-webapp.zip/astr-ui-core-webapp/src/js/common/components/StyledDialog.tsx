import React, { FC } from "react";
import classNames from "classnames";
import { Dialog } from "@progress/kendo-react-dialogs";
import { Button } from "@progress/kendo-react-buttons";

import styles from "./StyledDialog.module.scss";

const { styled_dialog, error_msg, action_btns } = styles;

interface ISDProps {
  className?: string;
  title?: any;
  children?: any;
  isOpen?: boolean;
  onClose?: (e) => any;
  onSave?: (e) => any;
  hasSave?: boolean;
  disableSave?: boolean;
  hasClose?: boolean;
  disableClose?: boolean;
  closeText?: string;
  saveText?: string;
  errorMessage?: string;
}

type SDProps = ISDProps;

const StyledDialog: FC<SDProps> = (props: SDProps) => {
  const {
    className,
    title,
    children,
    isOpen,
    onClose,
    onSave,
    hasSave = true,
    disableSave = false,
    hasClose = true,
    disableClose = false,
    closeText = "Cancel",
    saveText = "Save",
    errorMessage,
  } = props;

  const styledDialog_cn = classNames(styled_dialog, className);

  return (
    isOpen && (
      <Dialog className={styledDialog_cn} title={title} onClose={onClose}>
        {children}
        <div className={action_btns}>
          <div className={error_msg}>{errorMessage}</div>
          {hasClose && (
            <Button
              className={"k-button-flat k-button-flat-base"}
              onClick={onClose}
              disabled={disableClose}
            >
              {closeText}
            </Button>
          )}
          {hasSave && (
            <Button
              themeColor="primary"
              onClick={onSave}
              disabled={disableSave}
            >
              {saveText}
            </Button>
          )}
        </div>
      </Dialog>
    )
  );
};

export default StyledDialog;
