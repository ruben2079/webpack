import React, { FC } from "react";
import {
  Input,
  InputChangeEvent,
  InputProps,
} from "@progress/kendo-react-inputs";

interface VIProps extends InputProps {
  regpattern?: string | RegExp;
}

const default_reg = /^[a-zA-Z0-9]+$/;

const VarcharInput: FC<VIProps> = (props: VIProps) => {
  const { regpattern = default_reg } = props;
  const handleChange = (event: InputChangeEvent) => {
    if (event.value === "" || RegExp(regpattern).test(event.value)) {
      props.onChange(event);
    }
  };

  return <Input {...props} onChange={handleChange} />;
};

export default VarcharInput;
