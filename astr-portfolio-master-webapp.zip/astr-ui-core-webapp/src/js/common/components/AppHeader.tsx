import React, { FC } from "react";
import classNames from "classnames";
import {
  AppBar,
  AppBarSection,
  AppBarSpacer,
} from "@progress/kendo-react-layout";

import styles from "./AppHeader.module.scss";

const { app_header, center_section, small_spacing, logo, title } = styles;

interface IAHProps {
  className?: string;
  appName?: string;
  menuContentRender?: () => any;
  rightContentRender?: () => any;
}

type AHProps = IAHProps;

const AppHeader: FC<AHProps> = (props: AHProps) => {
  const { className, appName, menuContentRender, rightContentRender } = props;

  const appHeader_cn = classNames(app_header, className);

  return (
    <AppBar className={appHeader_cn}>
      <AppBarSection>
        <div className={logo} />
      </AppBarSection>
      <AppBarSpacer className={small_spacing} />
      <AppBarSection>
        <div className={title}>{appName}</div>
      </AppBarSection>
      <AppBarSpacer className={small_spacing} />
      <AppBarSection className={center_section}>
        {menuContentRender && menuContentRender()}
      </AppBarSection>
      <AppBarSpacer />
      <AppBarSection>
        {rightContentRender && rightContentRender()}
      </AppBarSection>
    </AppBar>
  );
};

export default AppHeader;
