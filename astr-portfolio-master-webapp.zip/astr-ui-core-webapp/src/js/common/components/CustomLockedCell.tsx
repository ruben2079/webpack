import React from "react";
import {
  GRID_COL_INDEX_ATTRIBUTE,
  GridCellProps,
} from "@progress/kendo-react-grid";
import { useTableKeyboardNavigation } from "@progress/kendo-react-data-tools";
import _ from "lodash";

export const CustomLockedCell = (props: GridCellProps, cellFn) => {
  const field = props.field || "";
  const value = props.dataItem[field];
  const navigationAttributes = useTableKeyboardNavigation(props.id);
  const newProps = {};

  Object.keys(props).forEach((prop) => {
    let propName = prop;
    switch (prop) {
      case "ariaColumnIndex":
        propName = "aria-colindex";
        break;
      case "isSelected":
        propName = "aria-selected";
        break;
      case "columnIndex":
        propName = GRID_COL_INDEX_ATTRIBUTE;
        break;
      default:
        break;
    }
    newProps[propName] = props[prop];
  });

  let tdProps = _.pick(newProps, [
    "style",
    "className",
    "colSpan",
    "aria-colindex",
    "aria-selected",
    GRID_COL_INDEX_ATTRIBUTE,
  ]);
  tdProps = {
    ...tdProps,
    role: "gridcell",
    ...navigationAttributes,
  };

  return !cellFn ? (
    <td {...tdProps}>
      {value === null ? "" : props.dataItem[field].toString()}
    </td>
  ) : (
    cellFn(newProps, tdProps)
  );
};
