import React, { FC, useEffect, useState } from "react";
import classNames from "classnames";
import { Notification } from "@progress/kendo-react-notification";
import { Slide } from "@progress/kendo-react-animation";

import styles from "./Notifications.module.scss";

const { notification } = styles;

interface INTFProps {
  className?: string;
  isTriggered?: boolean;
  level: "success" | "warning" | "error" | "info" | "none";
  message?: any;
  interval?: number;
  onClose?: () => void;
}

type NTFProps = INTFProps;

const Notifications: FC<NTFProps> = (props: NTFProps) => {
  const {
    className,
    isTriggered = false,
    level = "info",
    message,
    interval = 5000,
    onClose,
  } = props;
  const [isPopup, setIsPopup] = useState(false);

  useEffect(() => {
    setIsPopup(isTriggered);
    setTimeout(() => onMsgClose(), interval);
  }, [isTriggered]);

  const onMsgClose = () => {
    setIsPopup(false);
    onClose && onClose();
  };

  const notifications_cn = classNames(notification, className);

  return (
    <div className={notifications_cn}>
      <Slide direction={isPopup ? "down" : "up"}>
        {isPopup && (
          <Notification
            key={level}
            type={{
              style: level,
              icon: true,
            }}
            closable={level === "error"}
            onClose={onMsgClose}
          >
            {message}
          </Notification>
        )}
      </Slide>
    </div>
  );
};

export default Notifications;
