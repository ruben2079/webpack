declare module "*.module.scss";

declare type ActionType = {
  type: string;
  payload?: any;
};

declare type RouterItem = {
  pageId: string;
  path: string;
  desc: string;
  visable?: boolean;
  auth?: boolean;
  component?: any;
  isLowerLaneOnly?: boolean;
  entitlments: string[];
};

declare type RouterConfig = { [pageId: string]: RouterItem };

declare type AppInfoItem = {
  pathname: string;
  context: string;
  contextPrefix: string;
  appName: string;
};

declare type FilterItem = {
  key: string;
  value?: any;
  isExclude?: boolean;
};

declare type NotificationItem = {
  level: "error" | "success" | "warning" | "info" | "none";
  message?: string;
};

declare type AuthConfig = {
  apiRequest: any;
  loginRequest: any;
  graphConfig: any;
};
