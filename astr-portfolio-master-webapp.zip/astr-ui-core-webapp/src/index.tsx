import React, { createElement } from "react";
import { createRoot } from "react-dom/client";
import { Provider } from "react-redux";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { MsalProvider } from "@azure/msal-react";
import {
  AuthenticationResult,
  EventMessage,
  EventType,
  PublicClientApplication,
} from "@azure/msal-browser";
import {
  loginRequest,
  apiRequest,
  graphConfig,
} from "./js/common/auth/authConfig";

import {
  APP_ID,
  APP_NAME,
  DEFAULT_CONTEXT_NAME,
  DEV_SUPPORT_EMAIL,
  PM_ROUTERS,
} from "./js/portfoliomaster/utils/constants";
import configureAppStore from "./js/common/store/configureStore";
import { getAppUrl, getEnv } from "./js/common/utils/utils";
import ThemeProvider from "./js/common/context/ThemeContext";
import { withAuthorize } from "./js/common/HOC/withAuthorize";
import { ROUTERS } from "./js/common/utils/router";
import { clientId, msalConfig } from "./js/common/auth/authConfig";

import "./css/sass/main.scss";

const renderApp = () => {
  const root = createRoot(document.getElementById(APP_ID) as HTMLElement);
  const url_prefix = getAppUrl(DEFAULT_CONTEXT_NAME);
  const msalInstance = new PublicClientApplication({
    ...msalConfig,
    auth: { ...msalConfig.auth, clientId: clientId[getEnv()] },
  });
  const authConfig = { loginRequest, apiRequest, graphConfig };
  msalInstance.initialize().then(() => {
    // Account selection logic is app dependent. Adjust as needed for different use cases.
    const accounts = msalInstance.getAllAccounts();
    if (!!accounts.length) {
      msalInstance.setActiveAccount(accounts[0]);
    }

    msalInstance.addEventCallback((event: EventMessage) => {
      if (event.eventType === EventType.LOGIN_SUCCESS && event.payload) {
        const payload = event.payload as AuthenticationResult;
        const account = payload.account;
        msalInstance.setActiveAccount(account);
      }
    });

    root.render(
      <ThemeProvider App={APP_ID}>
        <Provider store={configureAppStore()}>
          <BrowserRouter basename={url_prefix}>
            <MsalProvider instance={msalInstance}>
              <Routes>
                {Object.values({ ...PM_ROUTERS, ...ROUTERS }).map(
                  (router: RouterItem) => {
                    const { pageId } = router;
                    const appType = router.component;
                    let props: any = !router.auth ? { appName: APP_NAME } : {};
                    router.pageId === "servererror" &&
                      (props = {
                        ...props,
                        email: DEV_SUPPORT_EMAIL,
                      });
                    return (
                      <Route
                        key={pageId}
                        path={router.path}
                        element={createElement(
                          !!router.auth
                            ? withAuthorize(appType, authConfig)
                            : appType,
                          props
                        )}
                      />
                    );
                  }
                )}
              </Routes>
            </MsalProvider>
          </BrowserRouter>
        </Provider>
      </ThemeProvider>
    );
  });
};

renderApp();
