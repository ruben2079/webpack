export const environment = {
  production: true,
  msalConfig: {
    auth: {
      authority:
        'https://login.microsoft.com/e3054106-a46a-4dc0-b86d-2ba84a24cdc4',
      scopes: ['user.read'],
    },
  },
  apiConfig: {
    uri: 'https://graph.microsoft.com/v1.0/me',
  },
};
