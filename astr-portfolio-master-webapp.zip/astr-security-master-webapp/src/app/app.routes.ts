import { Routes } from '@angular/router';
import { MsalGuard } from '@azure/msal-angular';
import { UserNotAllowedComponent } from './layout/user-not-allowed/user-not-allowed.component';
import { ServerErrorComponent } from './layout/server-error/server-error.component';
import { LayoutComponent } from './layout/layout.component';

export const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'security',
  },
  {
    path: 'security',
    loadChildren: () =>
      import('./layout/layout.module').then((m) => m.MainLayoutModule),
    canActivate: [MsalGuard],
    component: LayoutComponent,
  },

  {
    path: 'usernotallowed',
    component: UserNotAllowedComponent,
  },

  {
    path: '**',
    component: ServerErrorComponent,
  },
];
