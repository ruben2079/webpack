import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import {
  MsalBroadcastService,
  MsalModule,
  MsalService,
} from '@azure/msal-angular';
import { SharedService } from './core/services/shared.service';
import { Observable, filter, map } from 'rxjs';
import {
  AccountInfo,
  IPublicClientApplication,
  InteractionStatus,
} from '@azure/msal-browser';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, MsalModule, RouterOutlet, RouterLink],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnInit {
  constructor(
    private readonly msalBroadcastService: MsalBroadcastService,
    private readonly msalService: MsalService,
    private readonly sharedService: SharedService
  ) {
    let body = document.body.classList;
    body.add('vim-ds-light-theme');
    body.add('vim-ds');
  }

  ngOnInit(): void {
    this.getActiveAccount().subscribe((account) => {
      this.sharedService.setUserName(this.getUserName(account));
    });
  }

  private getActiveAccount(): Observable<AccountInfo | null> {
    return this.msalBroadcastService.inProgress$.pipe(
      filter((status: string) => status == InteractionStatus.None),
      map(() => {
        const instance: IPublicClientApplication = this.msalService.instance;
        const activeAccount: AccountInfo | null = instance.getActiveAccount();
        if (activeAccount != null) return activeAccount;

        const accounts: AccountInfo[] = instance.getAllAccounts();
        if (accounts.length > 0) {
          const [firstAccount] = accounts;
          instance.setActiveAccount(firstAccount);
          return firstAccount;
        }

        return null;
      })
    );
  }

  private getUserName(account: AccountInfo | null): string {
    if (!account) return '';

    const accountStr = JSON.stringify(account);
    const accountObj = JSON.parse(accountStr);
    if (
      accountObj.idTokenClaims.given_name &&
      accountObj.idTokenClaims.family_name
    ) {
      return (
        accountObj.idTokenClaims.given_name +
        ' ' +
        accountObj.idTokenClaims.family_name
      );
    }

    return account.username;
  }
}
