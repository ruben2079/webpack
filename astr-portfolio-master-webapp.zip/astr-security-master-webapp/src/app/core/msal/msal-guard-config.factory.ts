import { MsalGuardConfiguration } from '@azure/msal-angular';
import { InteractionType } from '@azure/msal-browser';
import { environment } from '../../../environments/environment';
import { apiScopes } from './msal-instance.factory';
import { getEnv } from '../utils/utils';

export function MSALGuardConfigFactory(envConfig: any): MsalGuardConfiguration {
  const env = getEnv();
  return {
    interactionType: InteractionType.Redirect,
    authRequest: {
      scopes: [...environment.msalConfig.auth.scopes, ...apiScopes[env]],
    },
    loginFailedRoute: '/login-failed',
  };
}
