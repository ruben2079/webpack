import {
  BrowserCacheLocation,
  IPublicClientApplication,
  LogLevel,
  PublicClientApplication,
} from '@azure/msal-browser';
import { environment } from '../../../environments/environment';
import { getEnv } from '../utils/utils';

export function MSALInstanceFactory(envConfig: any): IPublicClientApplication {
  const env = getEnv();
  return new PublicClientApplication({
    auth: {
      clientId: clientId[env],
      authority: environment.msalConfig.auth.authority,
      redirectUri: '/',
      postLogoutRedirectUri: '/',

      navigateToLoginRequestUrl: true,
    },
    cache: {
      cacheLocation: BrowserCacheLocation.LocalStorage,
      storeAuthStateInCookie: false,
    },
    system: {
      allowNativeBroker: false, // Disables WAM Broker
      loggerOptions: {
        loggerCallback,
        logLevel: LogLevel.Warning,
        piiLoggingEnabled: false,
      },
    },
  });
}

export function loggerCallback(logLevel: LogLevel, message: string) {
  console.log('[MSAL] Logger: ', message);
}

export const clientId: any = {
  dev: '54d57f3b-6bc6-4f5c-a4cf-23168bfe9c12',
  test: 'cec5d933-976d-4a9d-acbc-3d622367ebc8',
  prod: '9a15041a-8b25-415f-b0ff-d63c1ae1aa0e',
};

export const apiScopes: any = {
  dev: ['api://MasterDev/SecurityMaster.User'],
  test: ['api://MasterTest/SecurityMaster.User'],
  prod: ['api://Master/SecurityMaster.User'],
};
