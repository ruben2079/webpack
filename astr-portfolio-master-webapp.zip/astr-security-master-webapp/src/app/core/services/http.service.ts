import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {
  ENTITILEMENTS_API,
  REFERENCE_API,
  SECURITIES_API,
  USERSETTING_API,
} from '../const/api.const';

interface SearchQueryParam {
  filterByNames: string[];
  filterByValues: any[];
  sortByNames: string[];
  sortByOrders: any[];
  pageNumber: number;
  pageSize: number;
}

@Injectable({
  providedIn: 'root',
})
export class HttpService {
  constructor(private _http: HttpClient) {}

  get(url: string): Observable<any> {
    return this._http.get(url);
  }

  put(url: string, body: any): Observable<any> {
    return this._http.put(url, body);
  }

  post(url: string, body: any): Observable<any> {
    return this._http.post(url, body);
  }

  getEntitlement(): Observable<any> {
    return this._http.get(ENTITILEMENTS_API.getentitlements());
  }

  getUserSetting(): Observable<any> {
    return this._http.get(USERSETTING_API.getUserSetting());
  }

  updateUserSetting(colDefs: any): Observable<any> {
    return this._http.put(USERSETTING_API.getUserSetting(), colDefs);
  }

  getSecurities(SecurityId?: any, param?: string): Observable<any> {
    return this._http.get(
      `${SECURITIES_API.getSecurities()}${
        !!SecurityId ? `/${SecurityId}` : ''
      }${!!param ? `?${param}` : ''}`
    );
  }

  getSearchReslut(param: SearchQueryParam): Observable<any> {
    //filterByNames=test1&filterByNames=test&filterByValues=d&filterByValues=f&sortByNames=test1&sortByOrders=asc&pageNumber=1&pageSize=100
    let query = '';
    Object.keys(param).forEach((key) => {
      let values = Reflect.get(param, key);
      if (typeof values === 'object') {
        Reflect.get(param, key).forEach((value: string) => {
          query += `${!query.includes('?') ? '?' : '&'}${key}=${value}`;
        });
      } else {
        query += `${!query.includes('?') ? '?' : '&'}${key}=${values}`;
      }
    });
    return this._http.get(`${SECURITIES_API.getSecurities()}${query}`);
  }

  public searchByCategories(filter: string) {
    return this._http.post(SECURITIES_API.searchByCategories(filter), null);
  }

  public getDetailsDataBySection(
    securityId: any,
    section: 'SecurityXReferences' | 'Classifications'
  ) {
    return this._http.get(
      SECURITIES_API.getDetailsBySection(securityId, section)
    );
  }

  public getReference(
    referenceType?: 'SecurityXReference' | 'Classification' | undefined
  ) {
    return this._http.get(REFERENCE_API.getReference(referenceType));
  }

  public createReference(securityId: number, data: any) {
    return this.post(
      SECURITIES_API.getDetailsBySection(securityId, 'SecurityXReferences'),
      data
    );
  }

  public deleteReference(securityId: number, referenceId: number) {
    return this._http.delete(
      SECURITIES_API.updateReference(
        securityId,
        'SecurityXReferences',
        referenceId
      )
    );
  }

  public updateReference(securityId: number, referenceId: number, data: any) {
    return this.put(
      SECURITIES_API.updateReference(
        securityId,
        'SecurityXReferences',
        referenceId
      ),
      data
    );
  }
}
