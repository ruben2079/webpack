import { Injectable, EventEmitter, Output } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { HttpService } from './http.service';
import { getEnv, getLocationParam } from '../utils/utils';
import { SM_URL_PARAMS, user_roles } from '../const/constants';
import { Entitlements } from '../model/entitlements-model';
import { entitlement_mock } from '../../../assets/mock/entitlements';

@Injectable({
  providedIn: 'root',
})
export class SharedService {
  @Output() AclickedEvent = new EventEmitter<boolean>();

  constructor(private _http: HttpService) {}

  Aclickeded(value: boolean) {
    this.AclickedEvent.emit(value);
  }
  private _subject = new Subject<any>();
  newEvent(event: any) {
    this._subject.next(event);
  }

  get events$() {
    return this._subject.asObservable();
  }

  setUserRole: BehaviorSubject<any> = new BehaviorSubject(null);
  getUserRole = this.setUserRole.asObservable();

  referenceData: BehaviorSubject<any> = new BehaviorSubject(null);
  entitlement: any;
  fullname: any;

  setUserName(username: string) {
    this.fullname = username;
  }

  getUserName() {
    return this.fullname;
  }

  callEntitlements(cb?: any) {
    this._http.getEntitlement().subscribe((data: Entitlements) => {
      let roleValue = getLocationParam(SM_URL_PARAMS.role);
      let role = user_roles.reader;
      const entitlement =
        getEnv() == 'prod' || !roleValue ? data : entitlement_mock[roleValue];
      if (entitlement.CanSetup) {
        role = user_roles.admin;
      }
      this.entitlement = entitlement;
      this.setUserRole.next(role);
      cb && cb();
    });
  }

  getEntitlement() {
    return this.entitlement;
  }
}
