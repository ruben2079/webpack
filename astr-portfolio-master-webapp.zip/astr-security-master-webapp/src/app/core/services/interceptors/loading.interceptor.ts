import { Injectable } from '@angular/core';
import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { LoadingService } from '../loading.service';
import { searchByCategoriesUrl } from '../../const/api.const';

@Injectable()
export class LoaderInterceptor implements HttpInterceptor {
  private ignoreLoadingEndpoints: string[] = [searchByCategoriesUrl]
  
  constructor(private loader: LoadingService) {}
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    if (this.ignoreLoadingEndpoints.some(x => request.url.startsWith(x))){
      return next.handle(request);
    }

    this.loader.show();
    return next.handle(request).pipe(
      finalize(() => this.loader.hide())
    );
  }
}