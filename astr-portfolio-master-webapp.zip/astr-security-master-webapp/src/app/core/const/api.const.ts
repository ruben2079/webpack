import { replace } from 'lodash';
import { getEnv, isLocal } from '../utils/utils';
const backend_protocol = 'https';
const backend_hosts: {
  [key: string]: string;
} = {
  dev: 'astr-api-dev.iam.intranet',
  test: 'astr-api-test.iam.intranet',
  prod: 'astr-api.iam.intranet',
};

export const getbackendurl = (): string => {
  if (isLocal()) {
    return '';
  }
  const env: string = getEnv();
  return `${backend_protocol}://${backend_hosts[env]}`;
};

const url_prefix = getbackendurl();

const entitlementsUrl = `${url_prefix}/v1/Entitlements/SecurityMaster`;
const userSettingUrl = `${url_prefix}/v1/Settings/SecurityMaster`;
const securitiesrl = `${url_prefix}/v1/Securities`;
export const searchByCategoriesUrl = `${securitiesrl}/SearchByCategories`;
const detailsUrl = `${securitiesrl}/_securityId_/_section_`;
const referenceUrl = `${securitiesrl}/_referenceType_ReferenceFields`;

export const ENTITILEMENTS_API = {
  getentitlements: () => entitlementsUrl,
};

export const USERSETTING_API = {
  getUserSetting: () => userSettingUrl,
};

export const SECURITIES_API = {
  searchByCategories: (value: string) =>
    `${searchByCategoriesUrl}?searchString=${encodeURI(value)}`,
  getSecurities: () => securitiesrl,
  getDetailsBySection: (
    securityId: any,
    section: 'SecurityXReferences' | 'Classifications'
  ) =>
    `${detailsUrl
      .replace('_securityId_', securityId)
      .replace('_section_', section)}`,
  updateReference: (
    securityId: number,
    section: 'SecurityXReferences' | 'Classifications',
    referenceId: number
  ) =>
    `${SECURITIES_API.getDetailsBySection(securityId, section)}/${referenceId}`,
};

export const REFERENCE_API = {
  getReference: (
    referenceType: 'SecurityXReference' | 'Classification' | undefined
  ) =>
    `${referenceUrl.replace(
      '_referenceType_',
      !!referenceType ? `${referenceType}/` : ''
    )}`,
};
