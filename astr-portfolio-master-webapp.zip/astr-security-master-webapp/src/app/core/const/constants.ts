export const user_roles = {
  admin: 'Admin',
  reader: 'Reader',
};

export const SM_URL_PARAMS = {
  mock: 'mock',
  role: 'role',
  security: 'security',
};

export class HttpError {
  static BadRequest = 400;
  static Unauthorized = 401;
  static Forbidden = 403;
  static NotFound = 404;
  static TimeOut = 408;
  static Conflict = 409;
  static InternalServerError = 500;
  static BadGateway = 502;
  static GatewayTimeout = 504;
}

export const APP_DETAILS = {
  AppName: 'Security Master',
  DevEmail: 'mailto:Voya-IM-SecMaster-Support@voya.com',
  HelpDeskEmail: 'mailto:VoyaIMHelpDesk@voya.com',
  UserManual:
    'https://voya0.sharepoint.com/:w:/r/sites/IM-finance/IMPMO/VIMFS/Shared%20Documents/2%20-%20Workstreams/C.%20Data%20Platforms%20%26%20Distribution/C1.%20Voya%20Astra/C1.2%20Master%20Data%20(Portfolio%20and%20Security)/5.3%20Portfolio%20(Account)%20Master/User%20manual.docx?d=wdcd2c1607bbb40a1b360b89b7e220a91&csf=1&web=1&e=fbFpAf',
};

export const currency_data_value_split = ' - ';
export const boolean_data_fields = ['Status'];

export const Status_Reference: Array<Object> = [
  { text: 'Inactive', value: false },
  { text: 'Active', value: true },
];

export const Boolean_Reference: Array<Object> = [
  { text: 'Yes', value: false },
  { text: 'No', value: true },
];

export const DEFAULT_SM_GRID_DEF = {
  sortable: {
    mode: 'multiple',
    allowUnsort: true,
    showIndexes: true,
  },
  initialSort: [],
  pageable: {
    buttonCount: 4,
    pageSizes: [20, 50, 100],
  },
  filterable: true,
  groupable: true,
  pageSize: 50,
  exportFileName: 'Security Master',
  resizable: true,
  reorderable: true,
};

// AccrualDate: '2019-06-15';
// AmmountIssued: 3000000000;
// CUSIP: '125523AK6';
// CreatedBy: 'Madhuri.Nanduri@voya.com';
// CreatedOn: '2024-05-29T14:38:07Z';
// Currency: 'USD';
// ERISAFlag: false;
// ISIN: 'US125523AK66';
// Id: 1;
// IssueDate: '2019-08-27';
// IssuerId: 631;
// MaturityDate: '2048-12-15';
// MinLotSize: 1000;
// MinTradeSize: 2000;
// ModifiedBy: 'Madhuri.Nanduri@voya.com';
// ModifiedOn: '2024-09-30T19:43:14Z';
// PaymentFrequency: '0+S';
// PerformingFlag: true;
// RegulationRightsFlag: false;
// SEDOL: 'BKPHS34';
// SecRule144A: 'Public';
// SecurityName: 'CIGNA CORP';
// SourceSystem: 'BRS';
// Status: true;
// Ticker: 'CI';
export const DEFAULT_SM_COL_DEF = [
  { field: 'Id', hide: false, width: '100px', cell: 'link' },
  { field: 'CUSIP', hide: false, width: '200px' },
  { field: 'SecurityName', hide: false, width: '300px' },
  { field: 'SecurityType', hide: false, width: '200px', filter: 'list' },
  { field: 'SecurityGroup', hide: false, width: '200px', filter: 'list' },
  { field: 'AssetClass', hide: false, width: '200px', filter: 'list' },
  { field: 'Ticker', hide: false, width: '200px' },
  { field: 'MIC', hide: false, width: '200px' },
  { field: 'OnCoreId', hide: true, width: '200px' },
  { field: 'BRSId', hide: true, width: '200px' },
  { field: 'ISIN', hide: true, width: '200px' },
  { field: 'SEDOL', hide: true, width: '200px' },
  { field: 'BloombergId', hide: true, width: '200px' },
  { field: 'FIGI', hide: true, width: '200px' }, //missing
  { field: 'IssuerId', hide: true, width: '200px' },
  { field: 'Country', hide: true, width: '200px', filter: 'list' },
  { field: 'Currency', hide: true, width: '200px', filter: 'list' },
  { field: 'IssueDate', hide: true, width: '150px', filter: 'date' },
  { field: 'MaturityDate', hide: true, width: '150px', filter: 'date' },
  { field: 'Coupon', hide: true, width: '200px' },
  { field: 'Factor', hide: true, width: '200px' }, //missing
  { field: 'DayCount', hide: true, width: '200px' }, //missing
  { field: 'PaymentFrequency', hide: true, width: '200px' },
  { field: 'MoodysRating', hide: true, width: '200px' },
  { field: 'SPRating', hide: true, width: '200px' },
  { field: 'Status', hide: true, width: '100px', filter: 'list' },
  { field: 'ModifiedBy', hide: true, width: '250px' },
  {
    field: 'ModifiedOn',
    hide: true,
    width: '250px',
    filter: 'date',
    isDateTime: true,
  },
  { field: 'CreatedBy', hide: true, width: '250px' },
  {
    field: 'CreatedOn',
    hide: true,
    width: '250px',
    filter: 'date',
    isDateTime: true,
  },
];

// Category: 'BRS_ID';
// CreateSource: 'SYSTEM';
// CreatedBy: 'Madhuri.Nanduri@voya.com';
// CreatedOn: '2024-05-29T14:39:22Z';
// Id: 121670;
// ModifiedBy: 'Madhuri.Nanduri@voya.com';
// ModifiedOn: '2024-05-29T14:39:22Z';
// SecurityId: 1;
// SourceSystem: 'BRS';
// Status: true;
// Value: '125523AK6';
export const DEFAULT_XR_COL_DEF = [
  { field: 'Status' },
  { field: 'SecurityId' },
  { field: 'IdentifierType', filter: 'list' },
  { field: 'Identifier' },
  { field: 'SourceSystem', filter: 'list' },
  { field: 'CreatedBy', filter: 'list' },
  {
    field: 'CreatedOn',
    filter: 'date',
    isDateTime: true,
  },
  { field: 'ModifiedBy', filter: 'list' },
  {
    field: 'ModifiedOn',
    filter: 'date',
    isDateTime: true,
  },
];
export const DEFAULT_XR_GRID_DEF = {
  sortable: {
    mode: 'multiple',
    allowUnsort: true,
    showIndexes: true,
  },
  initialSort: [],
  pageable: {
    buttonCount: 4,
    pageSizes: [20, 50, 100],
  },
  filterable: true,
  groupable: false,
  pageSize: 50,
  resizable: true,
  reorderable: true,
};

// ClassItemCode: '35102015';
// ClassItemName: 'HEALTH CARE SERVICES';
// ClassItemType: 'SUB_INDUSTRY';
// ClassName: 'GICS';
// ClassType: 'GICS';
// CreatedBy: 'Madhuri.Nanduri@voya.com';
// CreatedOn: '2024-06-04T15:54:33Z';
// Id: 207;
// ModifiedBy: 'Madhuri.Nanduri@voya.com';
// ModifiedOn: '2024-06-04T15:54:33Z';
// SourceSystem: 'SYSTEM';
// Status: true;
export const DEFAULT_CF_COL_DEF = [
  { field: 'Id', title: 'Class ID' },
  { field: 'ClassType', filter: 'list' },
  { field: 'ClassName' },
  { field: 'ClassItemType', filter: 'list' },
  { field: 'ClassItemCode' },
  { field: 'ClassItemName', filter: 'list' },
  { field: 'SourceSystem', filter: 'list' },
];

export const DEFAULT_CF_GRID_DEF = {
  sortable: {
    mode: 'multiple',
    allowUnsort: true,
    showIndexes: true,
  },
  initialSort: [],
  pageable: {
    buttonCount: 4,
    pageSizes: [20, 50, 100],
  },
  filterable: true,
  groupable: false,
  pageSize: 50,
  resizable: true,
  reorderable: true,
};

export const LEFT_MENU_ITEMS = [
  {
    key: 'master',
    text: 'Master',
    disabled: false,
    Invalid: false,
  },
  {
    key: 'xreference',
    text: 'Cross Reference',
    disabled: false,
    Invalid: false,
  },
  {
    key: 'classification',
    text: 'Classification',
    disabled: false,
    Invalid: false,
  },
];

export const SM_field_name_mapping: any = {
  Id: 'Security ID',
  CUSIP: 'CUSIP',
  SEDOL: 'SEDOL',
  Ticker: 'Ticker',
  ISIN: 'ISIN',
  MIC: 'MIC',
  OnCoreId: 'OnCore ID',
  BRSId: 'BRS ID',
  BloombergId: 'Bloomberg ID',
  IssuerId: 'Issuer ID',
  SecurityName: 'Security Name',
  Coupon: 'Coupon',
  Country: 'Country',
  Currency: 'Currency',
  IssueDate: 'Issue Date',
  MaturityDate: 'Maturity Date',
  SecurityGroup: 'Security Group',
  SecurityType: 'Security Type',
  AccrualDate: 'Accrual Date',
  MinTradeSize: 'Min Trade Size',
  AmmountIssued: 'Ammount Issued',
  SecRule144A: 'SecRule144A',
  MinLotSize: 'Min Lot Size',
  PerformingFlag: 'Performing Flag',
  ERISAFlag: 'ERISA Flag',
  RegulationRightsFlag: 'Regulation Rights Flag',
  PaymentFrequency: 'Payment Frequency',
  Status: 'Status',
  CreatedBy: 'Created By',
  CreatedOn: 'Created Date & Time',
  ModifiedBy: 'Updated By',
  ModifiedOn: 'Updated Date & Time',
  AssetClass: 'Asset Class',
  MoodysRating: "Moody's",
  SPRating: 'S&P',
  FitchRating: 'Fitch',
  SourceSystem: 'Source System',
  SecurityId: 'Security Id',
  IdentifierType: 'Identifier Type',
  Identifier: 'Identifier',
  ClassType: 'Class Type',
  ClassName: 'Class Name',
  ClassItemType: 'Class Item Type',
  ClassItemCode: 'Class Item Code',
  ClassItemName: 'Class Item Name',
  MoodysRatingDate: 'Rating Issuance Date',
  SPRatingDate: 'Rating Issuance Date',
  FitchRatingDate: 'Rating Issuance Date',
};

// AccrualDate: '2019-06-15';
// AmmountIssued: 3000000000;
// CUSIP: '125523AK6';
// CreatedBy: 'Madhuri.Nanduri@voya.com';
// CreatedOn: '2024-05-29T14:38:07Z';
// Currency: 'USD';
// ERISAFlag: false;
// ISIN: 'US125523AK66';
// Id: 1;
// IssueDate: '2019-08-27';
// IssuerId: 631;
// MaturityDate: '2048-12-15';
// MinLotSize: 1000;
// MinTradeSize: 2000;
// ModifiedBy: 'Madhuri.Nanduri@voya.com';
// ModifiedOn: '2024-09-30T19:43:14Z';
// PaymentFrequency: '0+S';
// PerformingFlag: true;
// RegulationRightsFlag: false;
// SEDOL: 'BKPHS34';
// SecRule144A: 'Public';
// SecurityName: 'CIGNA CORP';
// SourceSystem: 'BRS';
// Status: true;
// Ticker: 'CI';
export const SM_content_datafields: any = {
  master: [
    {
      title: 'Core Information',
      owner: [],
      datafields: [
        {
          apiField: 'Id',
          fieldType: 'text',
          characterLimit: 10,
        },
        {
          apiField: 'CUSIP',
          fieldType: 'text',
          characterLimit: 10,
        },
        {
          apiField: 'SEDOL',
          fieldType: 'text',
          characterLimit: 50,
        },
        {
          apiField: 'Ticker',
          fieldType: 'text',
          characterLimit: undefined,
        },
        {
          apiField: 'ISIN',
          fieldType: 'text',
          characterLimit: undefined,
        },
        {
          apiField: 'IssuerId',
          fieldType: 'text',
          characterLimit: 50,
        },
        {
          apiField: 'BloombergId',
          fieldType: 'text',
          characterLimit: 50,
        },
        {
          apiField: 'SecurityName',
          fieldType: 'text',
          characterLimit: 100,
        },
        {
          apiField: 'Country',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'MIC',
          fieldType: 'text',
          characterLimit: undefined,
        },
        {
          apiField: 'Currency',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'IssueDate',
          fieldType: 'datepicker',
          characterLimit: undefined,
        },
        {
          apiField: 'MaturityDate',
          fieldType: 'datepicker',
          characterLimit: undefined,
        },
        {
          apiField: 'Status',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
      ],
    },
    {
      title: 'Asset Information',
      owner: [],
      datafields: [
        {
          apiField: 'SecurityGroup',
          fieldType: 'text',
          characterLimit: undefined,
        },
        {
          apiField: 'SecurityType',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
      ],
    },
    {
      title: 'Ratings',
      owner: [],
      layout: 'column',
      datafields: [
        {
          apiField: 'MoodysRating',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'MoodysRatingDate',
          fieldType: 'datepicker',
          characterLimit: undefined,
        },
        {
          apiField: 'SPRating',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'SPRatingDate',
          fieldType: 'datepicker',
          characterLimit: undefined,
        },
        {
          apiField: 'FitchRating',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'FitchRatingDate',
          fieldType: 'datepicker',
          characterLimit: undefined,
        },
      ],
    },
  ],
};

export const SM_classification_content_datafields: any = {
  title: 'Security Classification Information',
  owner: [],
  datafields: [
    {
      apiField: 'Id',
      fieldType: 'text',
      characterLimit: 10,
    },
    {
      apiField: 'ISIN',
      fieldType: 'text',
      characterLimit: undefined,
    },
    {
      apiField: 'SecurityName',
      fieldType: 'text',
      characterLimit: 100,
    },
    {
      apiField: 'Ticker',
      fieldType: 'text',
      characterLimit: undefined,
    },
    {
      apiField: 'CUSIP',
      fieldType: 'text',
      characterLimit: 10,
    },
    {
      apiField: 'SEDOL',
      fieldType: 'text',
      characterLimit: 50,
    },
  ],
};
