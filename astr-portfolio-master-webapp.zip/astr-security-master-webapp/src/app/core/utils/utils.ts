import _ from 'lodash';
import {
  Boolean_Reference,
  SM_field_name_mapping,
  Status_Reference,
  boolean_data_fields,
  currency_data_value_split,
} from '../const/constants';

export const getLocationParam = (paramName: string): string | null => {
  let { search } = window.location;
  const { href } = window.location;
  search === '' && (search = href.split('?')[1] || '');
  const key = `${paramName}=`;
  let value = '';
  if (search.indexOf(key) > -1) {
    value = search.split(key)[1].split('&')[0];
  }
  return !!value ? decodeURIComponent(value) : null;
};

export const getEnv = (): string => {
  const env = isLocal()
    ? 'dev'
    : window.location.hostname.includes('dev')
    ? 'dev'
    : window.location.hostname.includes('test')
    ? 'test'
    : 'prod';
  return env;
};

export const isLocal = (): boolean => {
  return window.location.hostname.includes('local');
};

export const isDev = (): boolean => {
  return getEnv() === 'dev';
};

export const getDisplayText = (date: Date) =>
  date ? date.toLocaleDateString() : '';

const NAME_FIELD = 'name';
export const sort = (list: any[]) => _.sortBy(list, NAME_FIELD);

export const getDisplayLabel = (field: any): any => {
  return SM_field_name_mapping[field] || `${field}*`;
};

export const getValueForTextField = (securityItem: any, datafield: any) => {
  var fieldName =
    !!datafield && !!datafield.apiField ? datafield.apiField : datafield;
  var value = !!securityItem ? securityItem[fieldName] : null;
  return value;
};

export const dateFormatter = (date: string, isDateTime = false) => {
  return !!date
    ? !isDateTime
      ? getDateDisplay(date)
      : new Date(date).toLocaleString().replace(',', '')
    : null;
};

const getDateDisplay = (date: any) => {
  const temp = (date || '').split('T')[0].split('-');
  if (temp.length < 2) {
    return date;
  } else {
    return `${temp[1]}/${temp[2]}/${temp[0]}`;
  }
};

export const getViewData = (data: any[]): any => {
  return data.map((item: any) => {
    let viewItem = { ...item };
    Object.keys(viewItem).forEach((field: any) => {
      if (boolean_data_fields.includes(field)) {
        const option: any = (
          field === 'Status' ? Status_Reference : Boolean_Reference
        ).find((item: any) => item.value === viewItem[field]);
        !!option && (viewItem[field] = option.text);
      }
    });
    return viewItem;
  });
};

export const getValueByField = (
  dataItem: any,
  field: string,
  type: 'text' | 'date' = 'text',
  isDateTime: boolean = false
) => {
  const value = getValueForTextField(dataItem, field);
  return type === 'text' ? value : dateFormatter(value, isDateTime);
};

export const processReference = (referenceData: any) => {
  let reference: any = {};

  !!referenceData &&
    Object.values(referenceData).forEach((item: any) => {
      const key = item.FieldToUpdate || item.FieldName;
      let newReference: any = {};
      const options = item?.Options;
      !!item &&
        !!options &&
        !!options.length &&
        options.forEach((option: any, index: any) => {
          const referenceId = option.Value || index;
          let referenceValue = (option.Text || option).trim();
          if (referenceValue !== 'No value') {
            // if (key.toLowerCase().includes('currency')) {
            //   referenceValue = `${referenceId}${currency_data_value_split}${referenceValue}`;
            // }
            if (!boolean_data_fields.includes(key)) {
              newReference[referenceId] = referenceValue;
            }
          }
        });
      !!Object.keys(newReference).length && (reference[key] = newReference);
    });

  boolean_data_fields.forEach((datafield) => {
    let mapping = datafield !== 'Status' ? Boolean_Reference : Status_Reference;
    let options: any = {};
    reference[datafield] = Object.values(mapping).forEach((item: any) => {
      options[item.value] = item.text;
    });
    reference[datafield] = options;
  });
  return reference;
};

export const initColDef = (cols: any, referenceData: any) => {
  return cols.map((col: any) => ({
    ...col,
    title: col.title || SM_field_name_mapping[col.field] || col.field,
    ...(col.filter === 'list'
      ? {
          filter_options: Object.keys(referenceData).includes(col.field)
            ? Object.values(referenceData[col.field])
            : [],
        }
      : {}),
  }));
};
