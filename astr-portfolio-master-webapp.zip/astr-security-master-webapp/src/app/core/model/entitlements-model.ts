export class Entitlements {
  constructor(
    public CanRead: boolean,
    public CanSetup: boolean,
    public FamilyName: string,
    public GivenName: string,
    public Username: string
  ) {}
}
