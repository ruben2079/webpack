import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SecurityDetailsComponent } from './security-master/security-details/security-details.component';
import { SecurityHomeComponent } from './security-master/security-home/security-home.component';

const routes: Routes = [
  {
    path: '',
    component: SecurityHomeComponent,
  },
  {
    path: 'details',
    component: SecurityDetailsComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LayoutRoutingModule {}
