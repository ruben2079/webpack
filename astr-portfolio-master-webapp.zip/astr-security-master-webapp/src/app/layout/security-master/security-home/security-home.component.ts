import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedService } from '../../../core/services/shared.service';
import {
  DEFAULT_SM_COL_DEF,
  DEFAULT_SM_GRID_DEF,
} from '../../../core/const/constants';
import { map } from 'rxjs';
import { SearchBoxComponent } from '../../common/search-box/search-box.component';
import { HttpService } from '../../../core/services/http.service';
import {
  dateFormatter,
  getViewData,
  initColDef,
  processReference,
} from '../../../core/utils/utils';
import { Router } from '@angular/router';
import { DataGridComponent } from '../../common/data-grid/data-grid.component';
import { process } from '@progress/kendo-data-query';
import { GridDataResult } from '@progress/kendo-angular-grid';

@Component({
  selector: 'app-security-home',
  templateUrl: './security-home.component.html',
  styleUrl: './security-home.component.scss',
})
export class SecurityHomeComponent implements OnInit {
  private recentValuesKey = 'recentSearchValues';
  public gridDef: any = DEFAULT_SM_GRID_DEF;
  public colDef: any = DEFAULT_SM_COL_DEF;
  public userSetting: any = {};
  public recentSearchValues!: any[];
  public viewData: GridDataResult = { data: [], total: 0 };
  public referenceData: any;
  public filterOption = {
    filterByNames: [],
    filterByValues: [],
    sortByNames: [],
    sortByOrders: [],
    pageNumber: 1,
    pageSize: 50,
  };
  dateFormatter: any = dateFormatter;

  @ViewChild('grid') grid!: DataGridComponent;
  @ViewChild('searchBox', { static: true })
  searchBox!: SearchBoxComponent;

  constructor(
    private router: Router,
    private _sharedService: SharedService,
    private _httpService: HttpService
  ) {}

  ngOnInit(): void {
    this._httpService.getUserSetting().subscribe({
      next: (data) => {
        !!data &&
          !!data.colDefs &&
          !!data.colDefs.length &&
          (this.colDef = data.colDefs);
        this._httpService.getReference().subscribe({
          next: (data) => {
            this.referenceData = processReference(data);
            this.colDef = initColDef(this.colDef, this.referenceData);
            this.queryFilteredData({
              ...this.filterOption,
              pageSize: this.grid.getState().take || 50,
            });
          },
        });
      },
    });
    this.recentSearchValues = this.getRecentSearchValues();
    this.searchBox.valueChange.subscribe((data) => {
      this.saveToRecentSearchValues(data);
      this.queryFilteredData({
        ...this.filterOption,
        filterByNames: [data.category],
        filterByValues: [data.value],
        sortByNames: [],
        sortByOrders: [],
        pageNumber: 1,
        pageSize: this.grid.getState().take || 50,
      });
    });
  }

  public queryFilteredData(filter: any) {
    this._httpService.getSearchReslut(filter).subscribe({
      next: (data) => {
        this.viewData = {
          ...process(getViewData(data.Securities), {}),
          total: data.TotalCount || data.Securities.length,
        };
      },
    });
  }

  public getFilteredSearchResult(filter: string) {
    return this._httpService.searchByCategories(filter).pipe(
      map((data: any) => {
        let list: any[] = [];
        data.forEach((item: SearchResult) => {
          item.Results.forEach((result: SearchCategoryValue) => {
            list.push({
              value: result.Value,
              id: result.Id,
              category: item.Category,
              groupBy: item.Category,
            });
          });
        });

        let recentValues = this.getRecentSearchValues();
        if (recentValues.length) {
          list.push(...recentValues);
        }

        return list;
      })
    );
  }

  private saveToRecentSearchValues(value: SearchItem) {
    let recentValues = this.getRecentSearchValues();
    if (
      recentValues.some(
        (x) =>
          x.id == value.id &&
          x.value == value.value &&
          x.category == value.category
      )
    ) {
      return;
    }
    recentValues = [value, ...recentValues];
    recentValues.forEach((x) => (x.groupBy = 'Recent'));

    if (recentValues.length > 5) {
      recentValues.pop();
    }

    localStorage.setItem(this.recentValuesKey, JSON.stringify(recentValues));
    this.recentSearchValues = recentValues;
  }

  private getRecentSearchValues() {
    return JSON.parse(
      localStorage.getItem(this.recentValuesKey) || '[]'
    ) as Array<SearchItem>;
  }

  onCellLinkClick(field: any, dataItem: any) {
    switch (field) {
      case 'Id':
        this.router.navigate(['/security/details'], {
          queryParams: { security: dataItem.Id },
        });
        break;
      default:
        break;
    }
  }

  updateUserSettings(colDef: any) {
    this._httpService.updateUserSetting(colDef).subscribe();
  }
}
