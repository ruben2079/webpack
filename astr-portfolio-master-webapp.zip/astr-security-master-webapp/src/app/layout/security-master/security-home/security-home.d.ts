declare interface SearchResult {
  Category: string;
  Results: SearchCategoryValue[];
}

declare interface SearchCategoryValue {
  Id: number | null;
  Value: string;
}
