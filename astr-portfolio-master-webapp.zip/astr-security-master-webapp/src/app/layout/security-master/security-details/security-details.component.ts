import { Component, OnInit } from '@angular/core';
import { SharedService } from '../../../core/services/shared.service';
import * as constants from '../../../core/const/constants';
import { ActivatedRoute, Router } from '@angular/router';
import { APP_DETAILS, SM_URL_PARAMS } from '../../../core/const/constants';
import { homeIcon } from '@progress/kendo-svg-icons';
import { HttpService } from '../../../core/services/http.service';
import * as utils from '../../../core/utils/utils';
import { getViewData } from '../../../core/utils/utils';

@Component({
  selector: 'app-security-details',
  templateUrl: './security-details.component.html',
  styleUrl: './security-details.component.scss',
})
export class SecurityDetailsComponent implements OnInit {
  public userRoles: any;
  public constants: any = constants;
  public utils: any = utils;
  public activeTab: any = 'master';
  public securityCode: any;
  public breadcrumbItems: any;
  public homeIcon = homeIcon;
  public securityItem: any = null;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private _sharedService: SharedService,
    private _httpService: HttpService
  ) {}

  async ngOnInit(): Promise<void> {
    this.route.queryParams.subscribe((params) => {
      this.securityCode = params[SM_URL_PARAMS.security];
      !!this.securityCode
        ? this._httpService.getSecurities(this.securityCode).subscribe({
            next: (security: any) => {
              this.securityItem = getViewData([security])[0];
              const currentItemText =
                utils.getValueForTextField(this.securityItem, 'SecurityName') ||
                this.securityCode;
              this.breadcrumbItems = [
                {
                  text: APP_DETAILS.AppName,
                  title: APP_DETAILS.AppName,
                  svgIcon: homeIcon,
                },
                {
                  text: currentItemText,
                  title: currentItemText,
                },
              ];
            },
            error: () => {
              this.onBreadcrumbItemClick();
            },
          })
        : this.onBreadcrumbItemClick();
    });
    this.userRoles = this._sharedService.getUserRole.subscribe(
      (data) => (this.userRoles = data)
    );
  }

  onTabSelected(key: string) {
    this.activeTab = key;
  }

  onBreadcrumbItemClick() {
    this.router.navigate(['security']);
  }
}
