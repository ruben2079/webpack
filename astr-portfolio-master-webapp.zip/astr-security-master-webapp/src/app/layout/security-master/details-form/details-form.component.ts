import { Component, Input, OnInit } from '@angular/core';
import { SharedService } from '../../../core/services/shared.service';
import * as constants from '../../../core/const/constants';
import * as utils from '../../../core/utils/utils';

@Component({
  selector: 'app-details-form',
  templateUrl: './details-form.component.html',
  styleUrl: './details-form.component.scss',
})
export class DetailsFormComponent implements OnInit {
  public userRoles: any;
  public constants: any = constants;
  public utils: any = utils;

  @Input() public activeTab: any = 'master';
  @Input() public securityItem: any;

  public datafields: any[] = [];

  constructor(private _sharedService: SharedService) {}

  async ngOnInit(): Promise<void> {
    this.datafields = constants.SM_content_datafields[this.activeTab];
  }

  getTextValue(securityItem: any, datafield: any) {
    return utils.getValueByField(
      securityItem,
      datafield,
      datafield.fieldType !== 'datepicker' ? 'text' : 'date'
    );
  }
}
