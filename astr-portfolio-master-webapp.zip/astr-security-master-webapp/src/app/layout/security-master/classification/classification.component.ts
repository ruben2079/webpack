import { Component, Input, OnInit } from '@angular/core';
import { SharedService } from '../../../core/services/shared.service';
import * as constants from '../../../core/const/constants';
import * as utils from '../../../core/utils/utils';
import { HttpService } from '../../../core/services/http.service';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { initColDef, processReference } from '../../../core/utils/utils';

@Component({
  selector: 'app-classification',
  templateUrl: './classification.component.html',
  styleUrl: './classification.component.scss',
})
export class ClassificationComponent implements OnInit {
  public userRoles: any;
  public constants: any = constants;
  public utils: any = utils;
  public section = constants.SM_classification_content_datafields;
  public gridDef: any = constants.DEFAULT_CF_GRID_DEF;
  public colDef: any = constants.DEFAULT_CF_COL_DEF;
  public gridData: any = [];
  public referenceData: any = [];

  @Input() public securityItem: any;

  constructor(
    private _sharedService: SharedService,
    private _httpService: HttpService
  ) {}

  async ngOnInit(): Promise<void> {
    !!this.securityItem &&
      this._httpService.getReference('Classification').subscribe({
        next: (data: any) => {
          this.referenceData = processReference(data);
          this.colDef = initColDef(this.colDef, this.referenceData);
          this._httpService
            .getDetailsDataBySection(this.securityItem?.Id, 'Classifications')
            .subscribe({
              next: (data: any) => {
                this.gridData = data;
              },
            });
        },
      });
  }
}
