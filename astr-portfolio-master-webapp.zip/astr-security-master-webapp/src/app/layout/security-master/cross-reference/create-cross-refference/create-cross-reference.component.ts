import { Component, Input, OnInit } from "@angular/core";
import { FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { DialogContentBase, DialogRef } from "@progress/kendo-angular-dialog";

@Component({
    selector: 'app-create-cross-reference',
    templateUrl: './create-cross-reference.component.html',
    styleUrl: './create-cross-reference.component.scss',
})
export class CreateCrossReferenceComponent 
    extends DialogContentBase
    implements OnInit {
    @Input('securityId') securityId!: number;
    @Input('reference') reference: any;
    @Input('submitButtonText') submitButtonText: string = 'Save';

    public referenceData: any[] = [];
    public identifierTypes: any[] = [];
    public sourceSystems: any[] = [];

    public referenceForm!: FormGroup;

    constructor(dialog: DialogRef, private formBuilder: FormBuilder) {
        super(dialog);
    }

    ngOnInit(): void {
        this.identifierTypes = this.referenceData?.find(x => x.FieldName === 'IdentifierType')?.Options.map((x: any) => x.Value) ?? [];
        this.sourceSystems = this.referenceData?.find(x => x.FieldName === 'SourceSystem')?.Options.map((x: any) => x.Value) ?? [];
        
        const isEdit = !!this.reference;
        this.referenceForm = this.formBuilder.group({
            SecurityId: new FormControl({value: this.securityId, disabled: true}, Validators.required),
            Identifier: new FormControl(isEdit ? this.reference.Value : '', Validators.required),
            IdentifierType: new FormControl(isEdit ? this.reference.IdentifierType : '', Validators.required),
            SourceSystem: new FormControl(isEdit ? this.reference.SourceSystem : '', Validators.required),
        });

        this.submitButtonText = isEdit ? 'Save' : 'Add'
    }

    public onCancelAction(): void {
        this.dialog.close({ text: 'Cancel' });
    }

    public onConfirmAction(): void {
        this.dialog.close({ text: 'Submit', themeColor: 'primary' });
    }
}