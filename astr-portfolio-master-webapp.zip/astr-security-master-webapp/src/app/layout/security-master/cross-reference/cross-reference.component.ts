import { Component, Input, OnInit } from '@angular/core';
import { SharedService } from '../../../core/services/shared.service';
import * as constants from '../../../core/const/constants';
import { HttpService } from '../../../core/services/http.service';
import { dateFormatter, getViewData, initColDef, processReference } from '../../../core/utils/utils';
import { DialogService } from '@progress/kendo-angular-dialog';
import { CreateCrossReferenceComponent } from './create-cross-refference/create-cross-reference.component';
import { NotificationService } from '@progress/kendo-angular-notification';
import { user_roles } from '../../../core/const/constants';

@Component({
  selector: 'app-cross-reference',
  templateUrl: './cross-reference.component.html',
  styleUrl: './cross-reference.component.scss',
})
export class CrossReferenceComponent implements OnInit {
  public userRoles: any;
  public constants: any = constants;
  public gridDef: any = constants.DEFAULT_XR_GRID_DEF;
  public colDef: any = constants.DEFAULT_XR_COL_DEF;
  public dateFormatter: any = dateFormatter;
  public referenceData: any[] = [];
  public actionMenus?: string[];
  public isAdmin: boolean = false;

  public data: any = [];

  @Input() public securityItem: any;

  constructor(
    private _sharedService: SharedService,
    private dialogService: DialogService,
    private _httpService: HttpService,
    private notificationService: NotificationService
  ) {}

  async ngOnInit(): Promise<void> {
    !!this.securityItem && this.getTableData();

    this._sharedService.getUserRole.subscribe(role => {
      if (role === user_roles.admin) {
        this.isAdmin = true;
        this.actionMenus = ['Edit', 'Remove'];
      }
    });
  }

  public onActionMenuSelected($event: any, item: any) {
    switch ($event.item.text) {
      case 'Edit':
        this.onEdit(item);
        break;
      case 'Remove':
        this.onDelete(item.Id);
        break;
      default:
        break;
    }
  }

  public onCreate() {
    const createDialog = this.dialogService.open({
      title: 'Create Cross Reference Item',
      content: CreateCrossReferenceComponent,
      width: 600,
      minHeight: 360,
    });

    const createComponent = createDialog.content
      .instance as CreateCrossReferenceComponent;
    createComponent.securityId = this.securityItem.Id;
    createComponent.submitButtonText = 'Add';
    createComponent.referenceData = this.referenceData;

    createDialog.result.subscribe((result: any) => {
      if (result.text == 'Submit') {
        let obj = {
          Status: true,
          IdentifierType:
            createComponent.referenceForm.controls['IdentifierType'].value,
          Value: createComponent.referenceForm.controls['Identifier'].value,
          SourceSystem:
            createComponent.referenceForm.controls['SourceSystem'].value,
          CreateSource:
            createComponent.referenceForm.controls['CreateSource']?.value ?? '',
        };

        this.createReference(obj);
      }
    });
  }

  public onEdit(selectedRow: any) {
    const editDialog = this.dialogService.open({
      title: 'Edit Cross Reference Item',
      content: CreateCrossReferenceComponent,
      width: 600,
      minHeight: 360,
    });

    const editComponent = editDialog.content
      .instance as CreateCrossReferenceComponent;
    editComponent.securityId = this.securityItem.Id;
    editComponent.reference = selectedRow;
    editComponent.referenceData = this.referenceData;

    editDialog.result.subscribe((result: any) => {
      if (result.text == 'Submit') {
        let obj = {
          Id: selectedRow.Id,
          Status: true,
          IdentifierType:
            editComponent.referenceForm.controls['IdentifierType'].value,
          Value: editComponent.referenceForm.controls['Identifier'].value,
          SourceSystem:
            editComponent.referenceForm.controls['SourceSystem'].value,
          CreateSource:
            editComponent.referenceForm.controls['CreateSource']?.value ?? '',
        };

        this.editReference(selectedRow.Id, obj);
      }
    });
  }

  public onDelete(id: any) {
    const removeDialog = this.dialogService.open({
      title: 'Remove Tag',
      content: `Are You sure you want to delete selected item?`,
      actions: [{ text: 'Delete', themeColor: 'primary' }, { text: 'Cancel' }],
      minWidth: 330,
      minHeight: 180,
    });

    removeDialog.result.subscribe((result: any) => {
      if (result.text == 'Delete') {
        this.deleteReference(id);
      }
    });
  }

  private deleteReference(id: number) {
    this._httpService
      .deleteReference(this.securityItem.Id, id)
      .subscribe(() => {
        this.showNotification(
          'The Cross Reference item has been successfuly deleted.'
        );
        this.getTableData();
      });
  }

  private editReference(referenceId: number, obj: any) {
    this._httpService
      .updateReference(this.securityItem.Id, referenceId, obj)
      .subscribe(() => {
        this.showNotification(
          'The Cross Reference item has been successfuly updated.'
        );
        this.getTableData();
      });
  }

  private showNotification(text: string): void {
    this.notificationService.show({
      content: text,
      cssClass: 'button-notification',
      animation: { type: 'slide', duration: 100 },
      position: { horizontal: 'center', vertical: 'top' },
      type: { style: 'success', icon: true },
      hideAfter: 5000,
    });
  }

  private createReference(obj: any) {
    this._httpService
      .createReference(this.securityItem.Id, obj)
      .subscribe(() => {
        this.showNotification(
          'The Cross Reference item has been successfuly created.'
        );
        this.getTableData();
      });
  }

  private getTableData() {
    this._httpService.getReference('SecurityXReference').subscribe({
      next: (data: any) => {
        this.referenceData = processReference(data);
        this.colDef = initColDef(this.colDef, this.referenceData);
        this._httpService
          .getDetailsDataBySection(this.securityItem?.Id, 'SecurityXReferences')
          .subscribe({
            next: (data: any) => {
              this.data = getViewData(data);
            },
          });
      },
    });
  }
}
