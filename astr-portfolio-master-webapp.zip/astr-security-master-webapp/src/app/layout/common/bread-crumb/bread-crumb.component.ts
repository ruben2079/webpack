import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  Output,
} from '@angular/core';

@Component({
  selector: 'app-bread-crumb',
  templateUrl: './bread-crumb.component.html',
  styleUrl: './bread-crumb.component.scss',
})
export class BreadCrumbComponent {
  @Input() public items?: any = [];
  @Output()
  public onSelect = new EventEmitter<string>();

  constructor(private elRef: ElementRef) {}

  handleSelect(key: any) {
    this.onSelect.emit(key);
  }
}
