import { Component } from '@angular/core';
import { bellIcon, SVGIcon, userIcon } from '@progress/kendo-svg-icons';
import { BadgeAlign } from '@progress/kendo-angular-indicators';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class HeaderComponent {
  public bellIcon: SVGIcon = bellIcon;
  public userIcon: SVGIcon = userIcon;

  public badgeAlign: BadgeAlign = { vertical: 'bottom', horizontal: 'end' };
}
