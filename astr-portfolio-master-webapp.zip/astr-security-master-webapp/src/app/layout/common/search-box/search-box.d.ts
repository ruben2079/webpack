declare interface SearchItem {
  category: string;
  id: number | null;
  value: string;
  groupBy: string;
}
