import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { searchIcon } from '@progress/kendo-svg-icons';
import { GroupResult, groupBy } from "@progress/kendo-data-query";
import { ComboBoxComponent } from '@progress/kendo-angular-dropdowns';
import { debounceTime, Observable } from 'rxjs';

@Component({
  selector: 'app-search-box',
  templateUrl: './search-box.component.html',
  styleUrl: './search-box.component.scss',
})
export class SearchBoxComponent implements OnInit {
  public searchIcon = searchIcon;
  public filter: string = '';
  public isLoading: boolean = false;
  @Input() public placeholder?: any = 'Search';
  @Input() public recentValues: SearchItem[] = [];
  @Input() public suggestions?: GroupResult[] = [];
  @Input() public getSuggestions!: (filter: string) => Observable<SearchItem[]>

  public value!: SearchItem;
  @Output() valueChange: EventEmitter<SearchItem> = new EventEmitter<SearchItem>();

  @ViewChild('search', { static: true })
  searchBox!: ComboBoxComponent;

  constructor() {}

  ngOnInit(): void {
    this.searchBox.filterChange
      .pipe(debounceTime(1000))
      .subscribe(filter => {
        this.filter = filter;
        if (filter.length >= 3)
          this.getFilteredResult(filter);
        else if(filter.length == 0)
          this.suggestions = this.group(this.recentValues)
        else
          this.suggestions = []
      });

    this.searchBox.valueChange.subscribe((value: SearchItem) => {
      this.value = value;
      this.valueChange.emit(value);

      this.searchBox.reset();
    });

    this.searchBox.onFocus.subscribe(() => { this.searchBox.toggle(); });


    if (this.recentValues?.length && !this.filter.length){
      this.suggestions = this.group(this.recentValues);
    }
  }

  private getFilteredResult(filter: string) {
    this.suggestions = [];
    this.isLoading = true;
    this.getSuggestions(filter)
      .subscribe(data => {
        this.suggestions = this.group(data);
        this.isLoading = false;
      })
  }

  private group(items: SearchItem[]) {
    return groupBy(items, [{ field: "groupBy" }]) as GroupResult[];
  }
}
