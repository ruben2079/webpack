import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import { MenuSelectEvent } from '@progress/kendo-angular-menu';
import { exclamationCircleIcon } from '@progress/kendo-svg-icons';

@Component({
  selector: 'app-sidebar-menu',
  templateUrl: './sidebar-menu.component.html',
  styleUrl: './sidebar-menu.component.scss',
})
export class SidebarMenuComponent implements OnInit {
  public selected: any;
  public exclamationCircleIcon = exclamationCircleIcon;
  @Input() public menuItems?: any = [];
  @Input() public selectedKey?: any;
  @Output()
  public onSelect = new EventEmitter<string>();

  constructor(private elRef: ElementRef) {}

  ngOnInit(): void {
    const displayedItems = this.menuItems.filter((item: any) => !item.disabled);
    this.selected =
      this.selectedKey || !!displayedItems.length
        ? displayedItems[0].key
        : null;
  }

  handleSelect($event: MenuSelectEvent) {
    this.selected = $event.item.key;
    this.onSelect.emit(this.selected);
  }
}
