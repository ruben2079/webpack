declare interface SidebarMenuItem {
  key: any;
  text: any;
  disabled: boolean;
  Invalid: boolean;
}
