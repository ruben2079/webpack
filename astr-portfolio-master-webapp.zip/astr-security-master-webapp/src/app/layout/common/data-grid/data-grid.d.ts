declare interface DataGridDef {
  sortable: any;
  initialSort: any;
  pageable: any;
  filterable: boolean;
  groupable: boolean;
  pageSize: number;
  exportFileName: string;
  groupConfig: any[];
  resizable: boolean;
  reorderable: boolean;
}
