import {
  Component,
  ElementRef,
  HostListener,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import _ from 'lodash';
import {
  SVGIcon,
  moreVerticalIcon,
  columnsIcon,
  fileExcelIcon,
  rotateIcon,
  chevronDoubleDownIcon,
  chevronDoubleUpIcon,
  saveIcon,
  searchIcon,
  checkboxCheckedIcon,
  checkboxIcon,
} from '@progress/kendo-svg-icons';
import { DrawerItem } from '@progress/kendo-angular-layout';
import { process, State } from '@progress/kendo-data-query';
import {
  GroupKey,
  GridComponent,
  DataStateChangeEvent,
} from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';

@Component({
  selector: 'app-data-grid',
  templateUrl: './data-grid.component.html',
  styleUrl: './data-grid.component.scss',
})
export class DataGridComponent implements OnInit {
  private default_gridDef: DataGridDef = {
    sortable: false,
    initialSort: null,
    pageable: false,
    filterable: false,
    groupable: false,
    pageSize: 5,
    exportFileName: 'Export',
    groupConfig: [],
    resizable: false,
    reorderable: false,
  };
  private default_filter: any = {
    logic: 'and',
    filters: [],
  };
  public action_menu_field = '';
  public metaData: any;
  public viewData: any;
  public cols: any;
  @ViewChild('clickedExport') clickedExport!: ElementRef<any>;
  @ViewChild('grid') grid!: GridComponent;
  @Input() public gridDef?: any = this.default_gridDef;
  @Input() set gridData(value: any) {
    this.metaData = value;
    this.refeshData();
  }
  @Input() set colDef(value: any) {
    this.cols = value;
    this.initMenuColumns();
  }
  @Input() public dateFormatter: any;
  @Input() public exportCB?: any;
  @Input() public onAddItem?: any;
  @Input() public onActionMenuSelected?: any;
  @Input() public onSavedColumns?: any;
  @Input() public actionMenus?: string[];
  @Input() public excludedColMenu?: string[] = [];
  @Input() public hasColumnPanel?: boolean = true;
  @Input() public hasExport?: boolean = true;
  @Input() public hasAdd?: boolean = false;
  @Input() public onCellLinkClick: any;
  @Output() public getState = () => this.state;
  public filename: any = `${this.gridDef}_${new Date().toISOString()}.xlsx`;
  public moreVerticalIcon: SVGIcon = moreVerticalIcon;
  public columnList: Array<DrawerItem> = [];
  public expanded = false;
  public state: State = {};
  public resetColumnDataVal: any;
  public savedSettingsData: any;
  public groupExpanded = true;
  public expandedGroupKeys: GroupKey[] = this.gridDef.groupConfig || [];
  public hiddenColumns: Array<any> = [];
  public selectedAllCol: boolean = false;
  public fileExcelIcon: SVGIcon = fileExcelIcon;
  public chevronDoubleDownIcon: SVGIcon = chevronDoubleDownIcon;
  public chevronDoubleUpIcon: SVGIcon = chevronDoubleUpIcon;
  public columnsIcon: SVGIcon = columnsIcon;
  public rotateIcon: SVGIcon = rotateIcon;
  public saveIcon: SVGIcon = saveIcon;
  public searchIcon: SVGIcon = searchIcon;
  public checkboxIcon: SVGIcon = checkboxIcon;
  public checkboxCheckedIcon: SVGIcon = checkboxCheckedIcon;

  constructor() {}

  ngOnInit(): void {
    this.dataStateChange({
      take: this.gridDef.pageSize,
      skip: 0,
      group: this.gridDef.groupConfig || [],
      sort: this.gridDef.initialSort || [],
      filter: this.gridDef.initialfilter || this.default_filter,
    });
    this.initMenuColumns();
  }

  public refeshData(): void {
    const data = process(
      this.metaData?.data || this.metaData || [],
      this.state
    );
    this.viewData = {
      ...data,
      total:
        !this.state.filter?.filters.length && !!this.metaData.total
          ? this.metaData.total
          : data.data.length,
    };
  }

  public fetchExportData(): ExcelExportData {
    return this.metaData;
  }

  public exportToExcel(): void {
    !!this.exportCB && this.exportCB();
  }

  public AddItem(): void {
    !!this.onAddItem && this.onAddItem();
  }

  public switchExpanded(): void {
    this.expanded = !this.expanded;
  }

  public expandAll(val: boolean): void {
    this.groupExpanded = !val;
    this.expandedGroupKeys = [];
  }

  public initMenuColumns() {
    this.columnList = _.sortBy(
      this.cols
        .filter(
          (col: any) =>
            !!col.title && !(this.excludedColMenu || []).includes(col.field)
        )
        .map((col: any) => ({
          text: col.title,
          selected: !col.hide,
          field: col.field,
        })),
      'text'
    );
    this.resetColumnDataVal = [...this.columnList];
    this.savedSettingsData = this.cols.filter((col: any) => !col.hide);
    !!this.actionMenus &&
      !this.cols.find((col: any) => col.field === this.action_menu_field) &&
      this.cols.push({ field: this.action_menu_field, title: '' });
    this.hiddenColumns = this.columnList.filter((item: any) => !item.selected);
  }

  resetColumns() {
    this.hiddenColumns = this.resetColumnDataVal.filter(
      (item: any) => !item.selected
    );
    this.columnList = [...this.resetColumnDataVal];
  }

  public isHidden(columnName: string): boolean {
    return (
      this.hiddenColumns.findIndex((column) => column.field == columnName) > -1
    );
  }

  public onSelectColumn(e: any): void {
    const columnName = e.item;
    const columnIndex = this.hiddenColumns.findIndex(
      (column) => column.field == columnName.field
    );
    if (columnIndex === -1) {
      this.hiddenColumns.push(columnName);
    } else {
      this.hiddenColumns.splice(columnIndex, 1);
    }
    this.selectedAllCol = !this.hiddenColumns.length;
    this.columnList = this.columnList.map((col) => ({
      ...col,
      selected: !this.hiddenColumns.find((item) => item.text === col.text),
    }));
  }

  selectAllColumn() {
    this.selectedAllCol = !this.selectedAllCol;
    this.hiddenColumns = [];
    this.columnList = this.columnList.map((col: any) => {
      !this.selectedAllCol && this.hiddenColumns.push(col);
      return {
        ...col,
        selected: this.selectedAllCol,
      };
    });
  }

  savedColumns() {
    let data =
      this.cols
        .filter(
          (col: any) =>
            !!col.title && !this.excludedColMenu?.includes(col.field)
        )
        .map((item: any) => {
          let isHide = this.columnList.find((d: any) => d.field == item.field);
          return { ...item, hide: isHide?.selected == false ? true : false };
        }) || [];
    let orderedData: any = _.compact(
      _.orderBy(this.grid.columns.toArray(), ['orderIndex'], ['asc']).map(
        (column: any) => data.find((item: any) => item.field === column.field)
      )
    );
    orderedData = orderedData.concat(
      data.filter(
        (column: any) =>
          !orderedData.find((item: any) => item.field === column.field)
      )
    );
    let payload: Object = {
      colDefs: orderedData,
    };
    this.onSavedColumns && this.onSavedColumns(payload);
  }

  handleListFilterChange = (selected: any, field: any) => {
    if (field.includes('Benchmark')) {
      selected = selected.map((value: string) =>
        value.substring(0, value.lastIndexOf(' ('))
      );
    }
    let newState: any = { ...this.state };
    const { filter = { filters: [] } } = newState;
    const newfilter: any = !!selected.length
      ? [
          {
            logic: 'or',
            filters: (selected || []).map((item: any) => ({
              field,
              operator: 'eq',
              value: item,
            })),
          },
        ]
      : [];
    newState = {
      ...newState,
      skip: 0,
      filter: {
        ...filter,
        filters: _.concat(
          !!filter && !!filter.filters
            ? filter.filters.filter(
                (item: any) =>
                  (!!item.filters ? item.filters[0].field : item.field) !==
                  field
              )
            : [],
          newfilter
        ),
        logic: 'and',
      },
    };
    !newState.filter.filters.length &&
      (newState = {
        ...newState,
        filter: this.default_filter,
      });
    this.dataStateChange(newState);
  };

  getDateStringforSaving = (date?: Date | any, isDateTime?: boolean): any => {
    try {
      const datestr = (
        !!date ? (typeof date === 'string' ? new Date(date) : date) : null
      ).toISOString();
      return !isDateTime ? datestr.split('T')[0] : datestr;
    } catch (error) {
      return null;
    }
  };

  handleDateFilterChange = (
    dates: any,
    field: any,
    isDateTime: boolean = false
  ) => {
    const { min, max } = dates;
    const filters = [];
    let newState: any = { ...this.state };
    const { filter = { filters: [] } } = newState;
    if (!!min) {
      filters.push({
        field: field,
        operator: 'gte',
        value: this.getDateStringforSaving(min, isDateTime),
      });
    }
    if (!!max) {
      filters.push({
        field: field,
        operator: 'lte',
        value: this.getDateStringforSaving(max, isDateTime),
      });
    }
    newState = {
      ...newState,
      skip: 0,
      filter: {
        ...filter,
        filters: _.concat(
          filters,
          !!filter && !!filter.filters
            ? filter.filters.filter((item: any) => item.field !== field)
            : []
        ),
        logic: 'and',
      },
    };
    this.dataStateChange(newState);
  };

  resetFilters() {
    let newState: any = { ...this.state };
    newState = {
      ...newState,
      skip: 0,
      filter: this.default_filter,
    };
    this.dataStateChange(newState);
  }

  public onSelect(e: any, val: any): void {
    this.onActionMenuSelected && this.onActionMenuSelected(e, val);
  }

  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.refeshData();
  }

  public handleCellLinkClick(field: any, dataItem: any): void {
    this.onCellLinkClick && this.onCellLinkClick(field, dataItem);
  }

  @HostListener('document:click', ['$event'])
  private documentClick(event: any): void {
    if (
      this.hasColumnPanel &&
      !this.contains(event.target) &&
      !!this.expanded
    ) {
      this.switchExpanded();
    }
  }

  private contains(target: any): boolean {
    return (
      document
        .getElementsByClassName('column_panel_drawer')[0]
        .contains(target) ||
      document.getElementsByClassName('columnsIcon')[0].contains(target)
    );
  }
}
