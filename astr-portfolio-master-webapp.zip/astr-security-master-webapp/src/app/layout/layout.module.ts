import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutRoutingModule } from './layout-routing.module';
import { LayoutComponent } from './layout.component';
import { HeaderComponent } from './common/header/header.component';
import { SecurityHomeComponent } from './security-master/security-home/security-home.component';
import { HttpClientModule } from '@angular/common/http';
import { GridModule, ExcelModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { IconsModule } from '@progress/kendo-angular-icons';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { IndicatorsModule } from '@progress/kendo-angular-indicators';
import { MenusModule } from '@progress/kendo-angular-menu';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { ServerErrorComponent } from './server-error/server-error.component';
import { UserNotAllowedComponent } from './user-not-allowed/user-not-allowed.component';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LabelModule } from '@progress/kendo-angular-label';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { PopupModule } from '@progress/kendo-angular-popup';
import { ListBoxModule } from '@progress/kendo-angular-listbox';
import { SecurityDetailsComponent } from './security-master/security-details/security-details.component';
import { MultiSelectFiltersComponent } from './common/multi-select-filters/multi-select-filters.component';
import { NotificationModule } from '@progress/kendo-angular-notification';
import { DateRangeFilterComponent } from './common/date-range-filter/date-range-filter.component';
import { LoadingComponent } from './common/loading/loading.component';
import { DataGridComponent } from './common/data-grid/data-grid.component';
import { SearchBoxComponent } from './common/search-box/search-box.component';
import { SidebarMenuComponent } from './common/sidebar-menu/sidebar-menu.component';
import { BreadCrumbComponent } from './common/bread-crumb/bread-crumb.component';
import { DetailsFormComponent } from './security-master/details-form/details-form.component';
import { CrossReferenceComponent } from './security-master/cross-reference/cross-reference.component';
import { ClassificationComponent } from './security-master/classification/classification.component';
import { CreateCrossReferenceComponent } from './security-master/cross-reference/create-cross-refference/create-cross-reference.component';

@NgModule({
  declarations: [
    LayoutComponent,
    HeaderComponent,
    SecurityHomeComponent,
    ServerErrorComponent,
    UserNotAllowedComponent,
    SecurityDetailsComponent,
    MultiSelectFiltersComponent,
    DateRangeFilterComponent,
    LoadingComponent,
    DataGridComponent,
    SearchBoxComponent,
    SidebarMenuComponent,
    BreadCrumbComponent,
    DetailsFormComponent,
    CreateCrossReferenceComponent,
    CrossReferenceComponent,
    ClassificationComponent,
  ],
  imports: [
    CommonModule,
    LayoutRoutingModule,
    HttpClientModule,
    GridModule,
    ExcelModule,
    MenusModule,
    PopupModule,
    DropDownsModule,
    ListBoxModule,
    LayoutModule,
    IconsModule,
    NavigationModule,
    ButtonsModule,
    IndicatorsModule,
    DialogsModule,
    InputsModule,
    FormsModule,
    ReactiveFormsModule,
    LabelModule,
    DateInputsModule,
    NotificationModule,
  ],
})
export class MainLayoutModule {}
