import { Component, OnInit } from '@angular/core';
import { APP_DETAILS } from '../core/const/constants';
import { SharedService } from '../core/services/shared.service';
import { SVGIcon, envelopIcon, fileTxtIcon } from '@progress/kendo-svg-icons';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.scss',
})
export class LayoutComponent implements OnInit {
  public fullname: any = '';
  public userRoles?: any;
  public APP_DETAILS = APP_DETAILS;
  public envelopIcon: SVGIcon = envelopIcon;
  public fileTxtIcon: SVGIcon = fileTxtIcon;

  constructor(private _sharedService: SharedService) {}

  ngOnInit(): void {
    this._sharedService.callEntitlements(() => {
      this.fullname = this._sharedService.getUserName();
      this._sharedService.getUserRole.subscribe(
        (data) => (this.userRoles = data)
      );
    });
  }
}
