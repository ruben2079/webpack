export const entitlement_mock: { [key: string]: any } = {
  reader: {
    Username: 'Demi.Wang@voya.com',
    FamilyName: 'Wang',
    GivenName: 'Demi',
    CanRead: true,
    CanSetup: false,
  },
  admin: {
    Username: 'Demi.Wang@voya.com',
    FamilyName: 'Wang',
    GivenName: 'Demi',
    CanRead: true,
    CanSetup: true,
  },
};
