export const environment = {
    production: false,
    msalConfig: {
        auth: {
            clientId: 'cec5d933-976d-4a9d-acbc-3d622367ebc8',
            authority: 'https://login.microsoft.com/e3054106-a46a-4dc0-b86d-2ba84a24cdc4',
            scopes: ['user.read']
        }
    },
    apiConfig: {
        scopes: ['api://PortfolioMasterTest/PortfolioMaster.User'],
        uri: 'https://graph.microsoft.com/v1.0/me'
    },
    apiUrl: 'astr-api-test.iam.intranet'
};

   