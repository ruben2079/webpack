export const environment = {
	production: true,
	msalConfig: {
		auth: {
			clientId: '9a15041a-8b25-415f-b0ff-d63c1ae1aa0e',
			authority: 'https://login.microsoft.com/e3054106-a46a-4dc0-b86d-2ba84a24cdc4',
            scopes: ['user.read']
		}
	},
	apiConfig: {
		scopes: ['api://PortfolioMaster/PortfolioMaster.User'],
        uri: 'https://graph.microsoft.com/v1.0/me'
	},
	apiUrl: 'astr-api.iam.intranet'
};

   