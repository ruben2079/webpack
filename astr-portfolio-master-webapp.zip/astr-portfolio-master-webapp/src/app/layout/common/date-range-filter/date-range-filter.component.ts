import {
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Output,
} from '@angular/core';
import { SVGIcon, calendarIcon } from '@progress/kendo-svg-icons';
import { getDisplayText } from '../../../core/utils/utils';

@Component({
  selector: 'app-date-range-filter',
  templateUrl: './date-range-filter.component.html',
  styleUrl: './date-range-filter.component.scss',
})
export class DateRangeFilterComponent {
  public isDateExpand = false;
  public calendarIcon: SVGIcon = calendarIcon;
  public min: any = '';
  public max: any = '';
  public getDisplayText = getDisplayText;

  @Output()
  public onSave = new EventEmitter<boolean>();

  constructor(private elRef: ElementRef) {}

  @HostListener('document:mousedown', ['$event'])
  private documentMousedown(event: any): void {
    if (
      !this.contains(event.target) &&
      !!this.isDateExpand &&
      !document.getElementsByClassName('k-calendar-view').length
    ) {
      this.close();
    }
  }

  reset() {
    this.min = null;
    this.max = null;
  }

  close() {
    this.isDateExpand = !this.isDateExpand;
    this.reset();
  }

  save() {
    let dateObj: any = { min: this.min, max: this.max };
    this.onSave.emit(dateObj);
    this.isDateExpand = false;
  }

  public value: Date = new Date(2024, 1, 1);
  public disabled: Date[] = [new Date(2024, 1, 10)];

  public disabledMinDates = (date: Date): boolean => {
    if (!this.max) {
      return false;
    }

    return date > this.max;
  };

  public disabledMaxDates = (date: Date): boolean => {
    return this.min > date;
  };

  // this method help make a date rang
  isDateInArray(targetDate: Date): boolean {
    return this.disabled.some(
      (date) => date.getTime() === targetDate.getTime()
    );
  }

  private contains(target: EventTarget): boolean {
    return this.elRef.nativeElement.contains(target);
  }
}
