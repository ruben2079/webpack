import { Component } from "@angular/core";
import { LoaderSize, LoaderType } from "@progress/kendo-angular-indicators";
import { LoadingService } from "../../../core/services/loading.service";

@Component({
    selector: 'app-loading',
    templateUrl: './loading.component.html',
    styleUrl: './loading.component.scss',
  })
  export class LoadingComponent {
    public type = <LoaderType>"converging-spinner";
    public size = <LoaderSize>"large"

    constructor(public loader: LoadingService) { }
  }