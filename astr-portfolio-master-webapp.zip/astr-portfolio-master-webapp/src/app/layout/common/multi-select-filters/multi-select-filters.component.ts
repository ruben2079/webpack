import {
  Component,
  EventEmitter,
  Input,
  Output,
  ElementRef,
  HostListener,
} from '@angular/core';
import { ActionName } from '@progress/kendo-angular-listbox';
import {
  SVGIcon,
  caretAltDownIcon,
  searchIcon,
} from '@progress/kendo-svg-icons';
import _ from 'lodash';

@Component({
  selector: 'app-multi-select-filters',
  templateUrl: './multi-select-filters.component.html',
  styleUrl: './multi-select-filters.component.scss',
})
export class MultiSelectFiltersComponent {
  public rightFilterOptions: Array<any> = [];
  public savedOption: any = {
    allOptions: [],
    selectedItems: [],
  };
  public show = false;
  public filterVal: any = [];
  public inpVal: any = '';
  public isFlag = true;
  public caretAltDownIcon: SVGIcon = caretAltDownIcon;
  public searchIcon: SVGIcon = searchIcon;
  public state: any = {
    allOptions: [],
    selectedItems: [],
  };
  public selectedState: any = {
    allOptions: [],
    selectedItems: [],
  };

  @Input() public title?: any = 'List';
  @Input() public isTag?: any = '';
  @Input() public additionalFilter?: any;
  @Input()
  public itemRender?: any;
  @Input()
  set filterOptions(filterOptions: Array<Object>) {
    let optionsData = filterOptions?.length > 0 ? filterOptions : [];
    this.state.allOptions = optionsData;
    this.state.savedOption = [...optionsData];
  }

  @Output()
  public onSave = new EventEmitter<boolean>();

  constructor(private elRef: ElementRef) {}

  ngOnInit(): void {
    if (this.isTag?.key) {
      this.isFlag = false;
      this.state.selectedItems.push(this.isTag.value);
      this.savedOption.selectedItems = [...this.state.selectedItems];
      this.savedOption.allOptions = [...this.state.allOptions];
    }
    this.selectedState = {
      allOptions: [],
      selectedItems: [],
    };
  }

  @HostListener('document:mousedown', ['$event'])
  private documentMousedown(event: any): void {
    if (!this.contains(event.target) && !!this.show) {
      this.close();
    }
  }

  public handleActionClick(e: ActionName): void {
    const newOptions = this.state.allOptions.filter(
      (option: string) => !this.selectedState.allOptions.includes(option)
    );
    const newSelectedItems = this.state.selectedItems.filter(
      (option: string) => !this.selectedState.selectedItems.includes(option)
    );
    switch (e) {
      case 'transferTo':
        this.state.selectedItems = _.uniq([
          ...this.state.selectedItems,
          ...this.selectedState.allOptions,
        ]);
        this.state.allOptions = [...newOptions];
        break;
      case 'transferAllTo':
        this.state.selectedItems = _.uniq([
          ...this.state.selectedItems,
          ...this.state.allOptions,
        ]);
        this.state.allOptions = [];
        break;

      case 'transferFrom':
        this.state.allOptions = _.uniq([
          ...this.state.allOptions,
          ...this.selectedState.selectedItems,
        ]);
        this.state.selectedItems = [...newSelectedItems];
        break;
      case 'transferAllFrom':
        this.state.allOptions = _.uniq([
          ...this.state.allOptions,
          ...this.state.selectedItems,
        ]);
        this.state.selectedItems = [];
        break;
      default:
        break;
    }
    this.onValueChange(this.inpVal);
  }

  resetSelected = () => {
    this.selectedState = {
      allOptions: [],
      selectedItems: [],
    };
    this.bindingEvent();
  };

  resetOptions = () => {
    if (this.isFlag) {
      this.state.allOptions = [...this.state.savedOption];
      this.state.selectedItems = [];
    } else {
      this.state.allOptions = [...this.savedOption.allOptions];
      this.state.selectedItems = [...this.savedOption.selectedItems];
    }
    this.resetSelected();
    this.handleChangeFilter(this.inpVal);
  };

  close() {
    this.show = !this.show;
    this.resetOptions();
  }

  public onValueChange(value: any): void {
    this.inpVal = value;
    this.handleChangeFilter(value);
    this.resetSelected();
  }

  handleChangeFilter(value: any) {
    let filterdata = !!value
      ? this.state.allOptions.filter(
          (item: any) =>
            item.toLowerCase().includes(value.toLowerCase()) ||
            (!!this.additionalFilter &&
              !!this.additionalFilter[item] &&
              this.additionalFilter[item]
                .toLowerCase()
                .includes(value.toLowerCase()))
        )
      : this.state.allOptions;
    this.filterVal = filterdata;
  }

  save() {
    this.savedOption.selectedItems = [...this.state.selectedItems];
    this.savedOption.allOptions = [...this.state.allOptions];
    this.resetSelected();
    this.onSave.emit(this.savedOption.selectedItems);
    this.show = false;
    this.isFlag = false;
  }

  public optionEvent: any = (e: any) => {
    let item = e.target.querySelectorAll('Span');
    item = (!!item.length ? item[0] : e.target).innerText;
    if (!!item) {
      if (this.selectedState.allOptions.indexOf(item) == -1) {
        this.selectedState.allOptions.push(item);
      } else {
        let index = this.selectedState.allOptions.indexOf(item);
        this.selectedState.allOptions.splice(index, 1);
      }
    }
    this.updateSelection();
  };

  public selectedEvent: any = (e: any) => {
    let item = e.target.querySelectorAll('Span');
    item = (!!item.length ? item[0] : e.target).innerText;
    if (!!item) {
      if (this.selectedState.selectedItems.indexOf(item) == -1) {
        this.selectedState.selectedItems.push(item);
      } else {
        let index = this.selectedState.selectedItems.indexOf(item);
        this.selectedState.selectedItems.splice(index, 1);
      }
    }
    this.updateSelection();
  };

  public bindingEvent(): void {
    if (this.elRef) {
      const listboxs = this.elRef.nativeElement.querySelectorAll('.list_panel');
      if (!!listboxs.length) {
        listboxs[0].removeEventListener('click', this.optionEvent);
        listboxs[0].addEventListener('click', this.optionEvent);
        listboxs[1].removeEventListener('click', this.selectedEvent);
        listboxs[1].addEventListener('click', this.selectedEvent);
      }
    }
  }

  public updateSelection(): void {
    if (this.elRef) {
      const listboxs = this.elRef.nativeElement.querySelectorAll('.list_panel');
      listboxs.forEach((listbox: any) => {
        let items = listbox.querySelectorAll('.k-list-item');
        const isAllOptions = listbox.classList.contains('option_list');
        let updateSelectionItem = isAllOptions
          ? this.selectedState.allOptions
          : this.selectedState.selectedItems;
        items.forEach((item: any) => {
          if (updateSelectionItem.indexOf(item.textContent) != -1) {
            item.classList.add('k-selected');
          } else {
            if (item.classList.contains('k-selected')) {
              item.classList.remove('k-selected');
            }
          }
        });
      });
    }
  }

  private contains(target: EventTarget): boolean {
    return this.elRef.nativeElement.contains(target);
  }
}
