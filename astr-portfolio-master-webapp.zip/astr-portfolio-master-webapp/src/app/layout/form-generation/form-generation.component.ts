import { Component, Input, OnInit, ViewChild } from '@angular/core';
import {
  Aladdin_form_fields,
  FormGenarationTypes,
  formrequiredFields,
  OneStop_form_fields,
  SGA_form_fields,
} from '../../core/const/constants';
import {
  checkRequiredFields,
  dateFormatterUTCtoLocal,
  genenteExportData,
  getDataFieldTitle,
  getRequiredFieldsBasedonStatus,
} from '../../core/utils/utils';
import { ExcelExportComponent } from '@progress/kendo-angular-excel-export';
import { Portfolio } from '../../core/model/portfolios.interface';
import { DialogService } from '@progress/kendo-angular-dialog';
import { FormGenerationDailogComponent } from './form-generation-dailog/form-generation-dailog.component';
import { SharedService } from '../../core/services/shared.service';

@Component({
  selector: 'app-form-generation',
  templateUrl: './form-generation.component.html',
  styleUrl: './form-generation.component.scss',
})
export class FormGenerationComponent implements OnInit {
  @Input() public portfolio!: Portfolio;
  @Input() public onHighlightRequiredFields!: (
    fields: string[],
    editForm: string
  ) => void;
  @Input() public onDownloadstreamPortfolio!: (apiStr: string) => void;
  @Input() public benchmarks: Record<number, string> = {};
  public errorMessage: any = null;
  public portfolioForBackend: any[] = [];
  public formtitle!: string;
  public oneStopFormFields: any = [];
  public date = new Date();
  public filenameOneStop: any =
    'OneStop_Setup_Form_' + this.date.toISOString() + '.xlsx';
  public filenameAladdin: any =
    'Aladdin_Setup_Form_' + this.date.toISOString() + '.xlsx';
  public filenameSGA: any =
    'SGA_Setup_Form_' + this.date.toISOString() + '.xlsx';
  public userRoles: any;
  public enetitlement: any;
  @ViewChild('excelexportOneStop', { static: true })
  excelexportOneStop!: ExcelExportComponent;

  @ViewChild('excelexportSga', { static: true })
  excelexportSga!: ExcelExportComponent;

  @ViewChild('excelexportAladdin', { static: true })
  excelexportAladdin!: ExcelExportComponent;

  public gridData = [
    {
      key: 'IMDS',
      Name: 'IMDS Setup Feed',
      type: 'load downStream',
      val: FormGenarationTypes.imds,
      submit: false,
    },
    {
      key: 'DMI',
      Name: 'DMI Setup Feed',
      type: 'load downStream',
      val: FormGenarationTypes.dmi,
      submit: false,
    },
    {
      key: 'OneStop',
      Name: 'OneStop Setup Form',
      type: 'Generate Form',
      val: FormGenarationTypes.oneStop,
      submit: false,
    },
    {
      key: 'SGA',
      Name: 'SGA Setup Form',
      type: 'Generate Form',
      val: FormGenarationTypes.sga,
      submit: false,
    },
    {
      key: 'Aladdin',
      Name: 'Aladdin Setup Form',
      type: 'Generate Form',
      val: FormGenarationTypes.Aladdin,
      submit: false,
    },
  ];

  constructor(
    private dialogService: DialogService,
    private _sharedService: SharedService
  ) {}

  ngOnInit(): void {
    this.getTimestampDMI();
    this.getTimestampIMDS();

    let currentPort = JSON.parse(JSON.stringify(this.portfolio));

    if (JSON.stringify(currentPort) !== '{}') {
      this.portfolioForBackend = genenteExportData(
        [currentPort],
        this.benchmarks
      );
    }
    this._sharedService.getUserRole.subscribe(
      (data) => (this.userRoles = data)
    );

    this.enetitlement = this._sharedService.getEntitlement();
  }

  getTimestampDMI() {
    if (
      this.portfolio.PortfolioSubscribers &&
      this.portfolio.PortfolioSubscribers.length > 0
    ) {
      const dmisObj = this.portfolio?.PortfolioSubscribers.find(
        (ele: any) => ele.DownstreamSystemName == FormGenarationTypes.dmi
      );

      if (dmisObj && JSON.stringify(dmisObj) !== '{}') {
        this.gridData.find((ele: any) => {
          if (ele.val == FormGenarationTypes.dmi) {
            ele.Status = dmisObj.Status;
            ele.LastCompletedTransmissionTimestamp = dateFormatterUTCtoLocal(
              dmisObj.LastCompletedTransmissionTimestamp,
              false
            );
          }
        });
      }
    }
  }

  getTimestampIMDS() {
    if (
      this.portfolio.PortfolioSubscribers &&
      this.portfolio.PortfolioSubscribers.length > 0
    ) {
      const imdsObj = this.portfolio?.PortfolioSubscribers.find(
        (ele: any) => ele.DownstreamSystemName == FormGenarationTypes.imds
      );

      if (imdsObj && JSON.stringify(imdsObj) !== '{}') {
        this.gridData.find((ele: any) => {
          if (ele.val == FormGenarationTypes.imds) {
            ele.Status = imdsObj.Status;
            ele.LastCompletedTransmissionTimestamp = dateFormatterUTCtoLocal(
              imdsObj.LastCompletedTransmissionTimestamp,
              false
            );
          }
        });
      }
    }
  }

  generate(data: any): void {
    const dialog = this.dialogService.open({
      title: 'Generate Form',
      content: FormGenerationDailogComponent,
      maxWidth: 600,
      minHeight: 50,
      minWidth: 350,
    });

    const formRequiredFields = Reflect.get(formrequiredFields, data.val);
    const requiredFields = getRequiredFieldsBasedonStatus(
      this.portfolio,
      false,
      null,
      false,
      formRequiredFields
    );
    const formValidationResult = checkRequiredFields(
      this.portfolio,
      requiredFields
    );

    const dialogComponent = dialog.content
      .instance as FormGenerationDailogComponent;
    dialogComponent.portfolio = this.portfolio;
    dialogComponent.modelData = data;
    dialogComponent.formValidationResult = formValidationResult;

    dialog.result.subscribe((result: any) => {
      if (result.text == 'Submit') {
        this.setupForm(data);
      } else if (result.text == 'Edit') {
        this.onHighlightRequiredFields(
          formValidationResult.errorFields,
          data.val
        );
      }
    });
  }

  oneStopFormFieldsCall() {
    let oneStopFormFields = OneStop_form_fields.map((field) => ({
      field,
      title: getDataFieldTitle(field),
    }));

    return oneStopFormFields;
  }

  aladdinFormFieldsCall() {
    let aladdinFormFieldsCall = Aladdin_form_fields.map((field) => ({
      field,
      title: getDataFieldTitle(field),
    }));

    return aladdinFormFieldsCall;
  }

  sgaFormFieldsCall() {
    let sgaFormFieldsCall = SGA_form_fields.map((field) => ({
      field,
      title: getDataFieldTitle(field),
    }));

    return sgaFormFieldsCall;
  }

  downloadstreamPortfolio(item: any): void {
    let apiStr = '';
    if (this.portfolio.Id && this.portfolio.Id > 0) {
      apiStr = item.val;
      if (apiStr) {
        this.onDownloadstreamPortfolio(apiStr);
      }
    }
  }

  downloadExcel(item: any): void {
    if (item.val == FormGenarationTypes.oneStop) {
      this.excelexportOneStop.save();
    }
    if (item.val == FormGenarationTypes.sga) {
      this.excelexportSga.save();
    }
    if (item.val == FormGenarationTypes.Aladdin) {
      this.excelexportAladdin.save();
    }
  }

  setupForm(item: any): void {
    if (
      item.val == FormGenarationTypes.imds ||
      item.val == FormGenarationTypes.dmi
    ) {
      this.downloadstreamPortfolio(item);
    }

    if (
      item.val == FormGenarationTypes.oneStop ||
      item.val == FormGenarationTypes.sga ||
      item.val == FormGenarationTypes.Aladdin
    ) {
      this.downloadExcel(item);
    }
  }

  disableDownStream(dataItem: any) {
    return (
      dataItem.Status ||
      (dataItem.type.includes('downStream') &&
        ((this.userRoles === 'Data Owner' &&
          !this.enetitlement.DownstreamSystems.includes(dataItem.key)) ||
          this.userRoles === 'Reader'))
    );
  }
}
