import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormGenerationDailogComponent } from './form-generation-dailog.component';

describe('FormGenerationDailogComponent', () => {
  let component: FormGenerationDailogComponent;
  let fixture: ComponentFixture<FormGenerationDailogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormGenerationDailogComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FormGenerationDailogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
