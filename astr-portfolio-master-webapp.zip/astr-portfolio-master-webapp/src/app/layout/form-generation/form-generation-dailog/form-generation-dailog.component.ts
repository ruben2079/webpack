import { Component, Input, OnInit } from '@angular/core';
import {
  FormGenarationTypes,
  portfolio_key_name_mapping,
} from '../../../core/const/constants';
import { Portfolio } from '../../../core/model/portfolios.interface';
import { DialogContentBase, DialogRef } from '@progress/kendo-angular-dialog';
import { SharedService } from '../../../core/services/shared.service';

@Component({
  selector: 'app-form-generation-dailog',
  templateUrl: './form-generation-dailog.component.html',
  styleUrl: './form-generation-dailog.component.scss',
})
export class FormGenerationDailogComponent
  extends DialogContentBase
  implements OnInit
{
  @Input('portfolio') portfolio!: Portfolio;
  @Input('modelData') modelData?: any;
  @Input() formValidationResult!: any;
  public bodyMessage: string = '';
  public requiredBodyfields: string = '';
  public showEditPortfolioButton?: boolean;
  public userRoles: any;

  constructor(dialog: DialogRef, private _sharedService: SharedService) {
    super(dialog);
  }

  ngOnInit(): void {
    this._sharedService.getUserRole.subscribe(
      (data) => (this.userRoles = data)
    );
    this.validateform(this.modelData.val);
  }

  validateform(val: string) {
    this.showEditPortfolioButton =
      this.formValidationResult.isFailed && this.userRoles !== 'Reader';
    if (this.formValidationResult.isFailed) {
      const fieldNames = this.formValidationResult.errorFields.map(
        (x: string) => portfolio_key_name_mapping[x]
      );
      this.bodyMessage = `Missing data for below data fields:`;
      this.requiredBodyfields = fieldNames.join(', ');
    } else {
      this.bodyMessage =
        val === FormGenarationTypes.Aladdin ||
        val === FormGenarationTypes.sga ||
        val === FormGenarationTypes.oneStop
          ? `Confirm generate form for ${val}`
          : `Confirm feed downstream form for  ${val}`;
    }
  }

  editPortfolio() {
    this.dialog.close({ text: 'Edit', themeColor: 'primary' });
  }

  onCancel(): void {
    this.dialog.close({ text: 'Cancel' });
  }

  onSubmit(): void {
    this.dialog.close({ text: 'Submit', themeColor: 'primary' });
  }
}
