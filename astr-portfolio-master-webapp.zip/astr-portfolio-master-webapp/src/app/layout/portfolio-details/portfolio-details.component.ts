import { Component, OnInit, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { SharedService } from '../../core/services/shared.service';
import { HttpService } from '../../core/services/http.service';
import {
  Portfolio,
  PortfolioTagId,
} from '../../core/model/portfolios.interface';
import { ReferenceField } from '../../core/model/reference-fields.interface';
import { SVGIcon, envelopIcon, pencilIcon } from '@progress/kendo-svg-icons';
import * as constants from '../../core/const/constants';
import { NotificationService } from '@progress/kendo-angular-notification';
import { default_portfolio_content_view } from '../../core/const/constants';
import { PortfolioDetailsContentComponent } from '../portfolio-details-content/portfolio-details-content.component';
import { DOWNSTREAM } from '../../core/const/api.const';
import { map, Observable } from 'rxjs';
import { DialogService } from '@progress/kendo-angular-dialog';
import { PortfolioStatus } from '../../core/model/portfolios.interface';

@Component({
  selector: 'app-portfolio-details',
  templateUrl: './portfolio-details.component.html',
  styleUrl: './portfolio-details.component.scss',
})
export class PortfolioDetailsComponent implements OnInit {
  public portfolioCode: string | undefined;
  public portfolio: Portfolio | undefined;
  public updatedPortfolio: Portfolio | undefined;
  public referenceFields: ReferenceField[] | undefined;
  public tagsAdGroups: Array<any> = [];
  public isEditing: boolean = false;
  public isCloning: boolean = false;
  public pencilIcon: SVGIcon = pencilIcon;
  public envelopIcon: SVGIcon = envelopIcon;
  public portfolioStatusMapping: any = constants.status_options;
  public cloneObject: any;
  public isValid: boolean = true;
  public constants: any = constants;
  public userRoles: any;
  public activeTab: string = default_portfolio_content_view;
  public editForm?: string | null | undefined = null;
  public PortfolioStatus: any = PortfolioStatus;
  @ViewChild(PortfolioDetailsContentComponent)
  portfolioDetailsContentComponent:
    | PortfolioDetailsContentComponent
    | undefined;

  constructor(
    private route: ActivatedRoute,
    private _location: Location,
    private router: Router,
    private _httpService: HttpService,
    private notificationService: NotificationService,
    private _sharedService: SharedService,
    private dialogService: DialogService
  ) {}

  async ngOnInit(): Promise<void> {
    this.route.queryParams.subscribe((params) => {
      this.portfolioCode = params['portfolio'];
    });

    this.getPortfolio();
    this.referenceFields =
      await this._httpService.getPortfolioReferenceFields();
    this.getTagsAdGroups();
    this._sharedService.referenceData.next(this.referenceFields);
    this._sharedService.callEntitlements();
    this.userRoles = this._sharedService.getUserRole.subscribe(
      (data) => (this.userRoles = data)
    );
    if (this._sharedService.openPortfolioInEditMode) {
      this.onEdit();
    }
  }

  getPortfolio() {
    this._httpService
      .getPortfolioByPortfolioCode(this.portfolioCode!)
      .subscribe({
        next: (portfolio: any) => {
          this.portfolio = portfolio;
          this.resetPortfolio();
        },
        error: () => {
          this.backToList();
        },
      });
  }

  getLocaleDateString(date: any) {
    return !!date ? new Date(date).toLocaleDateString() : null;
  }

  onCancel() {
    this.isEditing = false;
    this.resetPortfolio();
  }

  resetPortfolio() {
    this.updatedPortfolio = undefined;
    this.updatedPortfolio = JSON.parse(JSON.stringify(this.portfolio));
    this.editForm = null;
  }

  async onSave() {
    if (!this.updatedPortfolio) {
      return;
    }

    this._httpService
      .updatePortfolioById(this.updatedPortfolio!.Id!, this.updatedPortfolio)
      .subscribe({
        next: (portfolio: any) => {
          // Catch no updates detected case.
          if (!(portfolio.detail === 'No updates were detected.')) {
            this.portfolio = portfolio;
            this.resetPortfolio();
          }
        },
        complete: () => {
          // 'onCompleted' callback.
          this.notificationService.show({
            content: 'Portfolio updated successfully!',
            cssClass: 'button-notification',
            animation: { type: 'slide', duration: 100 },
            position: { horizontal: 'center', vertical: 'top' },
            type: { style: 'success', icon: true },
            hideAfter: 5000,
          });
          this.isEditing = false;
        },
      });
  }

  onTagChanged(): Promise<ReferenceField[]> {
    return this._httpService
      .getPortfolioReferenceFields()
      .then((data) => (this.referenceFields = data));
  }

  onPortfolioTagsChanged(newTagIds: PortfolioTagId[]): Observable<Portfolio> {
    let portfolio = JSON.parse(JSON.stringify(this.portfolio)) as Portfolio;
    portfolio.PortfolioTagIds = newTagIds;

    return this._httpService
      .updatePortfolioById(portfolio!.Id!, portfolio)
      .pipe(
        map((portfolio) => {
          this.portfolio = portfolio;
          this.resetPortfolio();

          return portfolio;
        })
      );
  }

  onDownloadstreamPortfolio(str: string): void {
    const genrateUrl = `${DOWNSTREAM.downstreamPortfolio()}/${
      this.portfolio!.Id
    }/loadtodownstream/${str}`;
    this._httpService.put(genrateUrl, '').subscribe(() => {
      this._httpService
        .getPortfolioByPortfolioCode(this.portfolioCode!)
        .subscribe({
          next: (data: any) => {
            this.portfolio = data;
            this.resetPortfolio();
          },
          complete: () => {
            this.notificationService.show({
              content: 'Load Downstream successfully!',
              cssClass: 'button-notification',
              animation: { type: 'slide', duration: 100 },
              position: { horizontal: 'center', vertical: 'top' },
              type: { style: 'success', icon: true },
              hideAfter: 5000,
            });
          },
        });
    });
  }

  onEdit() {
    this.isEditing = true;

    // If edit button is clicked and viewing tags or form, redirect to details.
    if (['tags', 'form'].includes(this.activeTab)) {
      this.activeTab = default_portfolio_content_view;
    }
  }

  clonePortfolio() {
    this.isCloning = true;
  }

  backToList() {
    this._sharedService.pushTag.next(null);
    this.router.navigate(['portfolio']);
  }

  routeToPortfolio(portfolioCode: string) {
    this.router
      .navigate(['/portfolio/details'], {
        queryParams: { portfolio: portfolioCode },
      })
      .then(() => {
        window.location.reload();
      });
  }

  receiveMessageFromModal(response: boolean) {
    this.isCloning = response;
  }

  renderHeaderText() {
    if (!this.isEditing) {
      return this.portfolio?.PortfolioName!;
    }

    return this.editForm
      ? `Edit for ${this.editForm} Form - ${this.portfolio?.PortfolioName!}`
      : `Edit - ${this.portfolio?.PortfolioName!}`;
  }

  getTagsAdGroups() {
    this._httpService.getTagsAdGroup().subscribe({
      next: (data) => {
        this.tagsAdGroups = data[0].Options;
      },
    });
  }

  notifyOwner() {
    const notifyDialog = this.dialogService.open({
      title: 'Notify Data Owners',
      content: 'Are you sure you want to notify data owners of missing data?',
      actions: [{ text: 'Cancel' }, { text: 'Ok', themeColor: 'primary' }],
      minWidth: 330,
      minHeight: 180,
    });

    notifyDialog.result.subscribe((result: any) => {
      if (result.text == 'Ok') {
        this._httpService.notifyOwner(this.portfolio?.Id).subscribe({
          next: (data: any) => {
            this.notificationService.show({
              content: 'Notified data owners successfully!',
              cssClass: 'button-notification',
              animation: { type: 'slide', duration: 100 },
              position: { horizontal: 'center', vertical: 'top' },
              type: { style: 'success', icon: true },
              hideAfter: 5000,
            });
          },
        });
      }
    });
  }
}
