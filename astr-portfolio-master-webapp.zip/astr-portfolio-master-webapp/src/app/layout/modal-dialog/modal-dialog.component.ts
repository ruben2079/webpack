import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { SharedService } from '../../core/services/shared.service';
import { VehicleName } from '../../core/model/vehicle-name-model';
import { AssetClassName } from '../../core/model/asset-class-name-model';
import {
  ABOR_DQ_key,
  FBL_DQ_Vehicle_key,
  PV_DQ_Vehicle_key,
  TAS_Inst_DQ_Sub_Vehicle_key,
  TAS_Retail_DQ_Sub_Vehicle_key,
  portfolio_inputs_key_max_length_mapping,
  status_options,
} from '../../core/const/constants';
import { HttpService } from '../../core/services/http.service';
import { CLONE_PORTFOLIO, PM_API } from '../../core/const/api.const';
import { Router } from '@angular/router';
import { NotificationService } from '@progress/kendo-angular-notification';
import {
  LoaderType,
  LoaderThemeColor,
  LoaderSize,
} from '@progress/kendo-angular-indicators';
import { HttpErrorResponse } from '@angular/common/http';
import { DialogRef } from '@progress/kendo-angular-dialog';

@Component({
  selector: 'app-modal-dialog',
  templateUrl: './modal-dialog.component.html',
  styleUrl: './modal-dialog.component.scss',
})
export class ModalDialogComponent implements OnInit {
  @Input()
  public isClone!: boolean;
  @Input()
  public cloneObject?: any;
  public subVehicleType: any;
  @Input()
  public opened: boolean = false;
  @Input()
  public isCloneFromDetail?: boolean = false;
  @Output()
  public onModalEventChange = new EventEmitter<boolean>();
  public vehicleListType: any;
  public typeListType: any;
  public assetClassType: any;
  public codeType: any;
  public investmentStrategyType: any;
  public nameType!: string;
  public referenceDataFields: any;
  public investmentStrategyReferenceFields: any;
  public parentPortfolioType: any;
  public vehicleType: Array<string> = [];
  public subVehicle: Array<string> = [];
  public typeList: Array<string> = [];
  public assetClass: Array<string> = [];
  public investmentStrategy: Array<string> = [];
  public parentPortfolioTypes: Array<string> = [];
  public isSubmitted = false;
  public serverError!: HttpErrorResponse;
  public errorMessage!: string;
  public dialogRef!: DialogRef;
  public hideFlag: boolean = false;
  public pattern = /^[a-zA-Z0-9_-]+$/;
  public loaders = [
    {
      type: <LoaderType>'converging-spinner',
      themeColor: <LoaderThemeColor>'info',
      size: <LoaderSize>'medium',
    },
  ];

  constructor(
    private _sharedService: SharedService,
    private formBuilder: FormBuilder,
    private _http: HttpService,
    private router: Router,
    private notificationService: NotificationService
  ) {}

  public registerForm: FormGroup = new FormGroup({
    code: new FormControl(),
    name: new FormControl(),
    vehicleType: new FormControl(),
    subVehicle: new FormControl(),
    typeList: new FormControl(),
    assetClass: new FormControl(),
    investmentStrategy: new FormControl(),
    parentPortfolioTypes: new FormControl(),
  });

  ngOnInit(): void {
    this.codeType = '';
    if (this.cloneObject) {
      this.vehicleListType = this.cloneObject.VehicleName;
      this.nameType = this.cloneObject.PortfolioName + ' - Copy';
      this.subVehicleType = this.cloneObject.SubVehicleName;
      this.assetClassType = this.cloneObject.AssetClassName;
      this.investmentStrategyType = this.cloneObject.InvestmentStrategyName;
      this.typeListType = this.cloneObject.PortfolioTypeName;
      this.parentPortfolioType = this.cloneObject.ParentPortfolioCode;
      this.generatePortfolioValues();
    } else {
      this.nameType = '';
      this.generatePortfolioValues();
    }

    this.registerForm = this.formBuilder.group({
      code: [
        '',
        [
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(
            portfolio_inputs_key_max_length_mapping.PortfolioCode
          ),
        ],
      ],
      name: [
        '',
        [
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(
            portfolio_inputs_key_max_length_mapping.PortfolioName
          ),
        ],
      ],
      vehicleType: ['', [Validators.required]],
      subVehicle: ['', [Validators.required]],
      typeList: ['', [Validators.required]],
      assetClass: ['', [Validators.required]],
      investmentStrategy: ['', [Validators.required]],
      parentPortfolioTypes: [''],
    });
  }

  public validationforSaving() {
    return !(
      this.registerForm.valid &&
      (this.registerForm.controls['typeList'].value != 'Sleeve' ||
        !!this.registerForm.controls['parentPortfolioTypes'].value)
    );
  }

  public generatePortfolioValues() {
    this._sharedService.getReferenceData.subscribe((data: Array<any>) => {
      const parentPortfolioCodes = data.filter(
        (res: any) => res.FieldName == 'ParentPortfolio'
      );

      this.referenceDataFields = data.filter(
        (res: any) => res.FieldName == 'Vehicle'
      );
      const portfolioTypeFields = data.filter(
        (res: any) => res.FieldName == 'PortfolioType'
      );
      const assetClassFields = data.filter(
        (res: any) => res.FieldName == 'AssetClass'
      );
      const investmentStrategyFields = data.filter(
        (res: any) => res.FieldName == 'InvestmentStrategy'
      );
      this.investmentStrategyReferenceFields = data.filter(
        (res: any) => res.FieldName == 'InvestmentStrategy'
      );
      const portfolioTypesList = portfolioTypeFields[0].Options.sort(
        (a: any, b: any) => a.Name.localeCompare(b.Name)
      );
      for (const portfolioTypes of portfolioTypesList) {
        this.typeList.push(portfolioTypes.Name);
      }
      const assetClassList = assetClassFields[0].Options.sort(
        (a: any, b: any) => a.Name.localeCompare(b.Name)
      );
      for (const assetClassField of assetClassList) {
        this.assetClass.push(assetClassField.Name);
      }
      for (const parentPortfolioCode of parentPortfolioCodes[0].Options) {
        this.parentPortfolioTypes.push(parentPortfolioCode.PortfolioCode);
      }
      for (const investmentStrategyField of investmentStrategyFields[0]
        .Options) {
        this.investmentStrategy.push(investmentStrategyField.Name);
      }
      const vehicleTypeFields = this.referenceDataFields[0].Options || [];
      for (const vehicle of vehicleTypeFields) {
        this.vehicleType.push(vehicle.Name);
      }
      const subVehicleTypeFields = vehicleTypeFields.filter(
        (vehicleName: VehicleName) => vehicleName.Name == this.vehicleListType
      );
      const subVehicles = subVehicleTypeFields[0]?.SubVehicles || [];
      for (const subvehicle of subVehicles) {
        this.subVehicle.push(subvehicle.Name);
      }
    });
  }

  public onVehicleChange(vehicleName: any) {
    const previousSelectedValue = this.vehicleListType;
    if (previousSelectedValue != vehicleName) {
      this.subVehicleType = '';
    }
    const vehicleChangeList = this.referenceDataFields[0].Options;
    const vehicleListOnChange = vehicleChangeList.filter(
      (vehicle: VehicleName) => vehicle.Name == vehicleName
    );
    const subVehiclesList = vehicleListOnChange[0].SubVehicles;
    this.subVehicle = [];
    for (const vehicleChange of subVehiclesList) {
      this.subVehicle.push(vehicleChange.Name);
    }
  }

  public onAssetClassChange(assetClassName: string) {
    const previousSelectedAssetValue = this.assetClassType;
    if (previousSelectedAssetValue != assetClassName) {
      this.investmentStrategyType = '';
    }
    const investmentStrategyList =
      this.investmentStrategyReferenceFields[0].Options;
    const assetListsOnChange = investmentStrategyList.filter(
      (assetClass: AssetClassName) =>
        assetClass.AssetClassName == assetClassName
    );
    this.investmentStrategy = [];
    for (const assetListOnChange of assetListsOnChange) {
      this.investmentStrategy.push(assetListOnChange.Name);
    }
  }

  public close(): void {
    this._sharedService.isOpened = false;
    this.opened = false;
    this.onModalEventChange.emit(this.opened);
    //this.opened = this._sharedService.isOpened;
  }

  public open(): void {
    this._sharedService.isOpened = false;
    this.hideFlag = false;
    this.opened = false;
    this.onModalEventChange.emit(this.opened);
    //this.opened =  this._sharedService.isOpened;
  }

  onSubmit(): void {
    this.isSubmitted = true;

    if (this.registerForm.invalid) {
      return;
    } else {
      let postObject: any = {};
      let action: string;
      let portfolioId: any;

      if (this.isClone) {
        portfolioId = this.cloneObject.Id;

        postObject = {
          PortfolioCode: this.registerForm.controls['code'].value,
          PortfolioName: this.registerForm.controls['name'].value,
          VehicleName: this.registerForm.controls['vehicleType'].value,
          SubVehicleName: this.registerForm.controls['subVehicle'].value,
          PortfolioTypeName: this.registerForm.controls['typeList'].value,
          AssetClassName: this.registerForm.controls['assetClass'].value,
          InvestmentStrategyName:
            this.registerForm.controls['investmentStrategy'].value,
          ParentPortfolioCode:
            this.typeListType == 'Sleeve'
              ? this.registerForm.controls['parentPortfolioTypes'].value
              : null,
        };

        action = 'clone';
        this._sharedService.isCloneClicked = true;
        this._http
          .put(`${CLONE_PORTFOLIO.clonePortfolio(portfolioId)}`, {
            ...postObject,
          })
          .subscribe({
            next: (data: any) => {
              this.notificationService.show({
                content: 'Portfolio created successfully!',
                cssClass: 'button-notification',
                animation: { type: 'slide', duration: 100 },
                position: { horizontal: 'center', vertical: 'top' },
                type: { style: 'success', icon: true },
                hideAfter: 1000,
              });
              this.isSubmitted = false;

              this._sharedService.updateCurrentPortfolio(data, action);

              const code = data.PortfolioCode;
              if (!this.isCloneFromDetail) {
                this.router
                  .navigateByUrl('/portfolio', { skipLocationChange: true })
                  .then(() => {
                    this.router.navigate(['/portfolio/details'], {
                      queryParams: { portfolio: code },
                    });
                  });
              }
              this.opened = false;
              this.onModalEventChange.emit(this.opened);
              // this.dialogRef.close();
            },
            error: (error: HttpErrorResponse) => {
              this.serverError = error;
              this.errorMessage = error?.error?.detail;
              setTimeout(() => {
                this.hideFlag = true;
              }, 5000);
            },
          });
      }
      if (!this.isClone) {
        postObject = {
          PortfolioCode: this.registerForm.controls['code'].value,
          PortfolioName: this.registerForm.controls['name'].value,
          VehicleName: this.registerForm.controls['vehicleType'].value,
          SubVehicleName: this.registerForm.controls['subVehicle'].value,
          PortfolioTypeName: this.registerForm.controls['typeList'].value,
          AssetClassName: this.registerForm.controls['assetClass'].value,
          InvestmentStrategyName:
            this.registerForm.controls['investmentStrategy'].value,
          ParentPortfolioCode:
            this.typeListType == 'Sleeve' ? this.parentPortfolioType : null,

          MultiSector: false,
          DomicileCountryName: 'UNITED STATES',
          BaseCurrencyName: 'US Dollar',
          PerformanceBookOfRecordName: 'Anova',
          FinanceAUMSourceName: 'IMDS BNY TA',
          FinanceAUMAmountTypeName: 'Market Value',
        };

        postObject = {
          ...postObject,
          Status: Object.keys(status_options)[0],
          InceptionDate: null,
          LiquidationDate: null,
          FinanceBusinessLineName:
            !!postObject.FinanceAUMSourceName &&
            postObject.FinanceAUMSourceName !== 'Do Not Load' &&
            FBL_DQ_Vehicle_key.includes(postObject.VehicleName)
              ? 'Intermediary'
              : 'Institutional',
          ProxyVotingFlag: PV_DQ_Vehicle_key.includes(postObject.VehicleName),
          ABORSystemName: ABOR_DQ_key.includes(postObject.SubVehicleName)
            ? 'Not Applicable'
            : postObject.ABORSystemName,
          TransferAgentSystemName: TAS_Inst_DQ_Sub_Vehicle_key.includes(
            postObject.SubVehicleName
          )
            ? 'BNYM Inst TA'
            : TAS_Retail_DQ_Sub_Vehicle_key.includes(postObject.SubVehicleName)
            ? 'BNYM Retail TA'
            : postObject.TransferAgentSystemName,
        };

        action = 'create';
        this._sharedService.isCreate = true;
        this._http.post(PM_API.getportfolios(), postObject).subscribe({
          next: (data: any) => {
            this.notificationService.show({
              content: 'Portfolio created successfully!',
              cssClass: 'button-notification',
              animation: { type: 'slide', duration: 100 },
              position: { horizontal: 'center', vertical: 'top' },
              type: { style: 'success', icon: true },
              hideAfter: 1000,
            });
            this.isSubmitted = false;

            this._sharedService.updateCurrentPortfolio(data, action);

            const code = data.PortfolioCode;
            this.router.navigate(['/portfolio/details'], {
              queryParams: { portfolio: code },
            });
            this._sharedService.isPortfolioCreate = true;
          },
          error: (error: HttpErrorResponse) => {
            this.serverError = error;
            this.errorMessage = error?.error?.detail;
            setTimeout(() => {
              this.hideFlag = true;
            }, 5000);
          },
        });
      }
    }
  }
  portfolioCodeValidation(event: any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (
      (charCode > 64 && charCode < 91) ||
      (charCode > 96 && charCode < 123) ||
      charCode == 8 ||
      charCode == 32 ||
      (charCode >= 48 && charCode <= 57) ||
      charCode == 45 ||
      charCode == 95
    ) {
      return true;
    }
    return false;
  }
}
