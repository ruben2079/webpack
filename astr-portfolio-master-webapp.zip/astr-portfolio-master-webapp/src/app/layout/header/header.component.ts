import { Component, OnInit } from '@angular/core';
import {
  bellIcon,
  menuIcon,
  SVGIcon,
  envelopIcon,
  fileTxtIcon,
  userIcon,
  folderIcon,
} from '@progress/kendo-svg-icons';
import { BadgeAlign } from '@progress/kendo-angular-indicators';
import { SharedService } from '../../core/services/shared.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class HeaderComponent implements OnInit {
  public menuIcon: SVGIcon = menuIcon;
  public bellIcon: SVGIcon = bellIcon;
  public envelopIcon: SVGIcon = envelopIcon;
  public fileTxtIcon: SVGIcon = fileTxtIcon;
  public folderIcon: SVGIcon = folderIcon;
  public userIcon: SVGIcon = userIcon;

  public badgeAlign: BadgeAlign = { vertical: 'bottom', horizontal: 'end' };

  CurrentInfo: any = [];
  fullname: any = '';
  userRoles: any = '';

  constructor(private _sharedService: SharedService) {}

  ngOnInit(): void {
    this.fullname = this._sharedService.getItem('fullname');
    this._sharedService.getUserRole.subscribe(
      (data) => (this.userRoles = data)
    );
  }
}
