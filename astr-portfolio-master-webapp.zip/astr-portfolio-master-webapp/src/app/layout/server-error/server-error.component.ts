import { Component } from '@angular/core';
import { APP_DETAILS } from '../../core/const/constants';

@Component({
  selector: 'app-server-error',
  templateUrl: './server-error.component.html',
  styleUrl: './server-error.component.scss',
})
export class ServerErrorComponent {
  public appName = APP_DETAILS.AppName;
  public appUrl = '/';
  public devEmail = APP_DETAILS.DevEmail;

  constructor() {}
}
