import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateTagModalDialogComponent } from './create-tag-modal-dialog.component';

describe('CreateTagModalDialogComponent', () => {
  let component: CreateTagModalDialogComponent;
  let fixture: ComponentFixture<CreateTagModalDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CreateTagModalDialogComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CreateTagModalDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
