import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { DialogContentBase, DialogRef } from '@progress/kendo-angular-dialog';
@Component({
  selector: 'app-create-tag-modal-dialog',
  templateUrl: './create-tag-modal-dialog.component.html',
  styleUrl: './create-tag-modal-dialog.component.scss',
})
export class CreateTagModalDialogComponent
  extends DialogContentBase
  implements OnInit
{
  @Input('title') title?: string;
  @Input('sendObjectforEdit') sendObjectforEdit: any;
  @Input()
  public portfolioDetails?: any;
  @Input()
  public adGroup?: any;
  public passRefrence: boolean = true;
  public Name: string = '';
  public ADGroupName!: string;
  public PortfolioTagDescription: string = '';
  public adGroupValue: Array<string> = [];
  public addToPortfolio: string = '';
  public submitButtonText: string = 'Save';

  constructor(dialog: DialogRef, private formBuilder: FormBuilder) {
    super(dialog);
  }

  public registerTagForm: FormGroup = new FormGroup({
    Name: new FormControl(),
    PortfolioTagDescription: new FormControl(),
    ADGroupName: new FormControl(),
    passRefrence: new FormControl(),
  });

  ngOnInit(): void {
    this.addToPortfolio = `Add tag to current portfolio (${this.portfolioDetails.PortfolioName}) `;
    if (this.title == 'Edit') {
      this.Name = this.sendObjectforEdit.Name;
      this.PortfolioTagDescription =
        this.sendObjectforEdit.PortfolioTagDescription;
      this.ADGroupName = this.sendObjectforEdit.ADGroupName;
    }

    if (this.adGroup) {
      for (const x of this.adGroup) {
        this.adGroupValue.push(x.Name);
      }
    }

    this.registerTagForm = this.formBuilder.group({
      Name: ['', Validators.required],
      PortfolioTagDescription: ['', Validators.required],
      ADGroupName: ['', Validators.required],
      passRefrence: [''],
    });
  }

  onCheckboxChange(event: any) {
    this.dialogData.isAddTagToPortfolio = event.target.checked;
  }

  public onCancelAction(): void {
    this.dialog.close({ text: 'Cancel' });
  }

  public onConfirmAction(): void {
    this.dialog.close({ text: 'Submit', themeColor: 'primary' });
  }

  public dialogData: any = {
    title: this.title,
    isDialogClose: false,
    tagRequest: {},
    isAddTagToPortfolio: true,
  };
}
