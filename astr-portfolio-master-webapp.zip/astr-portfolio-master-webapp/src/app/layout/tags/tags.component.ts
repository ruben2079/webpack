import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { ColumnMenuSettings } from '@progress/kendo-angular-grid';
import { SVGIcon, moreVerticalIcon } from '@progress/kendo-svg-icons';
import { SharedService } from '../../core/services/shared.service';
import { HttpService } from '../../core/services/http.service';
import { CREATE_TAG, EDIT_TAG } from '../../core/const/api.const';
import {
  Portfolio,
  PortfolioTagId,
} from '../../core/model/portfolios.interface';
import _ from 'lodash';
import { Router } from '@angular/router';
import { NotificationService } from '@progress/kendo-angular-notification';
import { user_roles } from '../../core/const/constants';
import { ReferenceField } from '../../core/model/reference-fields.interface';
import { DialogService } from '@progress/kendo-angular-dialog';
import { CreateTagModalDialogComponent } from './create-tag/create-tag-modal-dialog.component';
import { dateFormatter } from '../../core/utils/utils';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-tags',
  templateUrl: './tags.component.html',
  styleUrl: './tags.component.scss',
})
export class TagsComponent implements OnInit {
  @ViewChild('tags') tags!: any;

  @Input() public portfolio!: Portfolio;
  @Input() public referenceFields!: ReferenceField[];
  @Input() public onTagsChange!: (
    tagIds: PortfolioTagId[]
  ) => Observable<Portfolio>;
  @Input() public onTagChanged!: () => Promise<ReferenceField[]>;
  @Input() public tagsAdGroups!: Array<any>;
  public referenceFieldsDictionary: Record<string, any[]> = {};

  selectedValue?: any;
  public moreVerticalIcon: SVGIcon = moreVerticalIcon;
  public TagId?: number;
  public referenceObject!: Array<any>;
  public userRoles?: any;
  public role = user_roles;

  public menuSettings: ColumnMenuSettings = {
    lock: true,
    stick: true,
    setColumnPosition: { expanded: true },
    autoSizeColumn: true,
    autoSizeAllColumns: true,
  };

  public tagsList: Array<{
    text: string;
    value: number;
    tagData: any;
    tagDescription: string;
    ADGroupName: string;
    tagStatus: boolean;
  }> = [];

  public DropDowntagsList: any[] = [];
  originalTagsList: any[] = [];

  public gridData: any[] = [];

  isTagUpdated: boolean = false;
  public allReferenceTags: unknown[] = [];
  public portfolioViewTags: unknown[] = [];
  public existingPortTags: unknown[] = [];
  public portfolioId: number = 0;
  public dateFormatter = dateFormatter;

  constructor(
    private _sharedService: SharedService,
    private _http: HttpService,
    private router: Router,
    private dialogService: DialogService,
    private notificationService: NotificationService
  ) {}

  handleFilter(value: any) {
    this.DropDowntagsList = this.originalTagsList.filter((s) =>
      s.Name.toLowerCase().includes(value.toLowerCase())
    );
  }

  ngOnInit(): void {
    this.portfolioId = this.portfolio?.Id ?? 0;
    this._sharedService.getUserRole.subscribe(
      (data) => (this.userRoles = data)
    );

    this.getReferencePortData();
  }

  getReferencePortData(): void {
    const tags = this.referenceFields.find(
      (ele) => ele.FieldName == 'PortfolioTags'
    );
    this.allReferenceTags = tags?.Options ?? [];

    this.DropDowntagsList = [...this.allReferenceTags];
    this.originalTagsList = [...this.allReferenceTags];

    if (
      this.portfolio.PortfolioTagIds &&
      this.portfolio.PortfolioTagIds?.length !== 0
    ) {
      this.existingPortTags = JSON.parse(
        JSON.stringify(this.portfolio?.PortfolioTagIds)
      );

      this.portfolioViewTags = this.getPortfolioTagsToView(
        this.existingPortTags,
        this.allReferenceTags
      );

      this.gridData = this.portfolioViewTags.filter((ele: any) => {
        if (ele.Status == true) return ele;
      });
      this.DropDowntagsList = this.DropDowntagsList.filter((tag) => {
        return this.gridData.findIndex((ele) => tag.Id == ele.Id) == -1;
      });
      this.originalTagsList = this.originalTagsList.filter((tag) => {
        return this.gridData.findIndex((ele) => tag.Id == ele.Id) == -1;
      });
    }
  }

  getPortfolioTagsToView(existingPortTags: any, allReferenceTags: any): any {
    const updatedPortTags: any[] = [];
    existingPortTags.forEach((el: any) => {
      const a = allReferenceTags.filter((e: any, i: any, a: any) => {
        if (e.Id == el.PortfolioTagId) {
          e.Status = el.Status;
        }
        return e.Id == el.PortfolioTagId;
      });
      updatedPortTags.push(a[0]);
    });

    return updatedPortTags;
  }

  onAssetClassChange(assetClassName: any) {
    const selectedTag = [
      {
        PortfolioTagId: assetClassName.Id,
        Status: true,
      },
    ];

    let item = this.portfolio.PortfolioTagIds?.findIndex(
      (tag) => tag.PortfolioTagId == assetClassName.Id
    );
    let tagIds = this.portfolio.PortfolioTagIds;
    if (tagIds && item != undefined && item != -1) {
      tagIds[item].Status = true;
    } else {
      tagIds = [...tagIds!, ...selectedTag];
    }

    this.changePortfolioTags(tagIds);
  }

  navigateTo(dataItem: any) {
    this._sharedService.pushTag.next(dataItem);
    this.router.navigate(['portfolio']);
  }

  createPortfolioTag() {
    const createDialog = this.dialogService.open({
      title: 'Create Portfolio Tag',
      content: CreateTagModalDialogComponent,
      width: 600,
      minHeight: 360,
    });

    const createDialogComponent = createDialog.content
      .instance as CreateTagModalDialogComponent;
    createDialogComponent.title = 'Create';
    createDialogComponent.adGroup = this.tagsAdGroups;
    createDialogComponent.portfolioDetails = this.portfolio;
    createDialogComponent.submitButtonText = 'Create Tag';

    createDialog.result.subscribe((result: any) => {
      if (result.text == 'Submit') {
        let obj: any = {
          Status: true,
          Name: createDialogComponent.registerTagForm.controls['Name'].value,
          ADGroupName:
            createDialogComponent.registerTagForm.controls['ADGroupName'].value,
          PortfolioTagDescription:
            createDialogComponent.registerTagForm.controls[
              'PortfolioTagDescription'
            ].value,
          isAddTagToPortfolio:
            createDialogComponent.registerTagForm.controls['passRefrence']
              .value,
        };

        this.createTag(obj);
      }
    });
  }

  onSelect(e: any, val: any): void {
    let selectedRow = val;
    selectedRow.portfolioName = this.portfolio.PortfolioName;

    if (e.item.text == 'Edit') {
      this.onEditTag(selectedRow);
    }

    if (e.item.text == 'Remove') {
      this.onRemoveTag(selectedRow);
    }
  }

  private onEditTag(selectedRow: any) {
    const editDialog = this.dialogService.open({
      title: 'Edit Portfolio Tag',
      content: CreateTagModalDialogComponent,
      width: 600,
      height: 330,
    });

    const editDialogComponent = editDialog.content
      .instance as CreateTagModalDialogComponent;
    editDialogComponent.title = 'Edit';
    editDialogComponent.sendObjectforEdit = selectedRow;
    editDialogComponent.adGroup = this.tagsAdGroups;
    editDialogComponent.portfolioDetails = this.portfolio;

    editDialog.result.subscribe((result: any) => {
      if (result.text == 'Submit') {
        let obj: any = {
          Name: editDialogComponent.registerTagForm.controls['Name'].value,
          Id: editDialogComponent.sendObjectforEdit.Id,
          ADGroupName:
            editDialogComponent.registerTagForm.controls['ADGroupName'].value,
          PortfolioTagDescription:
            editDialogComponent.registerTagForm.controls[
              'PortfolioTagDescription'
            ].value,
        };

        this.editTag(obj);
      }
    });
  }

  private onRemoveTag(selectedRow: any) {
    const removeDialog = this.dialogService.open({
      title: 'Remove Tag',
      content: `Confirm to remove "${selectedRow.Name}" from "${selectedRow.portfolioName}".`,
      actions: [{ text: 'Cancel' }, { text: 'Ok', themeColor: 'primary' }],
      minWidth: 330,
      minHeight: 180,
    });

    removeDialog.result.subscribe((result: any) => {
      if (result.text == 'Ok') {
        this.removeTag(selectedRow.Id);
      }
    });
  }

  private removeTag(id: Number) {
    let tagIds = this.portfolio.PortfolioTagIds || [];
    tagIds?.forEach((e: PortfolioTagId) => {
      if (id == e.PortfolioTagId) {
        e.Status = false;
      }
    });

    this.changePortfolioTags(tagIds);
  }

  private createTag(obj: any): void {
    this._http.post(`${CREATE_TAG.createTags()}`, { ...obj }).subscribe({
      next: (x) => {
        this.onTagChanged().then((data) => {
          this.referenceFields = data;
          this.getReferencePortData();

          if (obj.isAddTagToPortfolio) {
            this.addTagToPortfolio(x.Id);
          }
        });
      },
    });
  }

  private editTag(obj: any): void {
    this._http.put(`${EDIT_TAG.createTags(obj.Id)}`, { ...obj }).subscribe({
      next: (tag) => {
        this.onTagChanged().then((data) => {
          this.referenceFields = data;
          const index = this.portfolio.PortfolioTags!.findIndex((x) => {
            x.Id == obj.Id;
          });

          this.portfolio.PortfolioTags![index!] = tag;
          this.getReferencePortData();
          this.notificationService.show({
            content: 'Portfolio Tag updated successfully!',
            cssClass: 'button-notification',
            animation: { type: 'slide', duration: 100 },
            position: { horizontal: 'center', vertical: 'top' },
            type: { style: 'success', icon: true },
            hideAfter: 5000,
          });
        });
      },
    });
  }

  private addTagToPortfolio(tagId: number): void {
    let tagIds = this.portfolio.PortfolioTagIds || [];
    if (!tagIds.some((x) => x.PortfolioTagId == tagId)) {
      tagIds.push({
        PortfolioTagId: tagId,
        Status: true,
      });
    }

    this.changePortfolioTags(tagIds);
  }

  private changePortfolioTags(tagIds: PortfolioTagId[]) {
    this.onTagsChange(tagIds).subscribe((portfolio) => {
      this.portfolio = portfolio;
      this.getReferencePortData();
      this.tags.reset();

      this.notificationService.show({
        content: 'Portfolio Tags updated successfully!',
        cssClass: 'button-notification',
        animation: { type: 'slide', duration: 100 },
        position: { horizontal: 'center', vertical: 'top' },
        type: { style: 'success', icon: true },
        hideAfter: 5000,
      });
    });
  }
}
