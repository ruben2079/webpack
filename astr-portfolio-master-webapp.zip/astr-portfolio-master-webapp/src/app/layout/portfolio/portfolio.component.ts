import {
  Component,
  ElementRef,
  HostListener,
  OnInit,
  ViewChild,
} from '@angular/core';
import { HttpService } from '../../core/services/http.service';
import {
  PM_API,
  REFERENCE_DATA_BENCHMARK_URL,
  REFERENCE_DATA_XREFERENCES_URL,
  REFERENCE_DATA_URL,
  SETTINGS_URL,
} from '../../core/const/api.const';
import { SharedService } from '../../core/services/shared.service';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import { FabAlign } from '@progress/kendo-angular-buttons';
import { FormGroup, FormControl } from '@angular/forms';
import {
  EXCLUDE_FIELDS,
  DEFAULT_PM_GRID_DEF,
  DEFAULT_VIEW_MODE,
  Default_Filters,
  default_gridDef,
  exclude_filed,
  max_pageSize,
  portfolio_date_datafields,
  reference_data_fields_pair,
  status_options,
  user_roles,
  API_FIELDS,
} from '../../core/const/constants';
import _ from 'lodash';
import {
  checkRequiredFields,
  dateFormatter,
  genenteGridData,
  getDataFieldTitle,
  getDateStringforSaving,
  getNextStatus,
  getPortfolioManagerTeamOptions,
  getReferenceOptions,
  getRequiredFieldsBasedonStatus,
  getStatusClass,
  getStatusOptions,
  getSubOptions,
  processFilters,
  processReference,
  processReferenceObject,
} from '../../core/utils/utils';
import {
  SVGIcon,
  moreVerticalIcon,
  menuIcon,
  caretAltDownIcon,
  searchIcon,
  fileExcelIcon,
  rotateIcon,
  chevronDoubleDownIcon,
  chevronDoubleUpIcon,
  saveIcon,
} from '@progress/kendo-svg-icons';
import { DrawerItem } from '@progress/kendo-angular-layout';
import { process, State } from '@progress/kendo-data-query';
import { Router } from '@angular/router';
import {
  DataStateChangeEvent,
  GroupKey,
  GridDataResult,
  GridComponent,
  MultipleSortSettings,
} from '@progress/kendo-angular-grid';
import { NotificationService } from '@progress/kendo-angular-notification';

@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.component.html',
  styleUrl: './portfolio.component.scss',
})
export class PortfolioComponent implements OnInit {
  @ViewChild('clickedExport') clickedExport!: ElementRef<any>;
  @ViewChild('refrenceTo') refrenceTo!: ElementRef<any>;
  @ViewChild('grid') grid!: GridComponent;
  gridData: any[] = [];
  public metaData: any = [];
  public exportToExcelData: any = [];
  public label: boolean = false;
  public closedCheckbox?: boolean;
  public closedCheckboxExt?: boolean;
  public savedSettingsData: any;
  public date = new Date();
  public filename: any =
    'Portfolio_Master_' + this.date.toISOString() + '.xlsx';
  public columnData: any;
  public columns: any;
  public columnsReset: any;
  public canUpdatePortfolio: boolean = false;
  public moreVerticalIcon: SVGIcon = moreVerticalIcon;
  public menuIcon: SVGIcon = menuIcon;
  public caretAltDownIcon: SVGIcon = caretAltDownIcon;
  public searchIcon: SVGIcon = searchIcon;
  public rotateIcon: SVGIcon = rotateIcon;
  public saveIcon: SVGIcon = saveIcon;
  public userSettingColumns: any;
  public masterFilters: any = [];
  public selectedFilters: any = [];
  public dateFormatter = dateFormatter;
  public checkboxFilter = [...Default_Filters];
  public tagData: any = [];
  public menuText: string = 'Change status to ';
  // public subText: string = 'Active';
  public itemsList: Array<{ text: string; value: number }> = [];
  public itemdata!: Array<{ text: string; value: number }>;
  public selectedValue!: any;

  public dataState: any = {
    ...DEFAULT_PM_GRID_DEF,
    pageable: {
      ...DEFAULT_PM_GRID_DEF.pageable,
    },
  };

  public sizes: any = [
    50,
    100,
    500,
    (this.gridData || []).length <= max_pageSize ? 'All' : max_pageSize,
  ];

  public defgridDef: any = this.dataState || default_gridDef;
  public state: State = {
    take: this.defgridDef.pageSize,
    skip: 0,
    group: this.defgridDef.groupConfig || [],
    sort: this.defgridDef.initialSort || [],
    filter: {
      logic: 'and',
      filters: [],
    },
  };

  public sortSettings: MultipleSortSettings = {
    mode: 'multiple',
    allowUnsort: true,
    showIndexes: true,
  };

  public items: Array<DrawerItem> = [];
  public data: string[] = ['Active', 'Close', 'In Progress', 'Operation Ready'];
  public expanded = false;
  public masterSelected: any = { field: 'PortfolioTags', value: null };
  public ExcelNameDate = new Date();
  public isDateExpand = false;
  public getStatusClass = getStatusClass;
  public getNextStatus = getNextStatus;

  public switchExpanded(): void {
    this.expanded = !this.expanded;
  }
  public expandedGroupKeys: GroupKey[] = this.defgridDef.groupConfig || [];

  public expandAll(val: boolean): void {
    this.label = val;
    if (this.label) {
      this.expandedGroupKeys = [];
      this.groupExpanded = false;
    } else {
      this.expandedGroupKeys = [];
      this.groupExpanded = true;
    }
  }

  public collapseAll(): void {}

  public show = false;
  public textValue: any = '';
  public opened = false;
  public isStatusChange = false;
  public pageSize = 50;
  public resetColumnDataVal: any;
  public buttonCount = 4;
  public cloneObject: any;
  public userSettings: any;
  public referenceList: any;
  public referenceObjects: any;
  public changeStatusObject: any;
  public statusChangeTo: string = '';
  public isCreate: boolean = false;
  public isClone: boolean = false;
  public isTagToHome: any = null;
  public userRoles?: any;
  public role = user_roles;
  public groupExpanded = true;

  public middleEnd: FabAlign = { vertical: 'middle', horizontal: 'end' };
  //public opened = false;
  public defaultItem = 'Select data field';
  public fileExcelIcon: SVGIcon = fileExcelIcon;
  public chevronDoubleDownIcon: SVGIcon = chevronDoubleDownIcon;
  public chevronDoubleUpIcon: SVGIcon = chevronDoubleUpIcon;

  constructor(
    private _http: HttpService,
    private _sharedService: SharedService,
    private router: Router,
    private notificationService: NotificationService
  ) {
    this.allData = this.allData.bind(this);
  }

  public allData(): ExcelExportData {
    const result: ExcelExportData = {
      data: process(this.exportToExcelData, {
        group: this.defgridDef.groupConfig || [],
        take: this.exportToExcelData.length,
        filter: this.state.filter,
      }).data,
      group: this.defgridDef.groupConfig || [],
    };

    if (result.data?.length == 0) {
      result.data = this.exportToExcelData;
    }

    return result;
  }

  ngOnInit(): void {
    this.opened = false;
    this._sharedService.getTag.subscribe((obj) => {
      if (typeof obj !== 'undefined' && obj != null) {
        this.isTagToHome = { key: 'Tags', value: obj?.Name };
      }
    });
    this._sharedService.callEntitlements(() => {
      this._sharedService.getUserRole.subscribe(
        (data) => (this.userRoles = data)
      );
      this._http.get(SETTINGS_URL.getSettings()).subscribe({
        next: (res) => {
          this.userSettingColumns = !!res?.colDefs
            ? res?.colDefs.filter(
                (col: any) => !EXCLUDE_FIELDS.includes(col.field)
              )
            : null;
          this.callReferencedata(() => {
            this.callPortfolioData();
          });
        },
      });
    });
  }

  public statusChange(item: any) {
    return getNextStatus(item)[0];
  }

  isTagToHomeCallBack(isTag: any) {
    if (typeof isTag !== 'undefined' && isTag != null) {
      this.closedCheckboxExt = true;
      this.closedCheckbox = true;
      this.checkboxFilter = [];
      this.selectedValue = this.itemsList.find(
        (item) => item.text === isTag.key
      );
      let filterData =
        this.columns?.find((d: any) => d.title == isTag.key) || [];
      this.masterSelected = filterData;
      this.onFilterClicked([isTag.value], 'PortfolioTags');
      this.onFilterSubmit();
    }
  }

  callReferencedata(cb: any) {
    this._http
      .get(REFERENCE_DATA_BENCHMARK_URL.getreferencedata())
      .subscribe((data) => {
        let referenceObj: any = { ...this.referenceObjects };
        referenceObj = {
          ...referenceObj,
          ...(data?.length > 0 && { PortfolioBenchmarks: data }),
        };
        this.referenceObjects = processReferenceObject(referenceObj);
        this._http
          .get(REFERENCE_DATA_XREFERENCES_URL.getreferencedata())
          .subscribe((data) => {
            let modifyData = {
              ...referenceObj,
              ...(data?.length > 0 && {
                PortfolioXReferences: data,
              }),
            };
            this.referenceObjects = processReferenceObject(modifyData);
            this._http
              .get(REFERENCE_DATA_URL.getreferencedata())
              .subscribe((references) => {
                let referencedata: any = { ...this.referenceList };
                let modifyData =
                  references?.length > 0
                    ? {
                        ...referencedata,
                        all: [
                          ..._.unionBy(
                            references,
                            referencedata.all || [],
                            'FieldToUpdate'
                          ),
                          ...(this.tagData || []),
                        ],
                      }
                    : referencedata;

                this.referenceList = processReference(modifyData);
                this.filterResults();
                this._sharedService.referenceData.next(references);
                cb && cb();
              });
          });
      });
  }

  callPortfolioData() {
    this._http.get(PM_API.getportfolios()).subscribe({
      next: (res) => {
        this.metaData = res;
        let genData = genenteGridData(
          res,
          this.referenceList,
          this.referenceObjects
        );
        this.gridData = [...genData];
        this.getData(this.state);
        this.isTagToHomeCallBack(this.isTagToHome);
      },
    });
  }

  public exportToExcel(): void {
    this.clickedExport.nativeElement.click();
  }

  public gridViewData: GridDataResult = { data: [], total: 0 };

  public getData(state: State, isInit = false): void {
    const filterColumnData = processFilters(
      this.gridData,
      isInit
        ? Default_Filters
        : !!this.masterFilters.length
        ? this.masterFilters
        : this.checkboxFilter
    );
    this.exportToExcelData = filterColumnData;
    this.gridViewData = process(filterColumnData || [], state);
  }

  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.getData(this.state);
  }

  filterResults() {
    let existed_fields: any = [];

    const filter_dataFields = _.chain(API_FIELDS)

      .sortBy()
      .xor(existed_fields)
      .map((field: any) => ({
        id: field,
        text: getDataFieldTitle(field),
      }))
      .value();

    let mainColumn = this.filterColumns();
    this.columns = [...mainColumn];
    this.savedSettingsData = [...mainColumn];
    this.columns.push({ field: '', title: '' });
    this.columnsReset = [...this.columns];
    this.items = [...this.menuColumns(mainColumn)];
    this.resetColumnDataVal = [...this.menuColumns(mainColumn)];
    let value = 1;
    for (let i = 0; i < this.items.length; i++) {
      let itemName: any = this.items[i].text;
      this.itemsList.push({ text: itemName, value: value });
      value++;
    }
    this.itemdata = this.itemsList.slice();
    this.selectedColumns(this.items);
  }

  selectedColumns(col: any) {
    let interval: any;
    const hiddenColumns = this.hiddenColumns;
    !!col?.length &&
      col.forEach((item: any, index: any) => {
        if (!item.selected) {
          hiddenColumns.push(item);
        }
      });

    if (interval) {
      clearInterval(interval);
    }
    interval = setTimeout(() => {
      this.activeColumns(col);
    }, 100);
  }

  public onSelectionChange(selection: any) {
    this.isTagToHome = false;
    this.textValue = '';
    this.masterSelected = {};
    this.selectedFilters = [];
    setTimeout(() => {
      let filterData =
        this.columns?.find((d: any) => d.title == selection.text) || [];
      this.selectedValue = selection;
      this.masterSelected = { ...filterData };
    }, 100);
  }

  handleFilter(value: any) {
    this.itemsList = this.itemdata.filter(
      (s) => s.text.toLowerCase().indexOf(value.toLowerCase()) !== -1
    );
  }

  resetColumns() {
    this.hiddenColumns = [];
    this.selectedColumns(this.resetColumnDataVal);
  }

  activeColumns(col: any) {
    let element: any = document.querySelectorAll(
      '.custom-drawer .k-drawer-items li'
    );
    !!col?.length &&
      col.forEach((item: any, index: any) => {
        if (item.selected) {
          element[index]?.classList.add('ct-selected');
        } else {
          element[index]?.classList.remove('ct-selected');
        }
      });
  }

  public onSelect(e: any, val: any): void {
    const selectedRow = { ...val };

    if (e.item.text == 'Clone') {
      this._sharedService.isOpened = true;
      this.opened = this._sharedService.isOpened;
      this.cloneObject = selectedRow;
      this.isClone = true;
      this.isCreate = false;
    }

    if (e.item.text == null && e.item.children.length == 0) {
      this.isStatusChange = true;
      this.changeStatusObject = selectedRow;
    }

    if (e.item.text == 'Edit') {
      this.changeStatusObject = selectedRow;
      this._sharedService.updateCurrentPortfolio(selectedRow, 'edit');
      const code = selectedRow.PortfolioCode;
      this.router.navigate(['/portfolio/details'], {
        queryParams: { portfolio: code },
      });
    }
    if (e.item.text == 'Reactivate') {
      this.isStatusChange = true;
      this.changeStatusObject = selectedRow;
    }
  }
  public hiddenColumns: Array<any> = [];

  public isHidden(columnName: string): boolean {
    return (
      this.hiddenColumns.findIndex((column) => column.field == columnName) > -1
    );
  }

  public hideColumn(columnName: any): void {
    const hiddenColumns = this.hiddenColumns;
    const columnIndex = this.hiddenColumns.findIndex(
      (column) => column.field == columnName.field
    );
    if (columnIndex === -1) {
      hiddenColumns.push(columnName);
    } else {
      hiddenColumns.splice(columnIndex, 1);
    }
  }

  public onSelectColumn(e: any): void {
    let item = this.items;
    let element: any = document.querySelectorAll(
      '.custom-drawer .k-drawer-items li'
    );
    if (element[e?.index]?.classList.contains('ct-selected')) {
      element[e?.index]?.classList.remove('ct-selected');
      item[e?.index].selected = false;
    } else {
      element[e?.index]?.classList.add('ct-selected');
      item[e?.index].selected = true;
    }

    this.hideColumn(e.item);
  }

  savedColumns() {
    let data =
      this.savedSettingsData?.map((item: any) => {
        let isHide = this.items.find((d: any) => d.field == item.field);
        return { ...item, hide: isHide?.selected == false ? true : false };
      }) || [];

    let orderedData: any = _.compact(
      _.orderBy(this.grid.columns.toArray(), ['orderIndex'], ['asc']).map(
        (column: any) => data.find((item: any) => item.field === column.field)
      )
    );

    orderedData = orderedData.concat(
      data.filter(
        (column: any) =>
          !orderedData.find((item: any) => item.field === column.field)
      )
    );

    let payload: Object = {
      colDefs: orderedData,
    };

    this._http.put(SETTINGS_URL.getSettings(), payload).subscribe({
      next: (res) => {
        this.userSettingColumns = res.colDefs;
        this.filterResults();
        this.notificationService.show({
          content: 'User settings updated successfully!',
          cssClass: 'button-notification',
          animation: { type: 'slide', duration: 100 },
          position: { horizontal: 'center', vertical: 'top' },
          type: { style: 'success', icon: true },
          hideAfter: 5000,
        });
      },
    });
  }

  public filterColumns() {
    const allDataCols = (API_FIELDS || []).map((field) => ({
      field,
      width: '150px',
      hide: true,
    }));
    // let viewMode = Object.keys(DEFAULT_VIEW_MODE)[1]
    const allCols = _.unionBy(
      this.userSettingColumns || DEFAULT_VIEW_MODE.detailed.columnDefs,
      allDataCols,
      'field'
    );

    const cols = allCols.map((col) => {
      let referenceId = col.field;
      let newCol: any = {
        ...col,
        title: getDataFieldTitle(referenceId),
      };

      let { referenceItem } = getReferenceOptions(
        referenceId,
        this.referenceList,
        this.referenceObjects
      );

      if (
        !!referenceItem &&
        Object.keys(reference_data_fields_pair).includes(referenceId)
      ) {
        referenceItem = getSubOptions('all', referenceItem);
      }
      if (referenceId === 'PortfolioManagerTeamName') {
        referenceItem = getPortfolioManagerTeamOptions(referenceItem);
      }

      !!referenceItem &&
        referenceId !== 'Status' &&
        (newCol = {
          ...newCol,
          filter: 'text',
          filter_type: 'list',
          filter_options: _.sortBy(Object.values(referenceItem)) || [],
        });

      portfolio_date_datafields.includes(referenceId) &&
        (newCol = {
          ...newCol,
          filter: 'date',
        });

      referenceId == 'Status' &&
        (newCol = {
          ...newCol,
          filter: 'text',
          filter_type: 'list',
          filter_options: _.sortBy(getStatusOptions()) || [],
        });

      return newCol;
    });

    return cols;
  }

  public menuColumns(gridColumnDefs: any) {
    const allDrawerCol: any = [];
    let gridDef = default_gridDef;
    // const gridColumnDefs = this.filterColumns();

    !!gridColumnDefs.length &&
      gridColumnDefs.forEach((colProps: any, index: any) => {
        let newCol = {
          ...colProps,
          reorderable: !colProps.locked,
          colindex: index,
        };

        // if (!!gridDef.hideColumn) {
        !!newCol.title &&
          !exclude_filed.includes(newCol.field) &&
          allDrawerCol.push({
            text: newCol.title,
            selected: !colProps.hide,
            field: newCol.field,
          });
        // }
      });
    return _.sortBy(allDrawerCol, 'text');
  }

  navigateTo(dataItem: any, isParent = false): void {
    this._sharedService.updateCurrentPortfolio(dataItem, 'dashboard-link');
    const code = isParent
      ? dataItem.ParentPortfolioCode
      : dataItem.PortfolioCode;
    this.router.navigate(['/portfolio/details'], {
      queryParams: { portfolio: code },
    });
  }

  handleListFilterChange = (selected: any, field: any) => {
    let newState: any = { ...this.state };
    const { filter = { filters: [] } } = newState;
    const newfilter: any = !!selected.length
      ? [
          {
            logic: 'or',
            filters: (selected || []).map((item: any) => ({
              field,
              operator: 'contains',
              value: item,
            })),
          },
        ]
      : [];
    newState = {
      ...newState,
      skip: 0,
      filter: {
        ...filter,
        filters: _.concat(
          !!filter && !!filter.filters
            ? filter.filters.filter(
                (item: any) =>
                  (!!item.filters ? item.filters[0].field : item.field) !==
                  field
              )
            : [],
          newfilter
        ),
        logic: 'and',
      },
    };
    !newState.filter.filters.length &&
      (newState = {
        ...newState,
        filter: null,
      });
    this.state = newState;
    this.getData(newState);
  };

  toggleButton(event: any) {
    if (event.target.checked) {
      const filterData =
        this.checkboxFilter?.filter((d) => d?.key != 'Status_check') || [];
      this.checkboxFilter = filterData;
      this.closedCheckbox = true;
    } else {
      this.closedCheckbox = false;
      this.checkboxFilter.push(Default_Filters[0]);
    }

    this.masterFilters = [
      ...this.checkboxFilter,
      ...this.masterFilters.filter((item: any) => !item.key.includes('_check')),
    ];
    this.getData(this.state);
  }

  toggleButtonexternal(event: any) {
    if (event.target.checked) {
      const filterData =
        this.checkboxFilter?.filter(
          (d) => d?.key != 'LegalInvestmentManagerName_check'
        ) || [];
      this.checkboxFilter = filterData;
      this.closedCheckboxExt = true;
    } else {
      this.closedCheckboxExt = false;
      this.checkboxFilter.push(Default_Filters[1]);
    }
    this.masterFilters = [
      ...this.checkboxFilter,
      ...this.masterFilters.filter((item: any) => !item.key.includes('_check')),
    ];
    this.getData(this.state);
  }
  handleDateFilterChange = (dates: any, field: any) => {
    const { min, max } = dates;
    const filters = [];
    let newState: any = { ...this.state };
    const { filter = { filters: [] } } = newState;
    if (!!min) {
      filters.push({
        field: field,
        operator: 'gte',
        value: getDateStringforSaving(min),
      });
    }
    if (!!max) {
      filters.push({
        field: field,
        operator: 'lte',
        value: getDateStringforSaving(max),
      });
    }
    newState = {
      ...newState,
      skip: 0,
      filter: {
        ...filter,
        filters: _.concat(
          filters,
          !!filter && !!filter.filters
            ? filter.filters.filter((item: any) => item.field !== field)
            : []
        ),
        logic: 'and',
      },
    };
    this.state = newState;
    this.getData(newState);
  };

  recieveMessageFromChangeStatusModal($event: any) {
    this.isStatusChange = $event;
    this.callPortfolioData();
  }

  public registerForm: FormGroup = new FormGroup({
    code: new FormControl(),
    name: new FormControl(),
    vehicleType: new FormControl(),
  });

  openPortFolio() {
    this.isCreate = true;
    this.isClone = false;
    this.opened = true;
  }

  onFilterSubmit() {
    this.masterFilters = [...this.selectedFilters];
    this.getData(this.state);
  }

  onFilterReset(reset?: any) {
    if (reset) {
      let interval: any;
      this.columns = [];
      this.masterSelected = {};
      this.closedCheckbox = false;
      this.closedCheckboxExt = false;
      this.state.filter = {
        logic: 'and',
        filters: [],
      };
      if (interval) {
        clearInterval(interval);
      }
      interval = setTimeout(() => {
        this.columns = [...this.columnsReset];
      }, 50);
      this._sharedService.pushTag.next(null);
    }
    this.masterSelected = {};
    this.textValue = '';
    this.selectedValue = { text: 'Select data field', value: null };
    this.masterFilters = [];
    this.selectedFilters = [];
    this.isTagToHome = false;
    this.getData(this.state, reset);
  }

  onValueChange(val: any) {
    if (this.masterSelected?.field) {
      this.textValue = val;
      this.onFilterClicked(this.textValue, this.masterSelected?.field);
    }

    if (val == '') {
      this.selectedFilters = [];
    }
  }

  onFilterClicked(filterValue: any, filterId: any) {
    let newFilters: any = [...this.checkboxFilter];
    newFilters.push({
      key: filterId,
      value: filterValue,
      isExclude: false,
    });
    if (
      !!filterId &&
      (!!filterValue?.length || !!filterValue.max || !!filterValue.min)
    ) {
      this.selectedFilters = newFilters;
    } else {
      this.selectedFilters = [];
    }
  }

  recieveMessageFromModal($event: any) {
    this.opened = $event;
  }

  validationStatusChange(dataItem: any) {
    const nextStatus = getNextStatus(dataItem.Status)[0];

    let requiredFields = !!this.referenceObjects
      ? getRequiredFieldsBasedonStatus(
          {
            ...dataItem,
            Status: nextStatus,
          },
          false,
          this.referenceObjects
        )
      : [];

    nextStatus === status_options.Closed &&
      (requiredFields = _.without(requiredFields, 'LiquidationDate'));

    return (
      this.userRoles == this.role.approver &&
      dataItem.Status != 'Closed' &&
      !checkRequiredFields(dataItem, requiredFields).isFailed
    );
  }

  checkFilterBtnEnable() {
    return this.selectedFilters?.length > 0;
  }

  getChangeStatusObject() {
    return {
      ...this.metaData.find(
        (item: any) => this.changeStatusObject.Id === item.Id
      ),
      Status: this.changeStatusObject.Status,
    };
  }

  @HostListener('document:click', ['$event'])
  private documentClick(event: any): void {
    if (!this.contains(event.target) && !!this.expanded) {
      this.switchExpanded();
    }
  }

  private contains(target: any): boolean {
    return document.getElementsByClassName('styled_drawer')[0].contains(target);
  }
}
