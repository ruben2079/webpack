import { Component } from '@angular/core';
import { APP_DETAILS } from '../../core/const/constants';

@Component({
  selector: 'app-user-not-allowed',
  templateUrl: './user-not-allowed.component.html',
  styleUrl: './user-not-allowed.component.scss',
})
export class UserNotAllowedComponent {
  public appName = APP_DETAILS.AppName;
  public appUrl = '/';
  public helpDeskEmail = APP_DETAILS.HelpDeskEmail;
}
