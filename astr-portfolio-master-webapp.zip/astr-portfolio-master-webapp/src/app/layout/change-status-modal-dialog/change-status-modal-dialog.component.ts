import { Component, EventEmitter, Input, Output } from '@angular/core';
import { arrowRightIcon, SVGIcon } from '@progress/kendo-svg-icons';
import { SharedService } from '../../core/services/shared.service';
import { HttpService } from '../../core/services/http.service';
import { CHANGE_STATUS_URL } from '../../core/const/api.const';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import {
  convertDateLocalfromUTC,
  getDateStringforSaving,
} from '../../core/utils/utils';
import { status_options } from '../../core/const/constants';

@Component({
  selector: 'app-change-status-modal-dialog',
  templateUrl: './change-status-modal-dialog.component.html',
  styleUrl: './change-status-modal-dialog.component.scss',
})
export class ChangeStatusModalDialogComponent {
  @Input('changeStatusObject') changeStatusObject: any;
  @Input()
  public changeStatusOpened: boolean = false;
  @Output()
  public onModalChangeStatusEventChange = new EventEmitter<boolean>();
  public opened: boolean = true;
  public arrowRightIcon: SVGIcon = arrowRightIcon;
  public inceptionDate!: any;
  public liquidationDate!: any;
  public isSubmitted = false;
  public showLiquidation: boolean = false;
  public showStatusDropdown: boolean = false;
  public status: any = '';
  public changedStatus: any;
  changeStatusList = ['In Progress'];

  constructor(
    private _http: HttpService,
    private formBuilder: FormBuilder,
    private _sharedService: SharedService
  ) {}

  public statusForm: FormGroup = new FormGroup({
    inceptionDate: new FormControl(),
    changedStatus: new FormControl(),
    liquidationDate: new FormControl(),
  });

  ngOnInit(): void {
    this.inceptionDate = convertDateLocalfromUTC(
      this.changeStatusObject.InceptionDate
    );
    if (this.changeStatusObject.Status == status_options.Active) {
      this.showLiquidation = true;
      this.statusForm = this.formBuilder.group({
        liquidationDate: ['', Validators.required],
        inceptionDate: ['', Validators.required],
      });
      this.status = 'Closed';
    } else if (this.changeStatusObject.Status == status_options.Closed) {
      this.showStatusDropdown = true;
      this.changedStatus = 'In Progress';
      this.statusForm = this.formBuilder.group({
        changedStatus: ['In Progress', Validators.required],
        inceptionDate: ['', Validators.required],
      });
      this.status = 'WorkInProgress';
    } else if (
      this.changeStatusObject.Status == status_options.WorkInProgress
    ) {
      this.showLiquidation = false;
      this.showStatusDropdown = false;
      this.statusForm = this.formBuilder.group({
        inceptionDate: ['', Validators.required],
      });
      this.status = 'OperationallyReady';
    } else if (
      this.changeStatusObject.Status == status_options.OperationallyReady
    ) {
      this.showLiquidation = false;
      this.showStatusDropdown = false;
      this.statusForm = this.formBuilder.group({
        inceptionDate: ['', Validators.required],
      });
      this.status = 'Active';
    } else {
      this.showLiquidation = false;
      this.showStatusDropdown = false;
      this.statusForm = this.formBuilder.group({
        changedStatus: [''],
        inceptionDate: ['', Validators.required],
      });
    }
  }

  public close(status: string): void {
    this._sharedService.isChangeStatusOpened = false;
    this.changeStatusOpened = false;
    this.onModalChangeStatusEventChange.emit(this.changeStatusOpened);
  }

  onSubmit(): void {
    this.isSubmitted = true;
    if (this.statusForm.invalid) {
      return;
    } else {
      this.changeStatusOpened = false;
      if (this.status == status_options.Closed) {
        this.changeStatusObject.LiquidationDate = getDateStringforSaving(
          this.liquidationDate.toLocaleDateString('en-CA')
        );
      }

      let newObj: any = {
        Id: this.changeStatusObject.Id,
        InceptionDate: getDateStringforSaving(
          this.inceptionDate.toLocaleDateString('en-CA')
        ),
        Status: this.status,
      };
      this.changeStatusObject = { ...this.changeStatusObject, ...newObj };

      this._http
        .put(
          `${CHANGE_STATUS_URL.changePortfolioStatus()}/${
            this.changeStatusObject.Id
          }`,
          { ...this.changeStatusObject }
        )
        .subscribe((x) => {
          this.onModalChangeStatusEventChange.emit(this.changeStatusOpened);
        });
    }
  }
}
