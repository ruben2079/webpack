import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PortfolioDetailsContentComponent } from './portfolio-details-content.component';

describe('PortfolioDetailsContentComponent', () => {
  let component: PortfolioDetailsContentComponent;
  let fixture: ComponentFixture<PortfolioDetailsContentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PortfolioDetailsContentComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PortfolioDetailsContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
