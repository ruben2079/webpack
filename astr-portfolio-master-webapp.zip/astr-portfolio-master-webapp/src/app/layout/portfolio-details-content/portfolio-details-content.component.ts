import {
  Component,
  OnInit,
  ViewEncapsulation,
  Input,
  Output,
  EventEmitter,
} from '@angular/core';
import * as constants from '../../core/const/constants';
import { SharedService } from '../../core/services/shared.service';
import {
  Portfolio,
  PortfolioStatus,
  PortfolioTagId,
  PortfolioType,
} from '../../core/model/portfolios.interface';
import {
  SVGIcon,
  exclamationCircleIcon,
  infoCircleIcon,
  trackChangesRejectIcon,
} from '@progress/kendo-svg-icons';
import {
  DropdownOption,
  ReferenceField,
} from '../../core/model/reference-fields.interface';
import {
  checkRequiredFields,
  createInputMaxLengthHint,
  getDateOffset,
  getRequiredFieldsBasedonStatus,
  getSpecialDisplayText,
  getStatusClass,
} from '../../core/utils/utils';
import { BenchmarkType } from '../../core/const/constants';
import { Observable } from 'rxjs';

@Component({
  selector: 'portfolio-details-content',
  templateUrl: './portfolio-details-content.component.html',
  styleUrl: './portfolio-details-content.component.scss',
  encapsulation: ViewEncapsulation.None,
})
export class PortfolioDetailsContentComponent implements OnInit {
  @Input() public portfolio!: Portfolio;
  @Input() public updatedPortfolio!: Portfolio;
  @Input() public tagsAdGroups!: Array<any>;
  @Input() public onPortfolioTagsChanged!: (
    tagIds: PortfolioTagId[]
  ) => Observable<Portfolio>;
  @Input() public onTagChanged!: () => Promise<ReferenceField[]>;
  @Input() public onDownloadstreamPortfolio!: (apiStr: string) => void;
  @Input() public refreshPortfolio!: () => void;
  @Output() updatedPortfolioChange: EventEmitter<Portfolio> =
    new EventEmitter<Portfolio>();
  @Input() public referenceFields!: ReferenceField[];
  @Input() public editForm: string | null | undefined = null;
  @Output() editFormChange: EventEmitter<string> = new EventEmitter<string>();
  public additionalRequiredFields: string[] = [];
  public referenceFieldsDictionary: Record<string, any[]> = {};
  public benchmarks: Record<number, string> = {};
  public defaultDropdownOption = { text: 'Please select', value: undefined };
  public booleanDropdownOptions = [
    this.defaultDropdownOption,
    { text: 'Yes', value: true },
    { text: 'No', value: false },
  ];
  public datePickerMinValue = new Date('0000-01-01');
  public noAnalyticsBenchmarkId: number | undefined;
  public noPerformanceBenchmarkId: number | undefined;

  @Input() public isValid!: boolean;
  @Output() isValidChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  @Input() isEditing!: boolean;
  @Output() isEditingChange: EventEmitter<boolean> =
    new EventEmitter<boolean>();

  @Input() userRoles: any;
  @Input() activeTab!: string;
  @Output() activeTabChange: EventEmitter<string> = new EventEmitter<string>();

  public items: any = constants.portfolio_menuitems; //getting side menus
  public key: any = constants.portfolio_menuitems.keys;
  public portfolioStatusMapping: any = constants.status_options;

  public dataFields = constants.portfolio_content_datafields;
  public fieldDictionary: Record<string, any> = {};
  public portfolioKeyNameMapping = constants.portfolio_key_name_mapping;

  public exclamationCircleIcon: SVGIcon = exclamationCircleIcon;
  public infoCircleIcon: SVGIcon = infoCircleIcon;
  public trackChangesRejectIcon: SVGIcon = trackChangesRejectIcon;
  public selectObj: any;
  public getStatusClass = getStatusClass;
  public filterOptions: any[] = [];

  handleSelect = (e: any) => {
    if (this.isTabDisabled(e.item)) {
      e.preventDefault();
      return;
    }

    if (e.item.key == 'form') {
      this.refreshPortfolio();
    }

    this.selectObj = e;
    this.activeTab = e.item.key;
    this.activeTabChange.emit(this.activeTab);
  };

  constructor(private _sharedService: SharedService) {}

  ngOnInit(): void {
    this.mapReferenceFields();
    this.flattenDataFields();
  }

  mapReferenceFields() {
    // Create Reference Fields Dictionary.
    this.referenceFields.forEach((ref) => {
      this.referenceFieldsDictionary[ref.FieldToUpdate] = [
        this.defaultDropdownOption,
      ].concat(
        ref.Options.map((opt) => {
          var text;
          var value;
          const fieldName = ref.FieldToUpdate;

          // Options are strings for PortfolioStatus.
          if (typeof opt == 'string') {
            text = this.portfolioStatusMapping[opt];
            value = opt;
          } else {
            if (fieldName.includes('Code')) {
              text = value = opt.Code ?? opt.PortfolioCode;
            } else if (fieldName.includes('Benchmark')) {
              //flexiable updates for attaching benchmark code, will remove this once backend change data format.
              text = opt.Name.includes(' (')
                ? opt.Name
                : getSpecialDisplayText(opt.Name, opt.Code, 'benchmark');
              value = opt.Id;

              if (fieldName.includes('Benchmark')) {
                // Create Benchmarks Dictionary for Form Generation.
                this.benchmarks[value] = text;

                // Save No benchmark ID for validations.
                if (opt.Code === constants.NoBenchmarkCode) {
                  if (opt.Type === BenchmarkType.Analytics) {
                    this.noAnalyticsBenchmarkId = opt.Id;
                  }

                  if (opt.Type === BenchmarkType.Performance) {
                    this.noPerformanceBenchmarkId = opt.Id;
                  }
                }
              }
            } else if (fieldName.includes('Currency')) {
              text = `${opt.Code} - ${opt.Name}`;
              value = opt.Name;
            } else if (fieldName.includes('ClientName')) {
              text = opt.Name.includes(' (')
                ? opt.Name
                : getSpecialDisplayText(
                    opt.Name,
                    opt.LookupSubValue,
                    'benchmark'
                  );
              value = opt.Name ?? opt;
            } else {
              text = value = opt.Name ?? opt;
            }
          }

          return { text, value, opt } as DropdownOption;
        }).sort((a, b) => {
          if (
            a.opt?.Code === constants.NoBenchmarkCode &&
            b.opt?.Code === constants.NoBenchmarkCode
          ) {
            return 0;
          } else if (a.opt?.Code === constants.NoBenchmarkCode) {
            return -1;
          } else if (b.opt?.Code === constants.NoBenchmarkCode) {
            return 1;
          } else {
            return a.text.localeCompare(b.text);
          }
        })
      );
    });

    // Remove ParentPortfolioCode that matches current Portfolio.
    this.referenceFieldsDictionary['ParentPortfolioCode'] =
      this.referenceFieldsDictionary['ParentPortfolioCode'].filter(
        (opt) => opt.value !== this.portfolio.PortfolioCode
      );
  }

  flattenDataFields() {
    // Flatten dataFields.
    Object.entries(this.dataFields).forEach(([_, tab]) => {
      for (var section of tab) {
        for (var [_, field] of Object.entries(section.datafields)) {
          this.fieldDictionary[field.apiField] = field;
        }
      }
    });
  }

  setRequiredValues() {
    // PortfolioCode can only be changed in WorkInProgress: If changing status, reset the PortfolioCode.
    if (this.updatedPortfolio.Status != PortfolioStatus.InProgress) {
      this.updatedPortfolio.PortfolioCode = this.portfolio.PortfolioCode;
    }

    if (
      !this.updatedPortfolio.TransferAgentSystemName ||
      this.updatedPortfolio.TransferAgentSystemName == 'Not Applicable'
    ) {
      this.updatedPortfolio.ShareholderID = undefined;
    }

    if (
      !this.updatedPortfolio.InsuranceAccountingSystemName ||
      this.updatedPortfolio.InsuranceAccountingSystemName != 'BNYM STAR'
    ) {
      this.updatedPortfolio.STARAccountNumber = undefined;
    }

    if (
      !this.updatedPortfolio.ABORSystemName ||
      this.updatedPortfolio.ABORSystemName != 'BNYM InvestOne'
    ) {
      this.updatedPortfolio.InvestOneAccountNumber = undefined;
    }

    if (
      !this.updatedPortfolio.IBORSystemName ||
      this.updatedPortfolio.IBORSystemName != 'BNYM SGA'
    ) {
      this.updatedPortfolio.SGAAccountNumber = undefined;
    }

    if (
      !this.updatedPortfolio.IBORSystemName ||
      this.updatedPortfolio.IBORSystemName != 'BNYM OnCore'
    ) {
      this.updatedPortfolio.OnCoreAccountNumber = undefined;
    }

    if (
      !this.updatedPortfolio.TradingSystemName ||
      this.updatedPortfolio.TradingSystemName != 'Aladdin'
    ) {
      this.updatedPortfolio.BlackrockIdentifier = undefined;
    }

    if (!this.updatedPortfolio.ESGSustainability) {
      this.updatedPortfolio.ESGSustainabilityObjectiveName = undefined;
    }

    if (!this.updatedPortfolio.ESGFlag) {
      this.updatedPortfolio.ESGClientDirectedExclusion = undefined;
      this.updatedPortfolio.ESGFullIntegration = undefined;
      this.updatedPortfolio.ESGSustainability = undefined;
      this.updatedPortfolio.ESGSustainabilityObjectiveName = undefined;
    }

    if (this.updatedPortfolio.FinanceAUMSourceName == 'Do Not Load') {
      this.updatedPortfolio.FinanceBusinessLineName = undefined;
      this.updatedPortfolio.FinanceAUMAmountTypeName = undefined;
    }

    if (
      !this.updatedPortfolio.CustodianBankName ||
      this.updatedPortfolio.CustodianBankName == 'No Custodian Access'
    ) {
      this.updatedPortfolio.CustodianAccountNumber = undefined;
    }

    if (
      !this.updatedPortfolio.PerformanceBookOfRecordName ||
      this.updatedPortfolio.PerformanceBookOfRecordName == 'Not Applicable'
    ) {
      this.updatedPortfolio.PerformanceInceptionDate = undefined;
      this.updatedPortfolio.PerformanceStartDate = undefined;
    }

    if (
      !this.updatedPortfolio.PrimaryBenchmarkId ||
      this.updatedPortfolio.PrimaryBenchmarkId === this.noPerformanceBenchmarkId
    ) {
      this.updatedPortfolio.SecondaryBenchmarkId = undefined;
    }

    if (!this.updatedPortfolio.SecondaryBenchmarkId) {
      this.updatedPortfolio.TertiaryBenchmarkId = undefined;
    }

    if (
      !this.updatedPortfolio.PrimaryAnalyticsBenchmarkId ||
      this.updatedPortfolio.PrimaryAnalyticsBenchmarkId ===
        this.noAnalyticsBenchmarkId
    ) {
      this.updatedPortfolio.SecondaryAnalyticsBenchmarkId = undefined;
    }

    if (this.updatedPortfolio.PortfolioTypeName != PortfolioType.Sleeve) {
      this.updatedPortfolio.ParentPortfolioCode = undefined;
    }

    if (this.updatedPortfolio.Status != PortfolioStatus.Closed) {
      this.updatedPortfolio.LiquidationDate = undefined;
    }
  }

  getPortfolioValueForTextField(datafield: any) {
    var fieldName = datafield.apiField;
    var value = Reflect.get(this.updatedPortfolio, fieldName);

    if (this.isNullOrUndefined(value)) {
      return '';
    }

    if (typeof value === 'boolean') {
      return this.booleanDropdownOptions.find((opt) => {
        return opt.value == value;
      })?.text;
    }

    var fieldName = datafield.apiField;

    if (fieldName.includes('BenchmarkId')) {
      fieldName = 'BenchmarkId';
    }

    if (fieldName in this.referenceFieldsDictionary) {
      let referenceItem = this.referenceFieldsDictionary[fieldName].find(
        (opt) => {
          return opt.value == value;
        }
      );
      return datafield.apiField == 'ClientName'
        ? getSpecialDisplayText(
            referenceItem.opt.Name,
            referenceItem.opt.LookupSubValue,
            'benchmark'
          )
        : referenceItem.text;
    }

    if (datafield.fieldType == 'datepicker') {
      return getDateOffset(value)?.toLocaleDateString();
    }

    return value;
  }

  getPortfolioValueForDropdown(datafield: any) {
    var fieldName = datafield.apiField;
    var value = Reflect.get(this.updatedPortfolio, fieldName);

    if (datafield.fieldType == 'boolean') {
      switch (value) {
        case true:
          return this.booleanDropdownOptions[1];
        case false:
          return this.booleanDropdownOptions[2];
        default:
          return this.booleanDropdownOptions[0];
      }
    }

    var fieldName = datafield.apiField;

    if (fieldName.includes('Benchmark')) {
      fieldName = 'BenchmarkId';
    }

    var option = this.referenceFieldsDictionary[fieldName]?.find((opt) => {
      return opt.value == value;
    });

    return option;
  }

  getPortfolioValueForDatepicker(fieldName: string) {
    var value = Reflect.get(this.updatedPortfolio, fieldName);

    return getDateOffset(value);
  }

  getDatePickerMinValue(fieldName: string): Date {
    if (fieldName == 'LiquidationDate') {
      return (
        this.getPortfolioValueForDatepicker('InceptionDate') ??
        this.datePickerMinValue
      );
    }

    return this.datePickerMinValue;
  }

  onTextChange(fieldName: string, value: string | undefined) {
    if (!value) {
      value = undefined;
    }

    this.updatePortfolioField(fieldName, value);
  }

  prefillField(fieldName: string, value: any) {
    // Don't prefill if value is set.
    var fieldValue = this.getFieldValue(fieldName);
    if (fieldValue || fieldValue === false) {
      return;
    }

    // Don't prefill if DataOwner and field not owned.
    if (
      this.userRoles === constants.user_roles.owner &&
      !this._sharedService.dataOwnerFields?.includes(fieldName)
    ) {
      return;
    }

    // this.updatePortfolioField(fieldName, value);
  }

  onDropdownChange(dataField: any, option: any) {
    var value = option.value;
    this.updatePortfolioField(dataField.apiField, value);

    // If updating VehicleName, reset SubVehicleName.
    if (dataField.apiField == 'VehicleName') {
      this.updatedPortfolio.SubVehicleName = undefined;

      // Prefill ProxyVotingFlag.
      if (['Mutual Fund', 'Trust Fund'].includes(value)) {
        this.prefillField('ProxyVotingFlag', true);
      }

      // Prefill FinanceBusinessLineName.
      if (value) {
        this.prefillField(
          'FinanceBusinessLineName',
          value == 'Mutual Fund' ? 'Intermediary' : 'Institutional'
        );
      }
    }

    // If updating AssetClassName, reset InvestmentStrategyName.
    if (dataField.apiField == 'AssetClassName') {
      this.prefillField('InvestmentStrategyName', undefined);
    }

    // Prefill Blackrock Identifier with Portfolio Code when TradingSystem is Aladdin.
    if (dataField.apiField == 'TradingSystemName' && value == 'Aladdin') {
      this.prefillField(
        'BlackrockIdentifier',
        this.updatedPortfolio.PortfolioCode
      );
    }

    // Prefill STAR Account Number with SGA Account Number when InsuranceAccountingSystem is BNYM STAR.
    if (
      this.updatedPortfolio.SGAAccountNumber &&
      dataField.apiField == 'InsuranceAccountingSystemName' &&
      value == 'BNYM STAR'
    ) {
      this.prefillField(
        'STARAccountNumber',
        this.updatedPortfolio.SGAAccountNumber
      );
    }

    // If updating SubVehicleName, prefill TransferAgentSystemName.
    if (dataField.apiField == 'SubVehicleName') {
      if (
        [
          'Collective Investment Trust',
          'Common Trust Fund',
          'Stable Value - Stabilizer',
        ].includes(value)
      ) {
        this.prefillField('TransferAgentSystemName', 'BNYM Inst TA');
      } else if (
        [
          '529 Option',
          'US Mutual Fund',
          'US Listed Closed-End Fund',
          'Variable Portfolio',
          'VACS',
        ].includes(value)
      ) {
        this.prefillField('TransferAgentSystemName', 'BNYM Retail TA');
      }
    }

    // If updating PortfolioManagerTeamName, update PrimaryPortfolioManagerName & PortfolioManagerTeamMembers.
    if (dataField.apiField == 'PortfolioManagerTeamName') {
      this.updatePortfolioField(
        'PrimaryPortfolioManagerName',
        option.opt?.PrimaryPortfolioManagerName
      );
      this.updatePortfolioField(
        'PortfolioManagerTeamMembers',
        option.opt?.PortfolioManagerTeamMembers.map(
          (m: { TeamMemberName: string }) => m.TeamMemberName
        ).join(', ')
      );
    }
  }

  onDateChange(fieldName: string, value: Date | null | undefined) {
    this.updatePortfolioField(fieldName, value?.toLocaleDateString('en-CA'));
  }

  updatePortfolioField(fieldName: string, value: any) {
    Reflect.set(this.updatedPortfolio, fieldName, value);
    this.setRequiredValues();
    this.isValidChange.emit(this.isValidRequest());
    this.updatedPortfolioChange.emit(this.updatedPortfolio);
  }

  mapDropdownOptions(datafield: any) {
    const needFilter = !!this.filterOptions[datafield.apiField];
    let options = this.referenceFieldsDictionary[datafield.apiField] || [];

    if (datafield.fieldType === 'boolean') {
      options = this.booleanDropdownOptions;
    }

    if (datafield.apiField.includes('BenchmarkId')) {
      var benchmarkType = datafield.apiField.includes(BenchmarkType.Analytics)
        ? BenchmarkType.Analytics
        : BenchmarkType.Performance;

      options = this.referenceFieldsDictionary['BenchmarkId'].filter(
        (option) => {
          if (option == this.defaultDropdownOption) {
            switch (datafield.apiField) {
              case 'PrimaryBenchmarkId':
                return !this.updatedPortfolio.SecondaryBenchmarkId;
              case 'SecondaryBenchmarkId':
                return !this.updatedPortfolio.TertiaryBenchmarkId;
              case 'PrimaryAnalyticsBenchmarkId':
                return !this.updatedPortfolio.SecondaryAnalyticsBenchmarkId;
              default:
                return true;
            }
          }

          if (option.opt?.Code === constants.NoBenchmarkCode) {
            if (!datafield.apiField.includes('Primary')) {
              return false;
            }

            if (
              this.updatedPortfolio.SecondaryBenchmarkId &&
              datafield.apiField === 'PrimaryBenchmarkId'
            ) {
              return false;
            }

            if (
              this.updatedPortfolio.SecondaryAnalyticsBenchmarkId &&
              datafield.apiField === 'PrimaryAnalyticsBenchmarkId'
            ) {
              return false;
            }
          }

          // Skip options which are selected by other Benchmarks.
          if (
            [
              this.updatedPortfolio.PrimaryBenchmarkId,
              this.updatedPortfolio.SecondaryBenchmarkId,
              this.updatedPortfolio.TertiaryBenchmarkId,
              this.updatedPortfolio.PrimaryAnalyticsBenchmarkId,
              this.updatedPortfolio.SecondaryAnalyticsBenchmarkId,
            ].includes(option.value) &&
            this.getFieldValue(datafield.apiField) != option.value
          ) {
            return false;
          }

          // Otherwise, return options which match BenchmarkType.
          return option.opt.Type == benchmarkType;
        }
      );
    }

    if (datafield.apiField == 'SubVehicleName') {
      // Return options which match ParentVehicle, or opt is null (default select option).
      options = this.referenceFieldsDictionary[datafield.apiField].filter(
        (option) =>
          !option.opt ||
          option.opt?.ParentVehicleName == this.updatedPortfolio.VehicleName
      );
    }

    if (datafield.apiField == 'InvestmentStrategyName') {
      // Return options which match AssetClass, or opt is null (default select option).
      options = this.referenceFieldsDictionary[datafield.apiField].filter(
        (option) =>
          !option.opt ||
          option.opt?.AssetClassName == this.updatedPortfolio.AssetClassName
      );
    }

    if (datafield.apiField == 'Status') {
      options = this.referenceFieldsDictionary[datafield.apiField]
        .filter((option) => {
          switch (this.portfolio.Status!) {
            case PortfolioStatus.InProgress:
              return [
                PortfolioStatus.InProgress,
                PortfolioStatus.OperationallyReady,
              ].includes(option.value);
            case PortfolioStatus.OperationallyReady:
              return [
                PortfolioStatus.OperationallyReady,
                PortfolioStatus.Active,
              ].includes(option.value);
            case PortfolioStatus.Active:
              return [PortfolioStatus.Active, PortfolioStatus.Closed].includes(
                option.value
              );
            case PortfolioStatus.Closed:
              return [
                PortfolioStatus.Closed,
                PortfolioStatus.InProgress,
              ].includes(option.value);
          }
        })
        .map((opt) => {
          if (opt.value == PortfolioStatus.InProgress) {
            opt.text =
              this.portfolio.Status == PortfolioStatus.Closed
                ? 'Reactivate'
                : this.portfolioStatusMapping[PortfolioStatus.InProgress];
          }
          return opt;
        });
    }

    return {
      showFilter: options.length > 50,
      options: needFilter
        ? options.filter((opt: any) =>
            opt.text
              .toLowerCase()
              .includes(this.filterOptions[datafield.apiField].toLowerCase())
          )
        : options,
    };
  }

  isTabDisabled(tab: any) {
    return this.isEditing && ['tags', 'form'].includes(tab.key);
  }

  isTabInvalid(tab: any) {
    const section: string = tab.key;
    const fields: Record<string, any> = this.dataFields;
    const data = fields[section];

    if (!data) {
      return false;
    }

    for (var s of data) {
      for (var field of s.datafields) {
        if (this.isFieldError(field.apiField)) {
          return true;
        }
      }
    }

    return false;
  }

  isFieldEditable(fieldName: string) {
    if (this.userRoles == constants.user_roles.reader) {
      return false;
    }

    if (
      this.portfolio.Status == PortfolioStatus.Closed &&
      !['LiquidationDate', 'Status'].includes(fieldName)
    ) {
      return false;
    }

    if (
      fieldName == 'PortfolioCode' &&
      this.updatedPortfolio.Status != PortfolioStatus.InProgress
    ) {
      return false;
    }

    if (
      ['PrimaryPortfolioManagerName', 'PortfolioManagerTeamMembers'].includes(
        fieldName
      )
    ) {
      return false;
    }

    if (
      fieldName == 'CustodianAccountNumber' &&
      (this.isNullOrUndefined(this.updatedPortfolio.CustodianBankName) ||
        this.updatedPortfolio.CustodianBankName == 'No Custodian Access')
    ) {
      return false;
    }

    if (
      ['FinanceBusinessLineName', 'FinanceAUMAmountTypeName'].includes(
        fieldName
      ) &&
      this.updatedPortfolio.FinanceAUMSourceName == 'Do Not Load'
    ) {
      return false;
    }

    if (
      [
        'ESGClientDirectedExclusion',
        'ESGFullIntegration',
        'ESGSustainability',
        'ESGSustainabilityObjectiveName',
      ].includes(fieldName) &&
      !this.updatedPortfolio.ESGFlag
    ) {
      return false;
    }

    if (
      fieldName == 'ESGSustainabilityObjectiveName' &&
      !this.updatedPortfolio.ESGSustainability
    ) {
      return false;
    }

    if (
      fieldName == 'SGAAccountNumber' &&
      this.updatedPortfolio.IBORSystemName != 'BNYM SGA'
    ) {
      return false;
    }

    if (
      fieldName == 'BlackrockIdentifier' &&
      this.updatedPortfolio.TradingSystemName != 'Aladdin'
    ) {
      return false;
    }

    if (
      fieldName == 'InvestOneAccountNumber' &&
      this.updatedPortfolio.ABORSystemName != 'BNYM InvestOne'
    ) {
      return false;
    }

    if (
      fieldName == 'STARAccountNumber' &&
      this.updatedPortfolio.InsuranceAccountingSystemName != 'BNYM STAR'
    ) {
      return false;
    }

    if (
      fieldName == 'OnCoreAccountNumber' &&
      this.updatedPortfolio.IBORSystemName != 'BNYM OnCore'
    ) {
      return false;
    }

    if (
      fieldName == 'ShareholderID' &&
      (!this.updatedPortfolio.TransferAgentSystemName ||
        this.updatedPortfolio.TransferAgentSystemName == 'Not Applicable')
    ) {
      return false;
    }

    if (
      ['PerformanceInceptionDate', 'PerformanceStartDate'].includes(
        fieldName
      ) &&
      this.updatedPortfolio.PerformanceBookOfRecordName == 'Not Applicable'
    ) {
      return false;
    }

    if (
      fieldName == 'SecondaryBenchmarkId' &&
      (!this.updatedPortfolio.PrimaryBenchmarkId ||
        this.updatedPortfolio.PrimaryBenchmarkId ===
          this.noPerformanceBenchmarkId)
    ) {
      return false;
    }

    if (
      fieldName == 'TertiaryBenchmarkId' &&
      !this.updatedPortfolio.SecondaryBenchmarkId
    ) {
      return false;
    }

    if (
      fieldName == 'SecondaryAnalyticsBenchmarkId' &&
      (!this.updatedPortfolio.PrimaryAnalyticsBenchmarkId ||
        this.updatedPortfolio.PrimaryAnalyticsBenchmarkId ===
          this.noAnalyticsBenchmarkId)
    ) {
      return false;
    }

    if (this.userRoles == constants.user_roles.owner) {
      return this._sharedService.dataOwnerFields?.includes(fieldName);
    }

    return true;
  }

  isFieldRequired(fieldName: string, skipValidate: boolean = false) {
    const requiredFields = getRequiredFieldsBasedonStatus(
      this.updatedPortfolio,
      false,
      null,
      false
    );

    var moreFields = checkRequiredFields(
      this.updatedPortfolio || this.portfolio,
      requiredFields
    );

    return skipValidate
      ? requiredFields.includes(fieldName)
      : (moreFields.isFailed && moreFields.errorFields.includes(fieldName)) ||
          this.additionalRequiredFields.includes(fieldName);
  }

  isFieldShown(fieldName: string) {
    if (
      fieldName == 'PortfolioCode' &&
      !(this.isEditing && this.portfolio.Status == PortfolioStatus.InProgress)
    ) {
      return false;
    }

    if (
      fieldName == 'Status' &&
      !(this.isEditing && this.userRoles == constants.user_roles.approver)
    ) {
      return false;
    }

    if (
      fieldName == 'ParentPortfolioCode' &&
      this.updatedPortfolio.PortfolioTypeName != PortfolioType.Sleeve
    ) {
      return false;
    }

    if (
      fieldName == 'LiquidationDate' &&
      this.updatedPortfolio.Status != PortfolioStatus.Closed
    ) {
      return false;
    }

    return true;
  }

  isValidRequest() {
    for (var fieldName in this.fieldDictionary) {
      if (this.isFieldError(fieldName)) {
        return false;
      }
    }

    return true;
  }

  isNullOrUndefined(obj: any) {
    return obj == undefined || obj == null;
  }

  getFieldValue(fieldName: string) {
    return Reflect.get(this.updatedPortfolio, fieldName);
  }

  isFieldError(fieldName: string) {
    if (!this.isEditing) {
      return false;
    }

    var fieldValue = this.getFieldValue(fieldName);

    if (this.isFieldRequired(fieldName) && this.isNullOrUndefined(fieldValue)) {
      return true;
    }

    var characterLimit = this.fieldDictionary[fieldName].characterLimit;

    if (characterLimit && fieldValue?.length > characterLimit) {
      return true;
    }

    // LiquidationDate must be >= InceptionDate.
    if (
      fieldName == 'LiquidationDate' &&
      (this.updatedPortfolio.LiquidationDate ?? Date.UTC(1)) <
        (this.updatedPortfolio.InceptionDate ?? Date.UTC(1))
    ) {
      return true;
    }

    // LEINumber must be alphanumeric and 20 characters (characterLimit).
    if (fieldName == 'LEINumber' && fieldValue) {
      return (
        fieldValue.length != characterLimit || !fieldValue.match(/^[0-9a-z]+$/i)
      );
    }

    // PortfolioCode must be alphanumeric + '-', '_'.
    if (fieldName == 'PortfolioCode' && fieldValue) {
      return !fieldValue.match(/^[a-z0-9_-]+$/i);
    }

    return false;
  }

  checkReadOnly(section: any) {
    if (this.userRoles == constants.user_roles.reader) {
      return true;
    }

    for (var df of section.datafields) {
      if (this.isFieldShown(df.apiField) && this.isFieldEditable(df.apiField)) {
        return false;
      }
    }

    return true;
  }

  getOwnerInfo(ownerData: string[]) {
    let ownerinfo = 'Owned by:';
    ownerData.forEach((owner: string) => (ownerinfo += `\r${owner}`));
    return ownerinfo;
  }

  onHighlightRequiredFields(fields: string[], editForm: string) {
    this.activeTab = 'details';
    this.activeTabChange.emit(this.activeTab);

    this.isEditing = true;
    this.isEditingChange.emit(true);

    this.editForm = editForm;
    this.editFormChange.emit(this.editForm);

    this.additionalRequiredFields = fields;
  }

  getHintInfo(datafield: any) {
    return createInputMaxLengthHint(
      datafield.apiField,
      datafield.fieldType === 'number'
    );
  }

  renderStatusClass(datafield: any) {
    return datafield.apiField === 'Status'
      ? getStatusClass(this.getPortfolioValueForTextField(datafield))
      : '';
  }

  handleOptionsFilter(value: string, datafield: any) {
    this.filterOptions[datafield.apiField] = value;
  }
}
