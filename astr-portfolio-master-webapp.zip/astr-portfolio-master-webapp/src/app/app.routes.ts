import { Routes } from '@angular/router';
import { MsalGuard } from '@azure/msal-angular';
import { UserNotAllowedComponent } from './layout/user-not-allowed/user-not-allowed.component';
import { ServerErrorComponent } from './layout/server-error/server-error.component';

export const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'portfolio'
  },
  {
    path: 'portfolio',
    loadChildren: () =>
      import('./layout/layout.module').then((m) => m.MainLayoutModule),
      canActivate: [MsalGuard],
  },

  {
    path: 'usernotallowed',
    component: UserNotAllowedComponent,
  },

  {
    path: '**',
    component: ServerErrorComponent,
  },
];
