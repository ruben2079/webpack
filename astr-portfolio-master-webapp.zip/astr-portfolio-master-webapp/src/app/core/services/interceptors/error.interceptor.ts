import { Injectable } from '@angular/core';
import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { catchError, map, Observable, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { NotificationService } from '@progress/kendo-angular-notification';
import { HttpError } from '../../const/constants';
import { isDev, isLocal } from '../../utils/utils';
import { ENTITILEMENTS_API } from '../../const/api.const';

@Injectable({
  providedIn: 'root',
})
export class ErrorInterceptor implements HttpInterceptor {
  constructor(
    private readonly router: Router,
    private readonly notificationService: NotificationService
  ) {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse) => {
        if (!isLocal() && !isDev()) {
          if (
            request.url == ENTITILEMENTS_API.getentitlements() && 
            (error?.status === HttpError.Unauthorized ||
            error?.status === HttpError.Forbidden)
          ) {
            this.router.navigate(['usernotallowed']);
          }
          if (error?.status === HttpError.GatewayTimeout || error?.status == HttpError.BadGateway) {
            this.router.navigate(['**']);
          }
        }

        this.notificationService.show({
          content: error?.error?.detail ?? error.message,
          cssClass: 'button-notification',
          animation: { type: 'slide', duration: 500 },
          position: { horizontal: 'center', vertical: 'top' },
          type: { style: 'error', icon: true },
          hideAfter: 5000,
        });

        return throwError(() => error);
      })
    );
  }
}
