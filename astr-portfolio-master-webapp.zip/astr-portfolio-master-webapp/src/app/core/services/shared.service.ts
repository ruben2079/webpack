import { Injectable, EventEmitter, Output } from '@angular/core';
import { BehaviorSubject, Subject, Observable } from 'rxjs';
import {
  Portfolio,
  PortfolioXreference,
  Portfolios,
} from '../model/portfolios.interface';
import { ENTITILEMENTS_API, PM_API } from '../const/api.const';
import { HttpService } from './http.service';
import { getEnv, getLocationParam } from '../utils/utils';
import { PM_URL_PARAMS, user_roles } from '../const/constants';
import { Entitlements } from '../model/entitlements-model';
import { entitlement_mock } from '../../mock/entitlements';
import { AngularPlugin } from '@microsoft/applicationinsights-angularplugin-js';
import { ApplicationInsights } from '@microsoft/applicationinsights-web';
import { Router } from '@angular/router';
import { instrumentationKey } from '../msal/msal-instance.factory';

@Injectable({
  providedIn: 'root',
})
export class SharedService {
  @Output() AclickedEvent = new EventEmitter<boolean>();

  constructor(private _http: HttpService, private router: Router) {}

  Aclickeded(value: boolean) {
    this.AclickedEvent.emit(value);
  }
  private _subject = new Subject<any>();
  newEvent(event: any) {
    this._subject.next(event);
  }

  get events$() {
    return this._subject.asObservable();
  }
  setClickeded: BehaviorSubject<any> = new BehaviorSubject(null);
  getClickeded = this.setClickeded.asObservable();

  pushTag: BehaviorSubject<any> = new BehaviorSubject(null);
  getTag = this.pushTag.asObservable();

  setUserRole: BehaviorSubject<any> = new BehaviorSubject(null);
  getUserRole = this.setUserRole.asObservable();

  referenceData: BehaviorSubject<any> = new BehaviorSubject(null);
  portfolioBenchmark!: Array<any>;

  getStatus!: string;
  portfolioData!: Portfolio;
  portfoliosData!: [Portfolio];
  operationalChangedData!: any;
  isCreate: boolean = false;
  isCloneClicked: boolean = false;
  isPortfolioCreate: boolean = false;

  isOpened: boolean = false;
  isChangeStatusOpened: boolean = false;
  dataOwnerFields: Array<string> = [];
  setUserName: BehaviorSubject<any> = new BehaviorSubject(null);
  getUserName = this.setUserName.asObservable();
  getReferenceData = this.referenceData.asObservable();
  portfolioXreferences!: PortfolioXreference[];
  performanceBenchmarkObject: BehaviorSubject<any> = new BehaviorSubject({});
  getAllFormsData: BehaviorSubject<any> = new BehaviorSubject({});
  operationalFormData: any;
  performanceFormData: any;

  openPortfolioInEditMode: boolean = false;
  entitlement: any;

  // using  function we can also fetch the data
  getUsernameForFunction() {
    return this.setUserName.asObservable();
  }
  //  private _items$ = new BehaviorSubject<T[]>([]);
  // get items$() {
  //   return this._items$.asObservable();
  // }

  private formValidationData = {};

  allFormValidation: BehaviorSubject<any> = new BehaviorSubject(
    this.formValidationData
  );

  getAllFormValidation() {
    return this.allFormValidation.asObservable();
  }

  setAllFormValidation(val: any): void {
    this.formValidationData = { ...this.formValidationData, ...val };
    this.allFormValidation.next(this.formValidationData);
  }

  // Set a value in local storage
  setItem(key: string, value: string): void {
    localStorage.setItem(key, value);
  }
  // Set a array value in local storage
  setArrayItem(key: string, value: any): void {
    localStorage.setItem(key, value);
  }

  // // Set a value in local storage
  // setSaveButton(key: string, value: string): void {
  //   localStorage.setItem(key, value);
  // }
  // // Set a array value in local storage
  // getSaveButton(key: string): string | null {
  //   return localStorage.getItem(key);
  // }
  // get an array value in local storage
  getArrayItem(key: string): any | null {
    localStorage.getItem(key);
  }

  // Get a value from local storage
  getItem(key: string): string | null {
    return localStorage.getItem(key);
  }

  // Remove a value from local storage
  removeItem(key: string): void {
    localStorage.removeItem(key);
  }

  // Clear all items from local storage
  clear(): void {
    localStorage.clear();
  }

  currentPortfolio: Portfolio | undefined;

  getCurrentPortfolio(): Portfolio | undefined {
    return this.currentPortfolio;
  }

  private dashboardLinkPortfolio: any = new BehaviorSubject(null);
  private createPortfolio: any = new BehaviorSubject(null);
  private editPortfolio: any = new BehaviorSubject(null);
  private clonePortfolio: any = new BehaviorSubject(null);

  updatedDashboardLinkPortfolio: Observable<any> =
    this.dashboardLinkPortfolio.asObservable();
  updatedCreatePortfolio: Observable<any> = this.createPortfolio.asObservable();
  updatedEditPortfolio: Observable<any> = this.editPortfolio.asObservable();
  updatedClonePortfolio: Observable<any> = this.clonePortfolio.asObservable();

  getDashboardLinkPortfolio(): Observable<Portfolio> {
    return this.updatedDashboardLinkPortfolio;
  }

  getCreatePortfolio(): Observable<Portfolio> {
    return this.updatedCreatePortfolio;
  }

  getEditPortfolio(): Observable<Portfolio> {
    return this.updatedEditPortfolio;
  }

  getClonePortfolio(): Observable<Portfolio> {
    return this.updatedClonePortfolio;
  }

  updateCurrentPortfolio(data: Portfolio, str?: string): void {
    this.openPortfolioInEditMode = str != 'dashboard-link';
    this.currentPortfolio = data;
  }

  callEntitlements(cb?: any) {
    !this.entitlement
      ? this._http
          .get(ENTITILEMENTS_API.getentitlements())
          .subscribe((data: Entitlements) => {
            let roleValue = getLocationParam(PM_URL_PARAMS.role);
            let role = user_roles.reader;
            const entitlement =
              getEnv() == 'prod' || !roleValue
                ? data
                : entitlement_mock[roleValue];
            if (!entitlement) {
              this.router.navigate(['usernotallowed']);
              return;
            }
            if (entitlement.CanApprove) {
              roleValue = 'approver';
            } else if (
              entitlement.CanUpdate &&
              entitlement.OwnedFields.length > 0
            ) {
              this.dataOwnerFields = entitlement.OwnedFields;
              roleValue = 'owner';
            } else if (entitlement.CanSetup) {
              roleValue = 'admin';
            } else {
              roleValue = 'reader';
            }
            switch (roleValue) {
              case 'admin':
                role = user_roles.admin;
                break;
              case 'approver':
                role = user_roles.approver;
                break;
              case 'owner':
                role = user_roles.owner;
                break;
              default:
                break;
            }
            this.entitlement = entitlement;
            this.setUserRole.next(role);
            cb && cb();
            this.loadingTrack();
          })
      : cb && cb();
  }

  getEntitlement() {
    return this.entitlement;
  }

  loadingTrack() {
    try {
      var angularPlugin = new AngularPlugin();
      const appInsights = new ApplicationInsights({
        config: {
          instrumentationKey: instrumentationKey[getEnv()],
          extensions: [angularPlugin],
          extensionConfig: {
            [angularPlugin.identifier]: { router: this.router },
          },
        },
      });
      appInsights.loadAppInsights();
    } catch (error) {
      console.log(error);
    }
  }

  private allPortfoliosFromApi: any = new BehaviorSubject(null);
  public allPortfolios: Observable<Portfolios> =
    this.allPortfoliosFromApi.asObservable();

  getAllPortfoliosApi() {
    this._http.get(PM_API.getportfolios()).subscribe({
      next: (res: any) => {
        this.allPortfoliosFromApi = res;
      },
    });
  }
}
