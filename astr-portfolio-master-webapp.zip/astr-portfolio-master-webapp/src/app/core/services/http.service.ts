import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import * as apiConstants from '../../core/const/api.const';
import { Portfolio } from '../model/portfolios.interface';
import { firstValueFrom } from 'rxjs';
import { ReferenceField } from '../model/reference-fields.interface';

@Injectable({
  providedIn: 'root',
})
export class HttpService {
  constructor(private _http: HttpClient) {}

  get(url: string): Observable<any> {
    return this._http.get(url);
  }

  getDataById(url: any, id: number): Observable<any> {
    return this.get(`${url}/${id}`);
  }

  put(url: string, body: any): Observable<any> {
    return this._http.put(url, body);
  }

  post(url: string, body: any): Observable<any> {
    return this._http.post(url, body);
  }

  getPortfolioByPortfolioCode(portfolioCode: string): Observable<Portfolio> {
    return this.get(
      `${apiConstants.PM_BY_ID.getById()}/${portfolioCode}?isPortfolioCode=true`
    );
  }

  updatePortfolioById(
    portfolioId: number,
    updatedPortfolio: Portfolio
  ): Observable<Portfolio> {
    return this.put(
      `${apiConstants.PM_BY_ID.getById()}/${portfolioId}`,
      updatedPortfolio
    );
  }

  async getPortfolioReferenceFields(): Promise<ReferenceField[]> {
    const referenceFields = await firstValueFrom<ReferenceField[]>(
      this._http.get<ReferenceField[]>(
        apiConstants.REFERENCE_DATA_URL.getreferencedata()
      )
    );
    return referenceFields;
  }

  getTagsAdGroup(): Observable<any> {
    return this._http.get(apiConstants.GET_TAG_AD_GROUP.getAdGroupTags());
  }

  downstreamAPI(url: any, id: number, str: string, body: any): Observable<any> {
    const genrateUrl = `${url}/${id}/loadtodownstream/${str}`;
    return this._http.put(genrateUrl, body);
  }

  notifyOwner(portfolioId: any): Observable<any> {
    return this._http.put(
      apiConstants.NOTIFY_OWNER.notifyOwner(portfolioId),
      null
    );
  }
}
