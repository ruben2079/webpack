export class AssetClassName {
    
    constructor(public AssetClassName:string,public CreatedBy:string,public CreatedOn:string, 
        public Id:number,public ModifiedBy:string, public ModifiedOn:string,public Name: string,
        public Status: boolean) {

    }

}
