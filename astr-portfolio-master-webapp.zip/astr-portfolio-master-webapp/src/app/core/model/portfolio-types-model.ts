export class PortfolioTypes {
    
    constructor(public FieldName:string,public FieldToUpdate:string,public IsDynamic:boolean, 
        public Options: any[]) {

    }

}