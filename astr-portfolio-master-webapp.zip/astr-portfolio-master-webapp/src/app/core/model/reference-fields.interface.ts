export interface ReferenceField {
  FieldName: string;
  FieldToUpdate: string;
  IsDynamic: boolean;

  Options: Option[] | string[];
}

export interface Option {
  Id: number;
  Code?: string;
  LookupSubValue?: string;
  PortfolioCode?: string;
  Name: string;
  Type: string;
  Status: boolean;
  CreatedBy: string;
  CreatedOn: string;
  ModifiedBy: string;
  ModifiedOn: string;
}

export interface DropdownOption {
  text: string;
  value: any;
  opt?: any;
}
