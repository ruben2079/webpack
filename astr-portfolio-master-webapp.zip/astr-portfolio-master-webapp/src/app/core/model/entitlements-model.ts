export class Entitlements {
  constructor(
    public CanApprove: boolean,
    public CanRead: boolean,
    public CanSetup: boolean,
    public CanUpdate: boolean,
    public FamilyName: string,
    public GivenName: string,
    public OwnedFields: any[],
    public Username: string
  ) {}
}
