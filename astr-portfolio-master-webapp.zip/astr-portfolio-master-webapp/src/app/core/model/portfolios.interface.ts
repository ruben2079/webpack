import { StringFilterComponent } from '@progress/kendo-angular-grid';

export interface Portfolios {
  Portfolios?: Portfolio[];
}

export enum PortfolioStatus {
  InProgress = 'WorkInProgress',
  OperationallyReady = 'OperationallyReady',
  Active = 'Active',
  Closed = 'Closed',
}

export enum PortfolioType {
  Model = 'Model',
  Parent = 'Parent',
  Portfolio = 'Portfolio',
  Sleeve = 'Sleeve',
}

export interface Portfolio {
  Id?: number;
  Status?: PortfolioStatus;
  CreatedBy?: string;
  CreatedOn?: string;
  ModifiedBy?: string;
  ModifiedOn?: string;
  PortfolioBenchmarks?: PortfolioBenchmark[];
  PortfolioXReferences?: PortfolioXreference[];
  ShareClasses?: ShareClass[];
  PortfolioTagIds?: PortfolioTagId[];
  PortfolioTags?: PortfolioTag[];
  PortfolioCode?: string;
  PortfolioName?: string;
  PortfolioTypeName?: PortfolioType;
  ParentPortfolioCode?: string;
  InvestmentStrategyName?: string;
  VehicleName?: string;
  SubVehicleName?: string;
  AssetClassName?: string;
  BaseCurrencyName?: string;
  ReportingCurrencyName?: string;
  DomicileCountryName?: string;
  CustodianBankName?: string;
  IBORSystemName?: string;
  ABORSystemName?: string;
  InsuranceAccountingSystemName?: string;
  TradingSystemName?: string;
  TransferAgentSystemName?: string;
  PerformanceBookOfRecordName?: string;
  PortfolioManagerTeamName?: string;
  LotSelectionMethodName?: string;
  TaxAccountingMethodName?: string;
  PrimaryAmortizationRuleName?: string;
  LegalInvestmentManagerName?: string;
  ClientName?: string;
  FinanceAUMSourceName?: string;
  FinanceAUMAmountTypeName?: string;
  FinanceBusinessLineName?: string;
  ManagementStyleName?: string;
  AladdinProcessingName?: string;
  RegulatoryStructureName?: string;
  InsuranceLegalEntityGroupingName?: string;
  LegalStructureName?: string;
  RiskModelName?: string;
  ComplianceCertification?: string;
  AccountingBasisName?: string;
  ESGSustainabilityObjectiveName?: any;
  CustodianAccountNumber?: string;
  FiscalYearEnd?: string;
  InceptionDate?: string;
  LiquidationDate?: string;
  PerformanceInceptionDate?: string;
  PerformanceStartDate?: string;
  TaxId?: string;
  ShortTermDiscountAccrualFlag?: boolean;
  LEINumber?: string;
  SGAAccount?: string;
  blackRock?: string;
  StarAccount?: string;
  shareholder?: string;
  investOne?: string;
  onCore?: string;
  SECDerivativeRule18f4?: any;
  Discretionary?: boolean;
  MultiSector?: boolean;
  ProxyVotingFlag?: boolean;
  MASSFundOfFundsSystem?: boolean;
  ESGFlag?: any;
  ESGClientDirectedExclusion?: any;
  ESGFullIntegration?: any;
  ESGSustainability?: any;
  VoyaSubAdvised?: boolean;
  EquityIPOAllowed?: boolean;
  SoftDollarsAllowed?: boolean;
  CommissionSharingAgreement?: boolean;
  CrossTradingAllowed?: boolean;
  DirectedBrokerage?: boolean;
  MFN?: boolean;
  PerformanceBasedFee?: boolean;
  LoadCashFlows?: boolean;
  NAICDesignations?: boolean;
  PortfolioSubscribers?: PortfolioSubscriber[];
  ChildPortfolios?: string[];
  PrimaryBenchmarkId?: number;
  SecondaryBenchmarkId?: number;
  TertiaryBenchmarkId?: number;
  PrimaryAnalyticsBenchmarkId?: number;
  SecondaryAnalyticsBenchmarkId?: number;
  SGAAccountNumber?: string;
  STARAccountNumber?: string;
  BlackrockIdentifier?: string;
  ShareholderID?: string;
  InvestOneAccountNumber?: string;
  OnCoreAccountNumber?: string;
  PrimaryPortfolioManagerName?: string;
  PortfolioManagerTeamMembers?: string;

  // additional properties not needed for payload
  detailsFormValid?: boolean;
  isdetailsFormEdit?: boolean;
  operationalFormValid?: boolean;
  isOperationalFormEdit?: boolean;
  performanceFormValid?: boolean;
  isperformanceFormEdit?: boolean;
  accountingFormValid?: boolean;
  isAccountingFormEdit?: boolean;
  complianceFormValid?: boolean;
  iscomplianceFormEdit?: boolean;
  riskFormValid?: boolean;
  isRiskFormEdit?: boolean;
  identifiersFormValid?: boolean;
  isIdentifiersFormEdit?: boolean;
  reportingFormValid?: boolean;
  isReportingFormEdit?: boolean;
}

export interface PortfolioBenchmark {
  Id?: number;
  Status?: boolean;
  CreatedBy?: string;
  CreatedOn?: string;
  ModifiedBy?: string;
  ModifiedOn?: string;
  BenchmarkId?: number;
  BenchmarkType?: string;
  BenchmarkPrecedenceName?: string;
  Options?: Options[];
}
export interface Options {
  Id?: number;
  Name?: string;
  Code?: string;
  Type?: string;
  Status?: string;
  CreatedBy?: string;
  CreatedOn?: string;
  ModifiedBy?: string;
  ModifiedOn?: string;
}

export interface PortfolioXreference {
  Id?: number;
  Status?: boolean;
  CreatedBy?: string;
  CreatedOn?: string;
  ModifiedBy?: string;
  ModifiedOn?: string;
  PortfolioXReferenceCategoryName?: string;
  PortfolioXReferenceValue?: string;
}

export interface ShareClass {
  Id?: number;
  Status?: boolean;
  CreatedBy?: string;
  CreatedOn?: string;
  ModifiedBy?: string;
  ModifiedOn?: string;
  ShareClassName?: string;
  ShareClassIdentifierName?: string;
  Ticker?: string;
  CUSIP?: string;
  ISIN?: string;
  ShareClassStartDate?: string;
  ShareClassEndDate?: string;
  ABORShareClassIdentifier?: string;
  BaseCurrencyName?: string;
  DomicileCountryName?: string;
  ShareClassFeeTypeName?: string;
}

export interface PortfolioTagId {
  Id?: number;
  Status?: boolean;
  CreatedBy?: string;
  CreatedOn?: string;
  ModifiedBy?: string;
  ModifiedOn?: string;
  PortfolioTagId?: number;
}

export interface PortfolioTag {
  Id?: number;
  Status?: boolean;
  CreatedBy?: string;
  CreatedOn?: string;
  ModifiedBy?: string;
  ModifiedOn?: string;
  Name?: string;
  PortfolioTagDescription?: string;
  ADGroupName?: string;
  Portfolios?: string[];
}

export interface PortfolioSubscriber {
  Id?: number;
  Status?: boolean;
  CreatedBy?: string;
  CreatedOn?: string;
  ModifiedBy?: string;
  ModifiedOn?: string;
  DownstreamSystemName?: string;
  LastCompletedTransmissionTimestamp?: string;
  PortfolioTransmissions?: PortfolioTransmission[];
}

export interface PortfolioTransmission {
  Id?: number;
  Status?: string;
  CreatedBy?: string;
  CreatedOn?: string;
  ModifiedBy?: string;
  ModifiedOn?: string;
}
