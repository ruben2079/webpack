export class VehicleName {
    
    constructor(public CreatedBy:string,public CreatedOn:string,public Id:number, 
        public ModifiedBy:string, public ModifiedOn:string,public Name: string,
        public SubVehicles: any[],
        public Status: boolean) {

    }

}
