import { getEnv, isLocal } from '../utils/utils';
const backend_protocol = 'https';
const backend_hosts: {
  [key: string]: string;
} = {
  dev: 'astr-api-dev.iam.intranet',
  test: 'astr-api-test.iam.intranet',
  prod: 'astr-api.iam.intranet',
  //   dev: 'vim-zue2-dev-astr-mstr-001.vimasezue2intdev002.appserviceenvironment.net',
  // test: "vim-zue2-test-astr-mstr-001.vimasezue2inttest002.appserviceenvironment.net",
  //   prod: 'vim-zue2-prod-astr-mstr-001.vimasezue2intprod001.appserviceenvironment.net',
};

export const getbackendurl = (): string => {
  if (isLocal()) {
    return '';
  }
  const env: string = getEnv();
  return `${backend_protocol}://${backend_hosts[env]}`;
};

const url_prefix = getbackendurl();

export const PM_API = {
  getportfolios: () => `${url_prefix}/v1/portfolios`,
};

export const ENTITILEMENTS_API = {
  getentitlements: () => `${url_prefix}/v1/entitlements/PortfolioMaster`,
};

export const REFERENCE_DATA_URL = {
  getreferencedata: () => `${url_prefix}/v1/portfolios/referencefields`,
};

export const REFERENCE_DATA_BENCHMARK_URL = {
  getreferencedata: () =>
    `${url_prefix}/v1/portfolios/PortfolioBenchmarks/referencefields`,
};

export const REFERENCE_DATA_XREFERENCES_URL = {
  getreferencedata: () =>
    `${url_prefix}/v1/portfolios/PortfolioXReferences/referencefields`,
};

export const CHANGE_STATUS_URL = {
  changePortfolioStatus: () => `${url_prefix}/v1/portfolios`,
};

export const SETTINGS_URL = {
  getSettings: () => `${url_prefix}/v1/settings/PortfolioMaster`,
};
export const CREATE_TAG = {
  createTags: () => `${url_prefix}/v1/portfolios/referencefields/PortfolioTags`,
};
export const EDIT_TAG = {
  createTags: (tagId: any) =>
    `${url_prefix}/v1/portfolios/referencefields/PortfolioTags/${tagId}`,
};

export const GET_TAG_AD_GROUP = {
  getAdGroupTags: () =>
    `${url_prefix}/v1/portfolios/PortfolioTags/referencefields`,
};

export const PM_BY_ID = {
  getById: () => `${url_prefix}/v2/portfolios`,
};

export const UPDATE_PORTFOLIO = {
  updatePortfolio: () => `${url_prefix}/v2/portfolios`,
};

export const CLONE_PORTFOLIO = {
  clonePortfolio: (portfolioId: any) =>
    `${url_prefix}/v1/portfolios/${portfolioId}/clone`,
};

// Load Downstream
export const DOWNSTREAM = {
  downstreamPortfolio: () => `${url_prefix}/v1/portfolios`,
};

export const NOTIFY_OWNER = {
  notifyOwner: (portfolioId: any) =>
    `${url_prefix}/v1/portfolios/${portfolioId}/NotifyDataOwnersForMissingFields`,
};
