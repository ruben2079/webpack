import _ from 'lodash';
import { statusCompare } from '../utils/utils';
export const APP_ID = 'portfolioMaster';
export const THEMES = { DARK: 'dark', LIGHT: 'light' };
export const DEFAULT_THEME = THEMES.LIGHT;

export enum BenchmarkType {
  Performance = 'Performance',
  Analytics = 'Analytics',
}

export const NoBenchmarkCode = 'NO_BENCH';

export const portfolio_key_name_mapping: any = {
  PortfolioCode: 'Portfolio Code',
  PortfolioName: 'Portfolio Name',
  PortfolioTypeName: 'Portfolio Type',
  ParentPortfolio: 'Parent Portfolio Code',
  ParentPortfolioCode: 'Parent Portfolio Code',
  AssetClassName: 'Asset Class',
  VehicleName: 'Vehicle Type',
  SubVehicleName: 'Sub-Vehicle',
  InceptionDate: 'Inception Date',
  LiquidationDate: 'Liquidation Date',
  Status: 'Portfolio Status',
  MultiSector: 'MultiSector Indicator',
  PrimaryBenchmarkId: 'Primary Benchmark',
  SecondaryBenchmarkId: 'Secondary Benchmark',
  TertiaryBenchmarkId: 'Tertiary Benchmark',
  PrimaryAnalyticsBenchmarkId: 'Analytics (Risk) Benchmark',
  SecondaryAnalyticsBenchmarkId: 'Secondary Analytics (Risk) Benchmark',
  SGAAccountNumber: 'SGA Account Number',
  STARAccountNumber: 'STAR Account Number',
  BlackrockIdentifier: 'Blackrock Identifier',
  ShareholderID: 'Shareholder ID',
  InvestOneAccountNumber: 'InvestOne Account Number',
  OnCoreAccountNumber: 'OnCore Account Number',
  InvestmentStrategyName: 'Investment Strategy',
  PerformanceInceptionDate: 'Performance Inception Date',
  PerformanceStartDate: 'Performance Start Date',
  ManagementStyleName: 'Management Style',
  Discretionary: 'Discretionary',
  PrimaryPortfolioManagerName: 'Primary Portfolio Manager Name',
  PortfolioManagerTeamMembers: 'Portfolio Management Team Members',
  PortfolioManagerTeamName: 'Investment Team Name',
  CustodianBankName: 'Custodian Bank Name',
  CustodianAccountNumber: 'Custodian Account Number',
  BaseCurrencyName: 'Base Currency',
  DomicileCountryName: 'Portfolio Country of Domicile',
  IBORSystemName: 'IBOR Source System',
  ABORSystemName: 'ABOR Source System',
  InsuranceAccountingSystemName: 'Insurance Accounting System',
  TradingSystemName: 'OMS Trading System',
  PerformanceBookOfRecordName: 'Performance Book of Record',
  AladdinProcessingName: 'Aladdin Processing',
  FiscalYearEnd: 'Fiscal Year End',
  LotSelectionMethodName: 'Lot Selection Method',
  PrimaryAmortizationRuleName: 'Primary Amortization/Accretion Rule',
  ShortTermDiscountAccrualFlag: 'Short Term Discount Accrual Flag',
  TaxAccountingMethodName: 'Tax (Withholding) Accounting Method',
  TaxId: 'Tax ID',
  LEINumber: 'LEI Number',
  RegulatoryStructureName: 'Regulatory Structure (ERISA) Indicator',
  SECDerivativeRule18f4: 'SEC Derivative Rule 18f-4',
  LegalInvestmentManagerName: 'Legal Investment Manager',
  ReportingCurrencyName: 'Reporting Currency Code',
  InsuranceLegalEntityGroupingName: 'Insurance Legal Entity Grouping',
  ClientName: 'Client Name',
  FinanceAUMSourceName: 'Finance AUM Source',
  FinanceAUMAmountTypeName: 'Finance AUM Amount Type',
  FinanceBusinessLineName: 'Finance Business Line',
  ESGFlag: 'ESG Flag',
  ESGClientDirectedExclusion: 'ESG - Client Directed Exclusion',
  ESGFullIntegration: 'ESG - Integration',
  ESGSustainability: 'ESG - Sustainability Solutions',
  ESGSustainabilityObjectiveName: 'ESG Sustainability Objective',
  Tag: 'Name',
  PortfolioTags: 'Tags',
  PortfolioTagIds: 'Tag',
  Description: 'Description',
  Team: 'Team',
  CreatedBy: 'Created By',
  CreatedOn: 'Created On',
  ModifiedBy: 'Modified By',
  ModifiedOn: 'Modified On',
  PortfolioXReferenceCategoryName: '',
  Benchmarks: '',
  AnalyticsBenchmarks: '',
  ProxyVotingFlag: 'Proxy Voting Flag',
  TransferAgentSystemName: 'Transfer Agent System',
  MASSFundOfFundsSystem: 'MASS Fund of Funds System',
  VoyaSubAdvised: 'Voya Sub-Advised',
  LegalStructureName: 'Legal Structure',
  RiskModelName: 'Risk Model',
  EquityIPOAllowed: 'Equity IPO/Secondaries Allowed',
  SoftDollarsAllowed: 'Soft Dollars Allowed',
  CommissionSharingAgreement: 'Commission Sharing Arrangement Allowed',
  CrossTradingAllowed: 'Cross Trading Allowed',
  DirectedBrokerage: 'Directed Brokerage',
  ComplianceCertification: 'Compliance Certification',
  MFN: 'MFN (Most Favored Nations)',
  PerformanceBasedFee: 'Performance Based Fee',
  AccountingBasisName: 'Accounting Basis',
  LoadCashFlows: 'Load Cashflows',
  NAICDesignations: 'NAIC Designations',
};

export const user_roles = {
  approver: 'Approver',
  admin: 'Admin',
  reader: 'Reader',
  owner: 'Data Owner',
};

export const home_screen_filterCheckbox = [
  {
    key: 'Status_check',
    text: 'Include closed portfolios',
    value: 'Closed',
    isExclude: true,
    isReverse: true,
    isDefaultFilter: true,
  },
  {
    key: 'LegalInvestmentManagerName_check',
    text: 'Include externally managed portfolios',
    value: 'External Manager',
    isExclude: true,
    isReverse: true,
    isDefaultFilter: true,
  },
];

export const Default_Filters = home_screen_filterCheckbox.filter(
  (item) => item.isDefaultFilter
);

export const Benchmark_Suffix = ' Benchmark';
export const Benchmark_DQ_Values = ['Not Applicable', 'No benchmark'];

export const Aladdin_form_fields = [
  'PortfolioCode',
  'PortfolioName',
  'PortfolioTypeName',
  'InceptionDate',
  'VehicleName',
  'PrimaryBenchmarkId',
  'PrimaryAnalyticsBenchmarkId',
  'SecondaryAnalyticsBenchmarkId',
  'AssetClassName',
  'InvestmentStrategyName',
  'PrimaryPortfolioManagerName',
  'PortfolioManagerTeamMembers',
  'PortfolioManagerTeamName',
  'DomicileCountryName',
  'BaseCurrencyName',
  'CustodianBankName',
  'CustodianAccountNumber',
  'IBORSystemName',
  'AladdinProcessingName',
  'TaxId',
  'RegulatoryStructureName',
  'SECDerivativeRule18f4',
  'InvestOneAccountNumber',
  'SGAAccountNumber',
];

export const SGA_form_fields = [
  'PortfolioCode',
  'PortfolioName',
  'SGAAccountNumber',
  'CustodianBankName',
  'CustodianAccountNumber',
  'InvestOneAccountNumber',
  'DomicileCountryName',
  'BaseCurrencyName',
  'TaxId',
  'FiscalYearEnd',
  'PrimaryAmortizationRuleName',
  'InceptionDate',
  'VehicleName',
  'InsuranceAccountingSystemName',
  'LotSelectionMethodName',
  'ShortTermDiscountAccrualFlag',
  'TaxAccountingMethodName',
  'TransferAgentSystemName',
];

export const OneStop_form_fields = [
  'PortfolioCode',
  'PortfolioName',
  'ParentPortfolioCode',
  'PortfolioTypeName',
  'Status',
  'InceptionDate',
  'LiquidationDate',
  'VehicleName',
  'AssetClassName',
  'InvestmentStrategyName',
  'ManagementStyleName',
  'PrimaryPortfolioManagerName',
  'PortfolioManagerTeamMembers',
  'PortfolioManagerTeamName',
  'PrimaryBenchmarkId',
  'SecondaryBenchmarkId',
  'TertiaryBenchmarkId',
  'PerformanceInceptionDate',
  'PerformanceStartDate',
  'PerformanceBookOfRecordName',
  'BaseCurrencyName',
  'IBORSystemName',
  'ABORSystemName',
  'TransferAgentSystemName',
  'TaxAccountingMethodName',
  'ReportingCurrencyName',
  'SGAAccountNumber',
  'InvestOneAccountNumber',
  'BlackrockIdentifier',
  'ShareholderID',
  'SubVehicleName',
  'PerformanceBasedFee',
  // "LegalStructureName",
];

export const single_reference_ids: any = {
  PortfolioBenchmarks: ['Benchmarks', 'AnalyticsBenchmarks'],
  PortfolioXReferences: ['PortfolioXReferenceCategoryName'],
  ShareClasses: ['ShareClassIdentifierName'],
};

export const exclude_filed = ['InnerExport', 'Action'];

export const default_gridDef = {
  sortable: false,
  initialSort: null,
  pageable: false,
  filterable: false,
  groupable: false,
  pageSize: 5,
  hasExpandToggle: false,
  hasExportExcel: false,
  exportFileName: 'Export',
  groupConfig: [],
  resizable: false,
  reorderable: false,
  hideColumn: false,
  toolbarRender: null,
  rowExportFn: false,
  rowExportFnButtonTextRender: null,
  rowExportFnButtonDisabled: false,
  rowExportFieldsGenerator: null,
};

export const DEFAULT_PM_GRID_DEF = {
  sortable: true,
  initialSort: [
    {
      field: 'Status',
      dir: 'desc',
      compare: (a: any, b: any) => statusCompare(a, b, 'desc'),
    },
    {
      field: 'InceptionDate',
      dir: 'desc',
    },
    {
      field: 'CreatedOn',
      dir: 'desc',
    },
  ],
  pageable: {
    buttonCount: 4,
    pageSizes: [50, 100, 500, 'All'],
  },
  filterable: true,
  groupable: true,
  pageSize: 50,
  hasExpandToggle: true,
  hasExportExcel: true,
  exportFileName: 'Portfolio Master',
  resizable: true,
  reorderable: false,
  hideColumn: true,
};

export const reference_data_fields_pair: any = {
  InvestmentStrategyName: 'AssetClassName',
  SubVehicleName: 'VehicleName',
};

export const portfolio_toggle_datafields = [
  'Discretionary',
  'MultiSector',
  'ShortTermDiscountAccrualFlag',
  'ProxyVotingFlag',
  'SECDerivativeRule18f4',
  'ESGFlag',
  'ESGClientDirectedExclusion',
  'ESGFullIntegration',
  'ESGSustainability',
  'MASSFundOfFundsSystem',
  'VoyaSubAdvised',
  'EquityIPOAllowed',
  'SoftDollarsAllowed',
  'CommissionSharingAgreement',
  'CrossTradingAllowed',
  'DirectedBrokerage',
  'MFN',
  'PerformanceBasedFee',
  'LoadCashFlows',
  'NAICDesignations',
];

export const Filter_Suffix = '_check';
export const data_value_split = ' -$- ';
export const currency_data_value_split = ' - ';

export const portfolio_date_datafields = [
  'InceptionDate',
  'LiquidationDate',
  'PerformanceInceptionDate',
  'PerformanceStartDate',
  'FiscalYearEnd',
];

export const DEFAULT_VIEW_MODE = {
  simple: {
    columnDefs: [
      { field: 'Status', width: '150px' },
      { field: 'PortfolioCode', width: '150px' },
      { field: 'portfolioName', width: '500px' },
      {
        field: 'InvestmentStrategyName',
      },
      {
        field: 'VehicleName',
      },
    ],
  },
  detailed: {
    columnDefs: [
      { field: 'Status', width: '160px' },
      {
        field: 'InceptionDate',
        filter: 'date',
        width: '110px',
      },
      { field: 'PortfolioCode', width: '120px' },
      { field: 'PortfolioName', width: '320px' },
      {
        field: 'VehicleName',
        width: '200px',
      },
      {
        field: 'SubVehicleName',
        width: '150px',
      },
      {
        field: 'AssetClassName',
        width: '120px',
      },
      {
        field: 'InvestmentStrategyName',
        width: '300px',
      },
      {
        field: 'PrimaryBenchmarkId',
        width: '400px',
      },
      {
        field: 'PrimaryAnalyticsBenchmarkId',
        width: '400px',
      },
      {
        field: 'PortfolioManagerTeamName',
        width: '200px',
      },
      {
        field: 'PortfolioTypeName',
        width: '100px',
      },
      {
        field: 'BaseCurrencyName',
        width: '100px',
      },
      {
        field: 'VoyaSubAdvised',
        width: '100px',
      },
      {
        field: 'CreatedOn',
        filter: 'date',
        width: '110px',
      },
    ],
  },
};

export const PM_URL_PARAMS = {
  role: 'role',
};

export const AUTH_HTTP_HEADER = 'Authorization';

export const portfolio_menuitems = [
  {
    text: 'Details',
    key: 'details',
    isEditable: true,
  },
  {
    text: 'Operational',
    key: 'operational',
    isEditable: true,
  },
  {
    text: 'Performance',
    key: 'performance',
    isEditable: true,
  },
  {
    text: 'Accounting',
    key: 'accounting',
    isEditable: true,
  },
  {
    text: 'Compliance and Regulatory',
    key: 'compliance',
    isEditable: true,
  },
  {
    text: 'Risk',
    key: 'risk',
    isEditable: true,
  },
  {
    text: 'Alternate Identifiers',
    key: 'alternate',
    isEditable: true,
  },
  {
    text: 'Reporting',
    key: 'reporting',
    isEditable: true,
  },
  {
    text: 'Tags',
    key: 'tags',
  },
  {
    text: 'Form Generation',
    key: 'form',
  },
];

export const portfolio_content_datafields = {
  details: [
    {
      title: 'Core',
      owner: ['Business Implementation Team (Portfolio)'],
      datafields: [
        {
          apiField: 'PortfolioCode',
          fieldType: 'text',
          characterLimit: 10,
        },
        {
          apiField: 'Status',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'PortfolioName',
          fieldType: 'text',
          characterLimit: 50,
        },
        {
          apiField: 'PortfolioTypeName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'ParentPortfolioCode',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'VoyaSubAdvised',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
        {
          apiField: 'VehicleName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'SubVehicleName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'InceptionDate',
          fieldType: 'datepicker',
          characterLimit: undefined,
        },
        {
          apiField: 'LiquidationDate',
          fieldType: 'datepicker',
          characterLimit: undefined,
        },
      ],
    },
    {
      title: 'Investment attributes',
      owner: [
        'Business Implementation Team (Portfolio)',
        'Investment Data & Analytics',
      ],
      datafields: [
        {
          apiField: 'PrimaryAnalyticsBenchmarkId',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'SecondaryAnalyticsBenchmarkId',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'AssetClassName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'InvestmentStrategyName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'ManagementStyleName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'Discretionary',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
      ],
    },
    {
      title: 'Management team',
      owner: ['Investment Team'],
      datafields: [
        {
          apiField: 'PortfolioManagerTeamName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'PrimaryPortfolioManagerName',
          fieldType: 'text',
          characterLimit: undefined,
        },
        {
          apiField: 'PortfolioManagerTeamMembers',
          fieldType: 'text',
          characterLimit: undefined,
        },
      ],
    },
  ],
  performance: [
    {
      title: 'Core',
      owner: ['Performance'],
      datafields: [
        {
          apiField: 'PrimaryBenchmarkId',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'SecondaryBenchmarkId',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'TertiaryBenchmarkId',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'PerformanceInceptionDate',
          fieldType: 'datepicker',
          characterLimit: undefined,
        },
        {
          apiField: 'PerformanceStartDate',
          fieldType: 'datepicker',
          characterLimit: undefined,
        },
      ],
    },
  ],
  operational: [
    {
      title: 'Core',
      owner: ['Business Implementation Team (Portfolio)', 'Accounting'],
      datafields: [
        {
          apiField: 'DomicileCountryName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'BaseCurrencyName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'CustodianBankName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'CustodianAccountNumber',
          fieldType: 'text',
          characterLimit: 20,
        },
      ],
    },
    {
      title: 'System Specific',
      owner: [
        'Business Implementation Team (Portfolio)',
        'Performance',
        'Investment Data & Analytics',
      ],
      datafields: [
        {
          apiField: 'IBORSystemName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'ABORSystemName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'TransferAgentSystemName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'InsuranceAccountingSystemName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'TradingSystemName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'PerformanceBookOfRecordName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'AladdinProcessingName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'MASSFundOfFundsSystem',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
      ],
    },
  ],
  accounting: [
    {
      title: 'Insurance',
      owner: ['Accounting'],
      datafields: [
        {
          apiField: 'InsuranceLegalEntityGroupingName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'AccountingBasisName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'LoadCashFlows',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
        {
          apiField: 'NAICDesignations',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
      ],
    },
    {
      title: 'Core',
      owner: ['Accounting'],
      datafields: [
        {
          apiField: 'FiscalYearEnd',
          fieldType: 'datepicker',
          characterLimit: undefined,
        },
        {
          apiField: 'LotSelectionMethodName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'PrimaryAmortizationRuleName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'ShortTermDiscountAccrualFlag',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
        {
          apiField: 'TaxAccountingMethodName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
      ],
    },
  ],
  compliance: [
    {
      title: 'Compliance',
      owner: ['Business Implementation Team (Portfolio)', 'Compliance'],
      datafields: [
        {
          apiField: 'TaxId',
          fieldType: 'text',
          characterLimit: 50,
        },
        {
          apiField: 'LEINumber',
          fieldType: 'text',
          characterLimit: 20,
        },
        {
          apiField: 'EquityIPOAllowed',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
        {
          apiField: 'SoftDollarsAllowed',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
        {
          apiField: 'CommissionSharingAgreement',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
        {
          apiField: 'CrossTradingAllowed',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
        {
          apiField: 'DirectedBrokerage',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
        {
          apiField: 'ComplianceCertification',
          fieldType: 'text',
          characterLimit: 100,
        },
      ],
    },
    {
      title: 'Regulatory',
      owner: ['Legal'],
      datafields: [
        {
          apiField: 'LegalInvestmentManagerName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'RegulatoryStructureName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        /*{
          apiField: 'LegalStructureName',
          fieldType: 'dropdown'
        }*/
      ],
    },
    {
      title: 'Active Ownership',
      owner: ['Active Ownership'],
      datafields: [
        {
          apiField: 'ProxyVotingFlag',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
      ],
    },
  ],
  risk: [
    {
      title: 'Risk',
      owner: ['Risk' /*, "Investment Data & Analytics"*/],
      datafields: [
        {
          apiField: 'SECDerivativeRule18f4',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
        /*{
          apiField: 'RiskModelName',
          fieldType: 'dropdown'
        }*/
      ],
    },
  ],
  alternate: [
    {
      title: 'Alternate identifiers',
      owner: [
        'Business Implementation Team (Portfolio)',
        'Investment Data & Analytics',
      ],
      datafields: [
        {
          apiField: 'SGAAccountNumber',
          fieldType: 'text',
          characterLimit: 35,
        },
        {
          apiField: 'STARAccountNumber',
          fieldType: 'text',
          characterLimit: 35,
        },
        {
          apiField: 'BlackrockIdentifier',
          fieldType: 'text',
          characterLimit: 35,
        },
        {
          apiField: 'ShareholderID',
          fieldType: 'text',
          characterLimit: 35,
        },
        {
          apiField: 'InvestOneAccountNumber',
          fieldType: 'text',
          characterLimit: 35,
        },
        {
          apiField: 'OnCoreAccountNumber',
          fieldType: 'text',
          characterLimit: 35,
        },
      ],
    },
  ],
  reporting: [
    {
      title: 'Core',
      owner: ['Accounting' /*, "Business Implementation Team (Portfolio)"*/],
      datafields: [
        {
          apiField: 'ReportingCurrencyName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        // {
        //   apiField: 'ClientName',
        //   fieldType: 'dropdown',
        // },
        {
          apiField: 'MultiSector',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
      ],
    },
    {
      title: 'Finance',
      owner: ['Finance', 'Product Management'],
      datafields: [
        {
          apiField: 'FinanceAUMSourceName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'FinanceAUMAmountTypeName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'FinanceBusinessLineName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
        {
          apiField: 'MFN',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
        {
          apiField: 'PerformanceBasedFee',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
      ],
    },
    {
      title: 'ESG Attributes',
      owner: ['Investment Team'],
      datafields: [
        {
          apiField: 'ESGFlag',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
        {
          apiField: 'ESGClientDirectedExclusion',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
        {
          apiField: 'ESGFullIntegration',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
        {
          apiField: 'ESGSustainability',
          fieldType: 'boolean',
          characterLimit: undefined,
        },
        {
          apiField: 'ESGSustainabilityObjectiveName',
          fieldType: 'dropdown',
          characterLimit: undefined,
        },
      ],
    },
  ],
};

export const default_portfolio_content_view = 'details';
export const max_pageSize = 1000;
export const EXCLUDE_FIELDS = ['ClientName'];
export const API_FIELDS = [
  'PortfolioTags',
  'PortfolioCode',
  'Status',
  'PortfolioName',
  'PortfolioTypeName',
  'ParentPortfolioCode',
  'VoyaSubAdvised',
  'VehicleName',
  'SubVehicleName',
  'InceptionDate',
  'LiquidationDate',
  'PrimaryAnalyticsBenchmarkId',
  'SecondaryAnalyticsBenchmarkId',
  'AssetClassName',
  'InvestmentStrategyName',
  'ManagementStyleName',
  'Discretionary',
  'PortfolioManagerTeamName',
  'PrimaryPortfolioManagerName',
  'PortfolioManagerTeamMembers',
  'PrimaryBenchmarkId',
  'SecondaryBenchmarkId',
  'TertiaryBenchmarkId',
  'PerformanceInceptionDate',
  'PerformanceStartDate',
  'DomicileCountryName',
  'BaseCurrencyName',
  'CustodianBankName',
  'CustodianAccountNumber',
  'IBORSystemName',
  'ABORSystemName',
  'TransferAgentSystemName',
  'InsuranceAccountingSystemName',
  'TradingSystemName',
  'PerformanceBookOfRecordName',
  'AladdinProcessingName',
  'MASSFundOfFundsSystem',
  'InsuranceLegalEntityGroupingName',
  'AccountingBasisName',
  'LoadCashFlows',
  'NAICDesignations',
  'FiscalYearEnd',
  'LotSelectionMethodName',
  'PrimaryAmortizationRuleName',
  'ShortTermDiscountAccrualFlag',
  'TaxAccountingMethodName',
  'TaxId',
  'LEINumber',
  'EquityIPOAllowed',
  'SoftDollarsAllowed',
  'CommissionSharingAgreement',
  'CrossTradingAllowed',
  'DirectedBrokerage',
  'ComplianceCertification',
  'LegalInvestmentManagerName',
  'RegulatoryStructureName',
  'ProxyVotingFlag',
  'SECDerivativeRule18f4',
  'SGA Account Number',
  'STAR Account Number',
  'Blackrock Identifier',
  'Shareholder ID',
  'InvestOne Account Number',
  'OnCore Account Number',
  'ReportingCurrencyName',
  'MultiSector',
  'FinanceAUMSourceName',
  'FinanceAUMAmountTypeName',
  'FinanceBusinessLineName',
  'MFN',
  'PerformanceBasedFee',
  'ESGFlag',
  'ESGClientDirectedExclusion',
  'ESGFullIntegration',
  'ESGSustainability',
  'ESGSustainabilityObjectiveName',
  // 'ClientName',
];

export const APP_DETAILS = {
  AppName: 'Portfolio Master',
  DevEmail: 'mailto:Voya-IM-PortfolioMaster-Support@voya.com',
  HelpDeskEmail: 'mailto:VoyaIMHelpDesk@voya.com',
};

export const status_options: any = {
  WorkInProgress: 'In Progress',
  OperationallyReady: 'Operationally Ready',
  Active: 'Active',
  Closed: 'Closed',
  Reactivate: 'Reactivate',
};

export const XReference_Split = ' ';

export const portfolio_required_datafields = [
  'PortfolioCode',
  'VehicleName',
  'PortfolioName',
  'SubVehicleName',
  'PortfolioTypeName',
  'AssetClassName',
  'ParentPortfolioCode',
  'InvestmentStrategyName',
];

export const portfolio_active_required_datafields = [
  'Status',
  'InceptionDate',
  'PrimaryBenchmarkId',
  'PrimaryAnalyticsBenchmarkId',
  'ManagementStyleName',
  'Discretionary',
  'MultiSector',
  // 'PortfolioManagerTeamName',
  'DomicileCountryName',
  'BaseCurrencyName',
  'IBORSystemName',
  'ABORSystemName',
  'InsuranceAccountingSystemName',
  'TradingSystemName',
  'PerformanceBookOfRecordName',
  'AladdinProcessingName',
  'FiscalYearEnd',
  'LotSelectionMethodName',
  'PrimaryAmortizationRuleName',
  'ShortTermDiscountAccrualFlag',
  'TaxAccountingMethodName',
  'TaxId',
  'LegalInvestmentManagerName',
  'RegulatoryStructureName',
  'SECDerivativeRule18f4',
  'ReportingCurrencyName',
  'FinanceAUMSourceName',
  'TransferAgentSystemName',
];

export enum FormGenarationTypes {
  Aladdin = 'Aladdin',
  sga = 'SGA',
  dmi = 'DMI',
  dmiBlackRock = 'dmiBlackRock',
  oneStop = 'OneStop',
  imds = 'IMDS',
}

export const formrequiredFields = {
  Aladdin: ['AladdinProcessingName'].concat(portfolio_required_datafields),
  SGA: [
    'DomicileCountryName',
    'BaseCurrencyName',
    'CustodianAccountNumber',
    'TransferAgentSystemName',
    'InsuranceAccountingSystemName',
    'FiscalYearEnd',
    'LotSelectionMethodName',
    'PrimaryAmortizationRuleName',
    'ShortTermDiscountAccrualFlag',
    'TaxAccountingMethodName',
    'TaxId',
    'InvestOneAccountNumber',
    'SGAAccountNumber',
  ].concat(portfolio_required_datafields),

  DMI: ['FinanceAUMSourceName', 'IBORSystemName'].concat(
    portfolio_required_datafields
  ),
  dmiBlackRock: [portfolio_required_datafields],
  OneStop: [...portfolio_required_datafields],
  IMDS: ['BaseCurrencyName'].concat(portfolio_required_datafields),
};

export const AlphaNumRegx: RegExp = /^[a-z0-9]+$/i;

export class HttpError {
  static BadRequest = 400;
  static Unauthorized = 401;
  static Forbidden = 403;
  static NotFound = 404;
  static TimeOut = 408;
  static Conflict = 409;
  static InternalServerError = 500;
  static BadGateway = 502;
  static GatewayTimeout = 504;
}

export const editable_for_WorkInProgress_only = ['PortfolioCode'];
export const disable_for_Edit_Mode = ['PortfolioCode', 'Status'];
export const enable_for_Closed_only = ['LiquidationDate'];
export const varchar_regexp_fields = {
  PortfolioCode: /^[a-zA-Z0-9_-]+$/,
  LEINumber: /^[a-zA-Z0-9]+$/,
};

export const ESG_DQ_keys = [
  'ESGClientDirectedExclusion',
  'ESGFullIntegration',
  'ESGSustainability',
];

export const ABOR_DQ_key = ['Institutional Separate Account'];
export const FBL_DQ_Vehicle_key = ['Mutual Fund'];
export const PV_DQ_Vehicle_key = ['Mutual Fund', 'Trust Fund'];
export const TAS_Inst_DQ_Sub_Vehicle_key = [
  'Collective Investment Trust',
  'Common Trust Fund',
  'Stable Value - Stabilizer',
];
export const TAS_Retail_DQ_Sub_Vehicle_key = [
  '529 Option',
  'US Mutual Fund',
  'US Listed Closed-End Fund',
  'Variable Portfolio',
  'VACS',
];
export const Shareholder_ID_DQ_Vehicle_key = [];

export const xreference_DQ_key = [
  'IBORSystemName',
  'ABORSystemName',
  'InsuranceAccountingSystemName',
  'TradingSystemName',
];

export const portfolio_inputs_key_max_length_mapping: any = {
  PortfolioCode: 10,
  PortfolioName: 50,
  CustodianAccountNumber: 20,
  LEINumber: 20,
  TaxId: 50,
  ComplianceCertification: 100,
  'SGA Account Number': 35,
  'STAR Account Number': 35,
  'Blackrock Identifier': 35,
  'Shareholder ID': 35,
  'InvestOne Account Number': 35,
  'OnCore Account Number': 35,
  SGAAccountNumber: 35,
  STARAccountNumber: 35,
  BlackrockIdentifier: 35,
  ShareholderID: 35,
  InvestOneAccountNumber: 35,
  OnCoreAccountNumber: 35,
};

export const portfolio_inputs_key_fixed_length_mapping = ['LEINumber'];
