import {
  ABOR_DQ_key,
  Benchmark_Suffix,
  DEFAULT_VIEW_MODE,
  ESG_DQ_keys,
  Filter_Suffix,
  XReference_Split,
  currency_data_value_split,
  data_value_split,
  portfolio_active_required_datafields,
  portfolio_content_datafields,
  portfolio_inputs_key_fixed_length_mapping,
  portfolio_inputs_key_max_length_mapping,
  portfolio_key_name_mapping,
  portfolio_required_datafields,
  portfolio_toggle_datafields,
  reference_data_fields_pair,
  single_reference_ids,
  status_options,
  xreference_DQ_key,
} from '../const/constants';
import _ from 'lodash';

export const getLocationParam = (paramName: string): string | null => {
  let { search } = window.location;
  const { href } = window.location;
  search === '' && (search = href.split('?')[1] || '');
  const key = `${paramName}=`;
  let value = '';
  if (search.indexOf(key) > -1) {
    value = search.split(key)[1].split('&')[0];
  }
  return !!value ? decodeURIComponent(value) : null;
};

export const getEnv = (): string => {
  const env = isLocal()
    ? 'dev'
    : window.location.hostname.includes('dev')
    ? 'dev'
    : window.location.hostname.includes('test')
    ? 'test'
    : 'prod';
  return env;
};

export const isLocal = (): boolean => {
  return window.location.hostname.includes('local');
};

export const isDev = (): boolean => {
  return getEnv() === 'dev';
};

export const getDataFieldTitle = (field: string) => {
  return (portfolio_key_name_mapping[field] || field).replaceAll('_', ' ');
};
const NAME_FIELD = 'name';
export const sort = (list: any[]) => _.sortBy(list, NAME_FIELD);

export const statusCompare = (a: any, b: any, dir: any) => {
  const correction = dir === 'asc' ? 1 : -1;
  return correction * compareStatus(a.Status, b.Status);
};

export const getSubOptions = (parentValue: any, referenceItem: any) => {
  let newReferenceItem = {};
  if (parentValue === 'all') {
    Object.values(referenceItem).forEach((options: any) => {
      newReferenceItem = { ...newReferenceItem, ...options };
    });
  } else {
    newReferenceItem = referenceItem[parentValue] || {};
  }
  return newReferenceItem;
};

export const getPortfolioManagerTeamOptions = (referenceItem: any) => {
  const newReferenceItem: any = {};
  !!referenceItem &&
    Object.keys(referenceItem).forEach((key) => {
      newReferenceItem[key] = getSplitValue(referenceItem[key], false, 2);
    });
  return newReferenceItem;
};

export const getSplitValue = (
  teamValue: any,
  isCurrency = false,
  index = 1
) => {
  const stringsArray = !!teamValue
    ? teamValue.split(isCurrency ? currency_data_value_split : data_value_split)
    : [];
  return !!stringsArray.length && stringsArray.length > index
    ? stringsArray[index].trim()
    : teamValue;
};

export const getStatusOptions = () =>
  Object.values(_.omit(status_options, [status_options.Reactivate]));

export const getDisplayText = (date: Date) =>
  date ? date.toLocaleDateString() : '';

const compareStatus = (a: any, b: any) => {
  const status1 = _.invert(status_options)[a];
  const status2 = _.invert(status_options)[b];
  if (status1 < status2) {
    return -1;
  } else if (status1 > status2) {
    return 1;
  }
  return 0;
};

export const dateFormatter = (date: string, isDateOnly = true) =>
  !!date
    ? isDateOnly
      ? getDateDisplay(date)
      : new Date(date).toLocaleString()
    : null;

const getDateDisplay = (date: any) => {
  const temp = (date || '').split('T')[0].split('-');
  if (temp.length < 2) {
    return date;
  } else {
    return `${temp[1]}/${temp[2]}/${temp[0]}`;
  }
};

export const getNextStatus = (status: string): any[] => {
  const nextStatusIndex = Object.values(status_options).indexOf(status) + 1;
  return [
    Object.values(status_options)[
      nextStatusIndex < Object.values(status_options).length
        ? nextStatusIndex
        : 0
    ],
  ];
};

export const getStatusClass = (status: string) => {
  if (!status) {
    return '';
  }
  const statusArray = status.toLowerCase().split(' ');
  return `portfolio_status ${statusArray[statusArray.length - 1]}`;
};

export const getDateStringforSavingWithTime = (date?: Date | any): any => {
  try {
    return (
      !!date ? (typeof date === 'string' ? new Date(date) : date) : null
    ).toISOString();
    // .split("T")[0];
  } catch (error) {
    return null;
  }
};
export const getDatePicker = (date?: Date | any): any => {
  try {
    return date.replace(/-/g, '/');
  } catch (error) {
    return null;
  }
};

export const getDateStringforSaving = (date?: Date | any): any => {
  try {
    return (!!date ? (typeof date === 'string' ? new Date(date) : date) : null)
      .toISOString()
      .split('T')[0];
  } catch (error) {
    return null;
  }
};

export const getDateOffset = (date: any) => {
  if (!date) {
    return null;
  }

  const newDate = new Date(date);
  var timezoneOffset = newDate.getTimezoneOffset();
  var offsetDate = new Date(newDate.getTime() + timezoneOffset * 60000);
  return offsetDate;
};

export const dateFormatterUTCtoLocal = (date: any, isDateOnly = true) => {
  //UTC -> Local
  const newDate = !!date
    ? date.includes('Z')
      ? new Date(date)
      : convertDateLocalfromUTC(date)
    : null;
  return !!newDate
    ? isDateOnly
      ? newDate.toLocaleDateString()
      : newDate.toLocaleString()
    : null;
};

export const processReference = (referenceData: any) => {
  let reference: any = {};
  !!referenceData &&
    _.flatten(
      Object.values(_.omit(referenceData, 'PortfolioBenchmarks'))
    ).forEach((item) => {
      const key = item.FieldToUpdate || item.FieldName;
      let newReference: any = {};
      const options = item?.Options;
      !!item &&
        !!options &&
        !!options.length &&
        options.forEach((option: any, index: any) => {
          const referenceId =
            option.Code || option.LookupSubValue || option.Id || index;
          let referenceValue = (
            option.Name ||
            option.PortfolioCode ||
            option
          ).trim();

          if (key === 'PortfolioManagerTeamName') {
            const members = _.chain(option.PortfolioManagerTeamMembers)
              .map('TeamMemberName')
              .join(', ')
              .value();
            referenceValue = `${option.PrimaryPortfolioManagerName}${data_value_split}${members}${data_value_split}${referenceValue}`;
          }
          if (key.toLowerCase().includes('currency')) {
            referenceValue = `${referenceId}${currency_data_value_split}${referenceValue}`;
          }
          if (key === 'ClientName') {
            referenceValue = getSpecialDisplayText(
              referenceValue,
              referenceId,
              'benchmark'
            );
          }
          if (!Object.keys(reference_data_fields_pair).includes(key)) {
            !!option.Status &&
              (key !== 'ParentPortfolioCode' ||
                option.Status !== status_options.Closed) &&
              (newReference[referenceId] = referenceValue);
          } else {
            const parent_key: any = reference_data_fields_pair[key];
            if (key === 'InvestmentStrategyName') {
              const group_key = option[parent_key];
              !newReference[group_key] && (newReference[group_key] = {});
              newReference[group_key] = {
                ...newReference[group_key],
                [referenceId]: referenceValue,
              };
            } else if (key === 'SubVehicleName') {
              let newReferenceValue: any = null;
              const { Id, Name, ParentVehicleName } = option;
              if (!!option && !!ParentVehicleName) {
                !newReferenceValue && (newReferenceValue = {});
                newReferenceValue[Id] = Name;
              }
              if (!!newReferenceValue) {
                !newReference[ParentVehicleName] &&
                  (newReference[ParentVehicleName] = {});
                newReference[ParentVehicleName] = {
                  ...newReference[ParentVehicleName],
                  ...newReferenceValue,
                };
              }
            }
          }
        });
      if (key === 'Status') {
        newReference = status_options;
      }
      (!!Object.keys(newReference).length || key === 'ParentPortfolioCode') &&
        (reference[key] = newReference);
    });
  portfolio_toggle_datafields.forEach((datafield) => {
    reference[datafield] = {
      true: 'Yes',
      false: 'No',
    };
  });
  return reference;
};

const getBenchmarkFieldKey = (isAnalyticsField: boolean, fieldKey: string) => {
  fieldKey = `${fieldKey}${isAnalyticsField ? 'Analytics' : ''}BenchmarkId`;
  return fieldKey;
};

export const processReferenceObject = (referenceData: any) => {
  let reference: any = null;
  !!referenceData &&
    Object.keys(single_reference_ids).forEach((id) => {
      !reference && (reference = {});
      const referenceObject = referenceData[id];
      single_reference_ids[id].forEach((fieldId: string) => {
        const isBenchmarks = id.includes('Benchmarks');
        const isXReference = id.includes('XReference');
        reference[fieldId] = {
          type: isBenchmarks ? 'list' : 'text',
          dataField: id,
          options: null,
          keyField: isBenchmarks ? 'BenchmarkPrecedenceName' : fieldId,
          valueField: isBenchmarks
            ? 'BenchmarkId'
            : isXReference
            ? 'PortfolioXReferenceValue'
            : fieldId,
        };
        if (isBenchmarks) {
          reference[fieldId] = {
            ...reference[fieldId],
            benchmarkType: fieldId.includes('Analytics')
              ? 'Analytics'
              : 'Performance',
            codeKey: `${reference[fieldId].valueField}-Code`,
          };
        }
        !!referenceObject &&
          !!Array.isArray(referenceObject) &&
          !!referenceObject.length &&
          referenceObject.forEach((obj) => {
            const objId = obj.FieldToUpdate || obj.FieldName;
            let options = obj.Options;
            reference[fieldId].options = {
              ...(reference[fieldId].options || {}),
              [objId]: {},
            };
            options
              .filter((option: any) => !option.status)
              .forEach((option: any, index: number) => {
                const referenceId = option.Id || index;
                let referenceValue =
                  option.BenchmarkId || option.Name || option;
                if (isBenchmarks && objId === reference[fieldId].keyField) {
                  const fieldKey = referenceValue.replace(Benchmark_Suffix, '');
                  const isAnalyticsField = fieldId.includes('Analytics');
                  if (
                    !isAnalyticsField ||
                    (isAnalyticsField && fieldKey !== 'Tertiary')
                  ) {
                    reference[fieldId].options[objId][referenceId] =
                      getBenchmarkFieldKey(isAnalyticsField, fieldKey);
                  }
                } else if (
                  isBenchmarks &&
                  objId === reference[fieldId].valueField
                ) {
                  const isAnalyticsField = fieldId.includes('Analytics');
                  const isAnalyticsType = option.Type === 'Analytics';
                  if (
                    (isAnalyticsType && isAnalyticsField) ||
                    (!isAnalyticsType && !isAnalyticsField)
                  ) {
                    //flexiable updates for attaching benchmark code, will remove this once backend change data format.
                    reference[fieldId].options[objId][referenceId] =
                      referenceValue.includes(' (')
                        ? referenceValue
                        : getSpecialDisplayText(
                            referenceValue,
                            option.Code,
                            'benchmark'
                          );
                  }
                } else {
                  reference[fieldId].options[objId][referenceId] =
                    referenceValue;
                }
              });
          });
      });
    });
  return reference;
};

export const genenteGridData = (
  data: any[],
  referenceList: any,
  referenceObjects: any
) => {
  if (!!data && !Array.isArray(data)) {
    return [];
  }
  const referenceMapping = _.chain(referenceObjects)
    .mapValues('dataField')
    .values()
    .uniq()
    .value();
  const dataItem: any = {};
  DEFAULT_VIEW_MODE.detailed.columnDefs.forEach((col: any) => {
    dataItem[col.field] = null;
  });
  return !!referenceList
    ? data.map((item) => {
        const newItem: any = { ...dataItem };
        Object.keys(item).forEach((key) => {
          const referenceItem = referenceList[key] || {};
          const isReferenceObject = referenceMapping.includes(key);
          if (isReferenceObject) {
            const objdata = item[key];
            let referenceObject: any = Object.values(referenceObjects).filter(
              (item: any) => item.dataField === key
            )[0];
            const isBenchmarks =
              referenceObject.dataField.includes('Benchmark');
            (!!referenceList[referenceObject.keyField] || isBenchmarks) &&
              objdata.forEach((data: any) => {
                if (isBenchmarks) {
                  referenceObject = Object.values(referenceObjects).filter(
                    (item: any) => {
                      const { dataField, valueField, options } = item;
                      return (
                        dataField === key &&
                        Object.keys(options[valueField]).includes(
                          `${data[valueField]}`
                        )
                      );
                    }
                  )[0];
                }
                let { keyField, valueField, options, benchmarkType } =
                  referenceObject;
                let fieldKey = data[keyField];
                if (isBenchmarks) {
                  fieldKey = getBenchmarkFieldKey(
                    data.BenchmarkType == 'Analytics',
                    fieldKey
                  );
                }
                !!data.Status &&
                  (newItem[fieldKey] = isBenchmarks
                    ? options[valueField][data[valueField]]
                    : data[valueField]);
              });
          } else if (
            portfolio_toggle_datafields.includes(key) ||
            key === 'Status'
          ) {
            newItem[key] = referenceItem[item[key]];
          } else {
            switch (key) {
              case 'PortfolioManagerTeamName':
                let value = item[key] || null;
                newItem.PrimaryPortfolioManagerName =
                  getPrimaryPortfolioManagerValue(value, referenceItem);
                newItem.PortfolioManagerTeamMembers =
                  getPrimaryPortfolioManagerValue(value, referenceItem, 1);
                newItem[key] = value;
                break;
              case key.toLowerCase().includes('currency') ? key : '':
                newItem[key] = Object.values(referenceItem).find(
                  (fieldValue: any) =>
                    !!item[key] && fieldValue.includes(`- ${item[key]}`)
                );
                break;
              case 'PortfolioTags':
                newItem[key] = _.join(_.map(item[key], 'Name'), ', ');
                break;
              default:
                newItem[key] = item[key];
                break;
            }
          }
        });
        return newItem;
      })
    : [];
};

export const genenteExportData = (data: any[], benchmarksReference: any) => {
  if (!!data && !Array.isArray(data)) {
    return [];
  }
  const dataItem: any = {};
  return data.map((item) => {
    const newItem: any = { ...dataItem };
    Object.keys(item).forEach((key) => {
      const isBenchmarks = key.includes('Benchmark');
      if (isBenchmarks) {
        newItem[key] = benchmarksReference[item[key]];
      } else if (portfolio_toggle_datafields.includes(key)) {
        newItem[key] = !!item[key]
          ? 'Yes'
          : item[key] === false
          ? 'No'
          : item[key];
      } else {
        switch (key) {
          case 'Status':
            newItem[key] = status_options[item[key]] || null;
            break;
          case 'PortfolioTags':
            newItem[key] = _.join(_.map(item[key], 'Name'), ', ');
            break;
          default:
            newItem[key] =
              typeof item[key] === 'object' && key.includes('Date')
                ? item[key].toLocaleDateString('en-CA')
                : item[key];
            break;
        }
      }
    });
    return newItem;
  });
};

export const getPrimaryPortfolioManagerValue = (
  teamValue: any,
  referenceItem: object,
  index = 0
) => {
  const value =
    !!referenceItem && !!teamValue
      ? Object.values(referenceItem)
          .find((team: any) => team.includes(teamValue))
          ?.toString()
          .split(data_value_split)
          [index].trim()
      : null;
  return !!value && value !== 'undefined' ? value : null;
};

export const getSpecialDisplayText = (
  str: string,
  key: any,
  type: 'currency' | 'benchmark'
): string => {
  let newStr = str;
  switch (type) {
    case 'currency':
      newStr = `${key} - ${str}`;
      break;
    case 'benchmark':
      newStr = `${str} (${key})`;
      break;
    default:
      break;
  }
  return newStr;
};

export const getReferenceOptions = (
  referenceId: any,
  referenceList: any,
  referenceObjects: any
) => {
  let referenceItem =
    !!referenceList && !!referenceId
      ? referenceList[
          referenceId.includes('Tag') ? 'PortfolioTagIds' : referenceId
        ]
      : null;
  let codeReferenceItem = null;
  !!referenceObjects &&
    Object.values(referenceObjects).forEach((referenceObject: any) => {
      const {
        options = null,
        keyField,
        valueField,
        codeKey,
      } = referenceObject || {};
      if (!!options && Object.values(options[keyField]).includes(referenceId)) {
        referenceItem = options[valueField];
        !!codeKey && (codeReferenceItem = options[codeKey]);
      }
    });
  return { referenceItem, codeReferenceItem };
};

export const processFilters = (meta: any[], filters?: any[]): any[] => {
  if (!filters || !filters.length) return meta;
  let newdata = [...meta];
  filters.forEach((filter) => {
    newdata = newdata.filter((item) => {
      const { isExclude = false } = filter;
      const key = filter.key.replace(Filter_Suffix, '');
      const value = filter.value;
      let dataValue = Object.keys(item).includes(key) ? item[key] || '' : '';
      if (Array.isArray(item[key])) {
        dataValue = _.join(_.map(item[key], 'Name'), '|');
      }
      dataValue = dataValue.toLowerCase();
      let isIncluded = false;
      if (Array.isArray(value)) {
        value.forEach((filterValue) => {
          isIncluded =
            isIncluded || dataValue.includes(filterValue.toLowerCase());
        });
      } else if (
        typeof value === 'object' &&
        Object.keys(value).includes('min')
      ) {
        if (!!dataValue) {
          const mindate = getDateStringforSaving(value.min);
          const maxdate = getDateStringforSaving(value.max);
          const isMin = !mindate || dataValue >= mindate;
          const isMax = !maxdate || dataValue <= maxdate;
          isIncluded = isMin && isMax;
        }
      } else {
        isIncluded = dataValue.includes(`${filter.value}`.toLowerCase());
      }
      return !isExclude ? isIncluded : !isIncluded;
    });
  });
  return newdata;
};

export const convertDateLocalfromUTC = (date: string): Date | null => {
  const dateStr = (date || '').split('-');
  try {
    const newDate = new Date(
      Date.UTC(Number(dateStr[0]), Number(dateStr[1]) - 1, Number(dateStr[2]))
    );
    newDate.setDate(newDate.getDate() + 1);
    return newDate;
  } catch (error) {
    return null;
  }
};

export const checkParentPortfolio = (typeValue: string) => {
  return !!typeValue && typeValue === 'Sleeve';
};

export const checkXreference = (dataState: any) => {
  return _.chain(xreference_DQ_key)
    .map((itemkey) => {
      return !!dataState[itemkey] ? dataState[itemkey] : '';
    })
    .uniq()
    .join('|')
    .value()
    .replace('Aladdin', 'Blackrock');
};

export const checkXreferenceDQ = (
  dataState: any,
  referenceId: string,
  checkingKey: string
) => {
  let isRequire = false;
  if (!referenceId.includes('Shareholder')) {
    const checking = checkXreference(dataState);
    checking.toLowerCase().includes(checkingKey.toLowerCase()) &&
      (isRequire = true);
  } else {
    !!dataState.TransferAgentSystemName &&
      dataState.TransferAgentSystemName !== 'Not Applicable' &&
      (isRequire = true);
  }
  return isRequire;
};

export const getRequiredFieldsBasedonStatus = (
  dataState: any,
  isSaveForm: boolean,
  referenceObjects: any,
  isInit = false,
  dataFields = portfolio_required_datafields
) => {
  let requiredFields = [...(dataFields || portfolio_required_datafields)];
  if (isSaveForm) {
    return requiredFields;
  }
  if (!!dataState && !!dataState.Status) {
    const status = dataState.Status;
    if (!isInit) {
      switch (status) {
        case status_options.OperationallyReady:
        case 'OperationallyReady':
        case status_options.Active:
          requiredFields = requiredFields.concat(
            portfolio_active_required_datafields
          );

          !!dataState.PerformanceBookOfRecordName &&
            dataState.PerformanceBookOfRecordName !== 'Not Applicable' &&
            requiredFields.push('PerformanceInceptionDate');

          !!dataState.CustodianBankName &&
            dataState.CustodianBankName !== 'No Custodian Access' &&
            requiredFields.push('CustodianAccountNumber');

          !!dataState.ESGFlag &&
            (dataState.ESGFlag === true || dataState.ESGFlag === 'Yes') &&
            (requiredFields = requiredFields.concat(ESG_DQ_keys));

          !!dataState.ESGSustainability &&
            (dataState.ESGSustainability === true ||
              dataState.ESGSustainability === 'Yes') &&
            requiredFields.push('ESGSustainabilityObjectiveName');

          if (!!referenceObjects) {
            const { options, keyField } =
              referenceObjects.PortfolioXReferenceCategoryName || {};
            Object.values(options[keyField]).forEach((referenceId: any) => {
              const checkingKey = referenceId
                .split(XReference_Split)[0]
                .toLowerCase();
              checkXreferenceDQ(dataState, referenceId, checkingKey) &&
                requiredFields.push(referenceId);
            });
          } else {
            portfolio_content_datafields.alternate[0].datafields.forEach(
              (obj: any) => {
                const referenceId = obj.apiField;
                const checkingKey = referenceId
                  .replace('AccountNumber', '')
                  .replace('Identifier', '')
                  .replace('ID', '');
                checkXreferenceDQ(dataState, obj.apiField, checkingKey) &&
                  requiredFields.push(referenceId);
              }
            );
          }
          break;
        case status_options.Closed:
          requiredFields = requiredFields.concat(['LiquidationDate']);
          break;
        default:
          break;
      }
    }
  }
  !!dataState &&
    !checkParentPortfolio(dataState.PortfolioTypeName) &&
    (requiredFields = _.without(requiredFields, 'ParentPortfolioCode'));
  return requiredFields;
};

export const checkRequiredFields = (
  dataState: any,
  requiredFields: string[]
) => {
  const passEsg =
    !_.intersection(requiredFields, ESG_DQ_keys).length ||
    !dataState.ESGFlag ||
    dataState.ESGFlag === false ||
    dataState.ESGFlag === 'No' ||
    ESG_DQ_keys.some((esgkey) => {
      return (
        !!dataState[esgkey] &&
        (dataState[esgkey] === 'Yes' || dataState[esgkey] === true) &&
        (esgkey !== 'ESGSustainability' ||
          (!!dataState.ESGSustainability &&
            (dataState.ESGSustainability === 'Yes' ||
              dataState.ESGSustainability === true) &&
            !!dataState.ESGSustainabilityObjectiveName))
      );
    });
  let errorFields: string[] = [];
  _.without(
    requiredFields,
    ...(passEsg ? ESG_DQ_keys : []),
    'PrimaryPortfolioManagerName',
    'PortfolioManagerTeamMembers'
  ).forEach((key) => {
    if (dataState[key] !== false && !dataState[key]) {
      errorFields = [...errorFields, key];
    }
  });
  return {
    isFailed: !!errorFields.length || !passEsg,
    errorFields: _.uniq(errorFields),
  };
};

export const checkAccessibility = (
  entitlement: any,
  contentView: string,
  section: any
) =>
  entitlement.CanSetup ||
  entitlement.CanApprove ||
  (!!entitlement?.OwnedFields &&
    !!entitlement?.OwnedFields.length &&
    (entitlement?.OwnerSections.indexOf(`${contentView}---${section.title}`) >
      -1 ||
      !section.owner.length));

export const validateInputLength = (
  key: string,
  value: string | string[] | number
) => {
  let isValidationFailed = false;
  const isValidValueType =
    typeof value === 'string' || typeof value === 'number';
  const maxLength = portfolio_inputs_key_max_length_mapping[key];
  const isValidMaximumLength = typeof maxLength === 'number';
  const isFixed = portfolio_inputs_key_fixed_length_mapping.includes(key);
  isValidValueType &&
    isValidMaximumLength &&
    (!isFixed
      ? value.toString().length > maxLength
      : !!value && value.toString().length !== maxLength) &&
    (isValidationFailed = true);
  return isValidationFailed;
};

export const createInputMaxLengthHint = (key: string, isNum = false) => {
  let hint = undefined;
  const maxLength = portfolio_inputs_key_max_length_mapping[key];
  const isValidMaximumLength = typeof maxLength === 'number';
  isValidMaximumLength &&
    (hint = `${maxLength} ${isNum ? 'Digits' : 'Characters'} Long`);
  return hint;
};

export const checkFieldsMaxLength = (dataState: any, datafields?: any) => {
  const maxLengthFields =
    datafields || Object.keys(portfolio_inputs_key_max_length_mapping);
  return maxLengthFields.some(
    (key: string) => dataState[key] && validateInputLength(key, dataState[key])
  );
};

export const processEntitlement = (
  entitlement: any = { OwnedFields: [] },
  contentView: string,
  sectionData: any
) => {
  const OwnerSections: string[] = [];
  const { title, datafields } = sectionData;
  const hasSome = datafields.some((datafield: any) => {
    return entitlement.OwnedFields.includes(datafield.apiField);
  });
  hasSome && OwnerSections.push(`${contentView}---${title}`);
  return { ...entitlement, OwnerSections };
};
