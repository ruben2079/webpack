import { MsalInterceptorConfiguration } from '@azure/msal-angular';
import { InteractionType } from '@azure/msal-browser';
import { environment } from '../../../environments/environment';
import { getbackendurl } from '../const/api.const';
import { apiScopes } from './msal-instance.factory';
import { getEnv } from '../utils/utils';

export function MSALInterceptorFactory(
  envConfig: any
): MsalInterceptorConfiguration {
  const env = getEnv();
  const backEndUrl = getbackendurl();
  const protectedResourceMap = new Map<string, Array<string>>();
  protectedResourceMap.set(environment.apiConfig.uri, apiScopes[env]);
  protectedResourceMap.set(backEndUrl, apiScopes[env]);

  return {
    interactionType: InteractionType.Redirect,
    protectedResourceMap,
  };
}
