import {
  BrowserCacheLocation,
  IPublicClientApplication,
  LogLevel,
  PublicClientApplication,
} from '@azure/msal-browser';
import { environment } from '../../../environments/environment';
import { getEnv } from '../utils/utils';

export function MSALInstanceFactory(envConfig: any): IPublicClientApplication {
  const env = getEnv();
  return new PublicClientApplication({
    auth: {
      clientId: clientId[env],
      authority: environment.msalConfig.auth.authority,
      redirectUri: '/',
      postLogoutRedirectUri: '/',

      navigateToLoginRequestUrl: true,
    },
    cache: {
      cacheLocation: BrowserCacheLocation.LocalStorage,
      storeAuthStateInCookie: false,
    },
    system: {
      allowNativeBroker: false, // Disables WAM Broker
      loggerOptions: {
        loggerCallback,
        logLevel: LogLevel.Warning,
        piiLoggingEnabled: false,
      },
    },
  });
}

export function loggerCallback(logLevel: LogLevel, message: string) {
  console.log('[MSAL] Logger: ', message);
}

export const clientId: any = {
  dev: '54d57f3b-6bc6-4f5c-a4cf-23168bfe9c12',
  test: 'cec5d933-976d-4a9d-acbc-3d622367ebc8',
  prod: '9a15041a-8b25-415f-b0ff-d63c1ae1aa0e',
};

export const apiScopes: any = {
  dev: ['api://MasterDev/PortfolioMaster.User'],
  test: ['api://MasterTest/PortfolioMaster.User'],
  prod: ['api://Master/PortfolioMaster.User'],
};

export const instrumentationKey: any = {
  dev: 'acf525d0-9b8a-4929-a55a-d9d8f87df694',
  test: 'e21abf8e-48f1-44ab-ad39-9866fc5b4519',
  prod: '8aefa31c-35f9-4e66-aa08-0edf085370e4',
};
