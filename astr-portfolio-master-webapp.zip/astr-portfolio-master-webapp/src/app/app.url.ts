export const SERVER = {
    portfoliomaster: "https://vim-zue2-dev-astr-mstr-001.vimasezue2intdev002.appserviceenvironment.net"
}